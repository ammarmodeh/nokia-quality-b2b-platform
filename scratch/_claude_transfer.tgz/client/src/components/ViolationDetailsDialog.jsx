import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  IconButton,
  Chip,
  Tooltip
} from '@mui/material';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { MdClose, MdFileDownload } from 'react-icons/md';
import api from '../api/api';
import { format, startOfWeek } from 'date-fns';
import { getCustomWeekNumber } from '../utils/helpers';
import * as XLSX from 'xlsx';

const ViolationDetailsDialog = ({ open, onClose, title, tasks, teamName }) => {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await api.get("/settings");
        setSettings(response.data);
      } catch (err) {
        console.error("Error fetching settings:", err);
      }
    };
    if (open) fetchSettings();
  }, [open]);

  const weekStartDay = settings?.weekStartDay || 0;

  const columns = [
    {
      field: 'week',
      headerName: 'Week',
      width: 80,
      valueGetter: (value, row) => {
        if (!row.interviewDate) return 'N/A';
        try {
          const date = new Date(row.interviewDate);
          const start = startOfWeek(date, { weekStartsOn: weekStartDay });
          const year = start.getFullYear();
          const weekNum = getCustomWeekNumber(start, year, settings || {});
          return weekNum;
        } catch (e) {
          return 'N/A';
        }
      },
      renderCell: (params) => (
        <Box sx={{ fontWeight: 'bold', color: 'var(--text-secondary)' }}>
          W{params.value}
        </Box>
      )
    },
    {
      field: 'interviewDate',
      headerName: 'Interview Date',
      width: 120,
      valueFormatter: (value) => {
        if (!value) return 'N/A';
        try {
          return format(new Date(value), 'yyyy-MM-dd');
        } catch (e) {
          return value;
        }
      }
    },
    {
      field: 'pisDate',
      headerName: 'PIS Date',
      width: 120,
      valueFormatter: (value) => {
        if (!value) return 'N/A';
        try {
          return format(new Date(value), 'yyyy-MM-dd');
        } catch (e) {
          return value;
        }
      }
    },
    {
      field: 'evaluationScore',
      headerName: 'Score',
      width: 80,
      renderCell: (params) => (
        <Box sx={{
          color: params.value <= 6 ? '#f44336' : params.value <= 8 ? '#ff9800' : '#4caf50',
          fontWeight: 'bold'
        }}>
          {params.value}
        </Box>
      )
    },
    {
      field: 'slid',
      headerName: 'SLID',
      width: 120,
    },
    {
      field: 'reason',
      headerName: 'Violation Reason',
      width: 200,
      flex: 1,
    },
    {
      field: 'subReason',
      headerName: 'Sub Reason',
      width: 150,
      valueFormatter: (value) => value || 'N/A'
    },
    {
      field: 'rootCause',
      headerName: 'Root Cause',
      width: 150,
      valueFormatter: (value) => value || 'N/A'
    },
    {
      field: 'customerFeedback',
      headerName: 'Customer Feedback',
      width: 250,
      flex: 1,
      renderCell: (params) => (
        <Tooltip title={params.value || ''} arrow>
          <span style={{
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            display: 'block'
          }}>
            {params.value}
          </span>
        </Tooltip>
      )
    },
    {
      field: 'priority',
      headerName: 'Impact',
      width: 120,
      renderCell: (params) => (
        <Chip
          label={params.value || 'N/A'}
          size="small"
          sx={{
            bgcolor: params.value === 'High' ? 'rgba(244, 67, 54, 0.2)' :
              params.value === 'Medium' ? 'rgba(255, 152, 0, 0.2)' :
                'rgba(76, 175, 80, 0.2)',
            color: params.value === 'High' ? '#f44336' :
              params.value === 'Medium' ? '#ff9800' :
                '#4caf50',
            fontWeight: 500
          }}
        />
      )
    },
    {
      field: 'validationStatus',
      headerName: 'Status',
      width: 130,
      renderCell: (params) => (
        <Typography variant="caption" sx={{ color: 'var(--text-secondary)' }}>
          {params.value}
        </Typography>
      )
    },
    {
      field: 'teamName',
      headerName: 'Team Name',
      width: 150,
      valueGetter: (value, row) => row.teamName || teamName || 'N/A'
    }
  ];

  const exportToExcel = () => {
    if (!tasks || !tasks.length) return;

    const exportData = tasks.map(task => {
      let weekStr = 'N/A';
      let dateStr = 'N/A';
      let pisDateStr = 'N/A';

      if (task.interviewDate) {
        try {
          const date = new Date(task.interviewDate);
          const start = startOfWeek(date, { weekStartsOn: weekStartDay });
          weekStr = `W${getCustomWeekNumber(start, start.getFullYear(), settings || {})}`;
          dateStr = format(date, 'yyyy-MM-dd');
        } catch (e) {
          // Keep defaults
        }
      }

      if (task.pisDate) {
        try {
          pisDateStr = format(new Date(task.pisDate), 'yyyy-MM-dd');
        } catch (e) {
          // Keep defaults
        }
      }

      return {
        'Week': weekStr,
        'Interview Date': dateStr,
        'PIS Date': pisDateStr,
        'SLID': task.slid || 'N/A',
        'Score': task.evaluationScore,
        'Violation Reason': task.reason,
        'Sub Reason': task.subReason || 'N/A',
        'Root Cause': task.rootCause || 'N/A',
        'Customer Feedback': task.customerFeedback || '',
        'Impact': task.priority,
        'Status': task.validationStatus || 'Not validated',
        'Team Name': task.teamName || teamName || 'N/A'
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Detailed Violations');

    // Auto-width columns
    const wscols = Object.keys(exportData[0]).map(k => ({ wch: 20 }));
    // Custom width adjustments
    wscols[0] = { wch: 10 }; // Week
    wscols[1] = { wch: 20 }; // Interview Date
    wscols[2] = { wch: 20 }; // PIS Date
    wscols[3] = { wch: 10 }; // SLID
    wscols[4] = { wch: 10 }; // Score
    wscols[5] = { wch: 30 }; // Reason
    wscols[8] = { wch: 20 }; // Team Name
    worksheet['!cols'] = wscols;

    const namePrefix = teamName || title || 'Detailed';
    const fileName = `${namePrefix.replace(/[\\/:*?"<>|]/g, '_')}_Violations_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullScreen
      PaperProps={{
        sx: {
          backgroundColor: 'var(--surface)',
          color: 'var(--text)',
          borderRadius: 2
        }
      }}
    >
      <DialogTitle component="div" sx={{ borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2 }}>
        <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>{title}</Typography>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Tooltip title="Export to Excel">
            <IconButton onClick={exportToExcel} size="small" sx={{ color: '#4caf50', '&:hover': { bgcolor: 'rgba(76,175,80,0.1)' } }}>
              <MdFileDownload />
            </IconButton>
          </Tooltip>
          <IconButton onClick={onClose} size="small" sx={{ color: 'var(--text-muted)' }}>
            <MdClose />
          </IconButton>
        </Box>
      </DialogTitle>

      <DialogContent sx={{ p: 0, height: 500 }}>
        <DataGrid
          rows={tasks || []}
          columns={columns}
          getRowId={(row) => row._id || Math.random()}
          slots={{ toolbar: GridToolbar }}
          disableRowSelectionOnClick
          sx={{
            border: 0,
            color: 'var(--text)',
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: 'var(--surface)',
              color: '#b0b0b0',
              borderBottom: '1px solid var(--border)'
            },
            '& .MuiDataGrid-cell': {
              borderBottom: '1px solid var(--border)'
            },
            '& .MuiDataGrid-row:hover': {
              backgroundColor: 'var(--surface)'
            },
            '& .MuiDataGrid-footerContainer': {
              borderTop: '1px solid var(--border)'
            },
            '& .MuiTablePagination-root': {
              color: 'var(--text)'
            }
          }}
        />
      </DialogContent>

      <DialogActions sx={{ borderTop: '1px solid var(--border)', p: 1.5 }}>
        <Button onClick={onClose} sx={{ color: 'var(--text)' }}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default ViolationDetailsDialog;
