/* eslint-disable react/prop-types */
import clsx from "clsx";

const Textbox = ({ type, placeholder, label, className, register, name, error }) => {
  return (
    <div className='w-full flex flex-col gap-1'>
      {label && (
        <label htmlFor={name} className='text-[var(--text)]'>
          {label}
        </label>
      )}

      <div>
        <input
          type={type}
          name={name}
          placeholder={placeholder}
          {...register}
          aria-invalid={error ? "true" : "false"}
          className={clsx(
            "bg-transparent px-3 py-2.5 2xl:py-3 border border-gray-300 placeholder-gray-800 text-[var(--text-secondary)] outline-none text-base focus:ring-2 ring-blue-300",
            className
          )}
        />
      </div>
      {error && (
        <span className='text-xs text-[#f64949fe] mt-0.5 '>{error}</span>
      )}
    </div>
  );
}
export default Textbox;