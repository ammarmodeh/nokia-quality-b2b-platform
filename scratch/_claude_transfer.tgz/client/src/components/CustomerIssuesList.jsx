import { alpha } from "../theme/colorFns";
import { useState, useEffect, useMemo, useRef } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  TextField,
  InputAdornment,
  IconButton,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Select,
  FormControl,
  InputLabel,
  Stack,
  useMediaQuery,
  Hidden,
  useTheme,
  Divider,
  Tooltip,
  Grid,
  Checkbox,
  FormControlLabel,
  Tabs,
  Tab,
  TablePagination,
  Pagination,
  Badge,
  Autocomplete
} from '@mui/material';
import { FaFilePdf, FaWhatsapp } from 'react-icons/fa6';
import { toast } from 'sonner';
import LoadingSpinner from './common/LoadingSpinner';
import RecordTicketDialog from './task/RecordTicketDialog';
import AdvancedSearch from './common/AdvancedSearch';
import { MdHistory, MdEmail, MdSearch, MdClose, MdFilterList, MdMoreVert, MdEdit, MdDelete, MdAdd, MdVisibility, MdFileDownload, MdViewList, MdViewModule, MdBarChart, MdRefresh, MdTerminal, MdNewReleases, MdAccessTime } from 'react-icons/md';

import api from '../api/api';
import CustomerIssueDialog from './CustomerIssueDialog';
import GaiaStepsDialog from './task/GaiaStepsDialog';
import CustomerIssuesAnalytics from './CustomerIssuesAnalytics';
import ViewIssueDetailsDialog from './ViewIssueDetailsDialog';
import { utils, writeFile } from 'xlsx';
import { useSelector } from 'react-redux';
import ManagedAutocomplete from "./common/ManagedAutocomplete";


const TruncatedCell = ({ value, label, theme }) => {
  const [isOverflowing, setIsOverflowing] = useState(false);
  const [open, setOpen] = useState(false);
  const textRef = useRef(null);

  useEffect(() => {
    const checkOverflow = () => {
      if (textRef.current) {
        setIsOverflowing(textRef.current.scrollWidth > textRef.current.clientWidth);
      }
    };
    checkOverflow();
    window.addEventListener('resize', checkOverflow);
    return () => window.removeEventListener('resize', checkOverflow);
  }, [value]);

  return (
    <>
      <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', overflow: 'hidden' }}>
        <Typography
          ref={textRef}
          variant="body2"
          sx={{
            fontSize: '0.85rem',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            flex: 1
          }}
        >
          {value || '-'}
        </Typography>
        {isOverflowing && (
          <Tooltip title={`View full ${label}`}>
            <IconButton
              size="small"
              onClick={(e) => {
                e.stopPropagation();
                setOpen(true);
              }}
              sx={{
                ml: 0.5,
                p: 0.25,
                color: 'var(--accent-text)',
                '&:hover': { backgroundColor: 'rgba(123, 104, 238, 0.1)' }
              }}
            >
              <MdVisibility size={14} />
            </IconButton>
          </Tooltip>
        )}
      </Box>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        onClick={(e) => e.stopPropagation()}
        PaperProps={{
          sx: {
            bgcolor: 'var(--surface)',
            color: 'var(--text)',
            border: '1px solid var(--border)',
            maxWidth: '500px',
            width: '100%'
          }
        }}
      >
        <DialogTitle sx={{ borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6" sx={{ color: 'var(--accent-text)', fontWeight: 'bold' }}>{label}</Typography>
          <IconButton onClick={() => setOpen(false)} sx={{ color: 'var(--text-secondary)' }}>
            <MdClose size={20} />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap', color: 'var(--text)' }}>
            {value}
          </Typography>
        </DialogContent>
        <DialogActions sx={{ borderTop: '1px solid var(--border)', p: 2 }}>
          <Button onClick={() => setOpen(false)} sx={{ color: 'var(--accent-text)' }}>Close</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};


const CustomerIssuesList = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const user = useSelector((state) => state?.auth?.user);
  const [issues, setIssues] = useState([]);
  const [filteredIssues, setFilteredIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [anchorEl, setAnchorEl] = useState(null);
  const [currentIssue, setCurrentIssue] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list' | 'grid' | 'analytics'
  const [statusFilter, setStatusFilter] = useState('all'); // 'all' | 'resolved' | 'unresolved'
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [openViewDialog, setOpenViewDialog] = useState(false);

  // Pagination & Source Filter State
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [sourceFilter, setSourceFilter] = useState('Overall');
  const [supervisorFilter, setSupervisorFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('');
  const [dateTypeFilter, setDateTypeFilter] = useState('reported'); // 'reported' | 'pis'

  // --- GAIA & Advanced Search State ---
  const [advancedSearchOpen, setAdvancedSearchOpen] = useState(false);
  const [activeAdvSearch, setActiveAdvSearch] = useState(false);
  const [advSearchFields, setAdvSearchFields] = useState({
    slid: '',
    gaiaId: '',
    requestNumber: '',
    customerName: '',
    contactNumber: '',
    teamName: ''
  });
  const [recordTicketDialogOpen, setRecordTicketDialogOpen] = useState(false);
  const [selectedIssueForTicket, setSelectedIssueForTicket] = useState(null);
  const [gaiaStepsDialogOpen, setGaiaStepsDialogOpen] = useState(false);
  const [gaiaStepsTask, setGaiaStepsTask] = useState(null);
  const [dropdownOptions, setDropdownOptions] = useState({});
  const [columnFilters, setColumnFilters] = useState({
    createdAt: '',
    pisDate: '',
    date: '',
    slid: '',
    customerName: '',
    customerContact: '',
    fromMain: '',
    fromSub: '',
    reporter: '',
    teamName: '',
    teamCode: '',
    installingTeam: '',
    issues: '',
    assignedTo: '',
    closedBy: '',
    dispatched: '',
    status: ''
  });

  const allColumnOptions = useMemo(() => {
    const options = {};
    const keys = [
      'createdAt', 'pisDate', 'date', 'slid', 'customerName',
      'customerContact', 'fromMain', 'fromSub', 'reporter',
      'teamName', 'teamCode', 'installingTeam', 'issues',
      'assignedTo', 'closedBy', 'dispatched', 'status'
    ];

    keys.forEach(key => {
      const uniqueVals = new Set();
      issues.forEach(issue => {
        let val = '';
        switch (key) {
          case 'slid': val = issue.slid; break;
          case 'customerName': val = issue.customerName; break;
          case 'customerContact': val = issue.customerContact; break;
          case 'fromMain': val = issue.fromMain || issue.from; break;
          case 'fromSub': val = issue.fromSub; break;
          case 'reporter': val = issue.reporter; break;
          case 'teamName': val = issue.teamName; break;
          case 'teamCode': val = issue.teamCode; break;
          case 'installingTeam': val = issue.installingTeam; break;
          case 'issues':
            issue.issues?.forEach(i => uniqueVals.add(i.category));
            return;
          case 'assignedTo': val = issue.assignedTo; break;
          case 'closedBy': val = issue.closedBy; break;
          case 'dispatched': val = issue.dispatched === 'yes' ? 'yes' : 'no'; break;
          case 'status': val = issue.solved === 'yes' ? 'closed' : 'open'; break;
          case 'createdAt':
            val = issue.createdAt ? new Date(issue.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A';
            break;
          case 'pisDate':
            val = issue.pisDate ? new Date(issue.pisDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
            break;
          case 'date':
            val = issue.date ? new Date(issue.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
            break;
          default: break;
        }
        if (val) uniqueVals.add(val);
      });
      options[key] = Array.from(uniqueVals).filter(Boolean).sort();
    });
    return options;
  }, [issues]);


  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const fetchIssues = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const response = await api.get('/customer-issues?limit=10000', {
        headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` },
      });
      setIssues(response.data.data);
      setFilteredIssues(response.data.data);
      setError(null);
    } catch (err) {
      setError(err.message || 'Failed to fetch issues');
      toast.error("Failed to refresh issues");
    } finally {
      setLoading(false);
    }
  };

  const fetchDropdowns = async () => {
    try {
      const { data } = await api.get("/dropdown-options/all");
      setDropdownOptions(data || {});
    } catch (error) {
      console.error("Error fetching dropdowns:", error);
    }
  };

  useEffect(() => {
    fetchIssues();
    fetchDropdowns();
  }, []);

  // Compute Latest Issue (Reported Date)
  const latestIssue = useMemo(() => {
    if (!issues || issues.length === 0) return null;
    return [...issues].sort((a, b) => {
      const dateA = a.date ? new Date(a.date) : new Date(0);
      const dateB = b.date ? new Date(b.date) : new Date(0);
      return dateB - dateA;
    })[0];
  }, [issues]);

  // Compute Latest Created Issue (System Created At)
  const latestCreatedIssue = useMemo(() => {
    if (!issues || issues.length === 0) return null;
    return [...issues].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
  }, [issues]);

  useEffect(() => {
    const handleSyncRefresh = () => {
      fetchIssues(true);
    };

    window.addEventListener('cin-refresh', handleSyncRefresh);
    return () => window.removeEventListener('cin-refresh', handleSyncRefresh);
  }, []);

  // --- Refactored Filtering Logic ---
  const filteredByBaseOptions = useMemo(() => {
    let filtered = issues;

    // Filter by Source Tab
    if (sourceFilter !== 'Overall') {
      filtered = filtered.filter(issue => (issue.fromMain === sourceFilter) || (issue.from === sourceFilter));
    }

    // Filter by Supervisor
    if (supervisorFilter !== 'all') {
      filtered = filtered.filter(issue => issue.closedBy === supervisorFilter);
    }

    // Filter by search term (existing quick search)
    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(issue =>
        issue.slid.toLowerCase().includes(term) ||
        issue.reporter.toLowerCase().includes(term) ||
        issue.teamCompany.toLowerCase().includes(term) ||
        (issue.assignedTo && issue.assignedTo.toLowerCase().includes(term)) ||
        (issue.installingTeam && issue.installingTeam.toLowerCase().includes(term)) ||
        (issue.fromMain && issue.fromMain.toLowerCase().includes(term)) ||
        (issue.fromSub && issue.fromSub.toLowerCase().includes(term)) ||
        (issue.from && issue.from.toLowerCase().includes(term)) ||
        (issue.customerName && issue.customerName.toLowerCase().includes(term)) ||
        (issue.customerContact && issue.customerContact.toLowerCase().includes(term)) ||
        (issue.area && issue.area.toLowerCase().includes(term)) ||
        (issue.callerName && issue.callerName.toLowerCase().includes(term)) ||
        (issue.callerDetails && issue.callerDetails.toLowerCase().includes(term)) ||
        (issue.closedBy && issue.closedBy.toLowerCase().includes(term)) ||
        (issue.assigneeNote && issue.assigneeNote.toLowerCase().includes(term)) ||
        (issue.resolutionDetails && issue.resolutionDetails.toLowerCase().includes(term)) ||
        (issue.ticketId && issue.ticketId.toLowerCase().includes(term)) ||
        (issue.issues && issue.issues.some(i =>
          i.category.toLowerCase().includes(term) ||
          (i.subCategory && i.subCategory.toLowerCase().includes(term))
        ))
      );
    }

    // Filter by date range
    if (startDate) {
      const start = new Date(startDate);
      start.setHours(0, 0, 0, 0);
      filtered = filtered.filter(issue => {
        if (!issue.date) return false;
        return new Date(issue.date) >= start;
      });
    }
    if (endDate) {
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      filtered = filtered.filter(issue => {
        if (!issue.date) return false;
        return new Date(issue.date) <= end;
      });
    }

    // Filter by Month
    if (monthFilter) {
      const [year, month] = monthFilter.split('-');
      filtered = filtered.filter(issue => {
        const dateToCheck = dateTypeFilter === 'pis' ? issue.pisDate : issue.date;
        if (!dateToCheck) return false;
        const d = new Date(dateToCheck);
        return d.getFullYear() === parseInt(year) && (d.getMonth() + 1) === parseInt(month);
      });
    }

    // Advanced Search Engine Filtering
    if (activeAdvSearch) {
      filtered = filtered.filter(issue => {
        const matchesSlid = !advSearchFields.slid || issue.slid?.toLowerCase().includes(advSearchFields.slid.toLowerCase());
        const matchesGaiaId = !advSearchFields.gaiaId || issue.latestGaia?.ticketId?.toLowerCase().includes(advSearchFields.gaiaId.toLowerCase());
        const matchesRequest = !advSearchFields.requestNumber || issue.ticketId?.toLowerCase().includes(advSearchFields.requestNumber.toLowerCase());
        const matchesName = !advSearchFields.customerName || issue.customerName?.toLowerCase().includes(advSearchFields.customerName.toLowerCase());
        const matchesContact = !advSearchFields.contactNumber || issue.customerContact?.toLowerCase().includes(advSearchFields.contactNumber.toLowerCase());
        const matchesTeam = !advSearchFields.teamName ||
          issue.teamCompany?.toLowerCase().includes(advSearchFields.teamName.toLowerCase()) ||
          issue.installingTeam?.toLowerCase().includes(advSearchFields.teamName.toLowerCase());

        return matchesSlid && matchesGaiaId && matchesRequest && matchesName && matchesContact && matchesTeam;
      });
    }

    // Column-specific filtering
    if (Object.keys(columnFilters).length > 0) {
      filtered = filtered.filter(issue => {
        return Object.entries(columnFilters).every(([key, value]) => {
          if (!value) return true;
          const term = value.toLowerCase();

          switch (key) {
            case 'slid': return issue.slid?.toLowerCase().includes(term);
            case 'customerName': return issue.customerName?.toLowerCase().includes(term);
            case 'customerContact': return issue.customerContact?.toLowerCase().includes(term);
            case 'fromMain': return (issue.fromMain || issue.from)?.toLowerCase().includes(term);
            case 'fromSub': return issue.fromSub?.toLowerCase().includes(term);
            case 'reporter': return issue.reporter?.toLowerCase().includes(term);
            case 'teamName': return issue.teamName?.toLowerCase().includes(term);
            case 'teamCode': return issue.teamCode?.toLowerCase().includes(term);
            case 'installingTeam': return issue.installingTeam?.toLowerCase().includes(term);
            case 'issues': return issue.issues?.some(i => i.category.toLowerCase().includes(term));
            case 'assignedTo': return issue.assignedTo?.toLowerCase().includes(term);
            case 'closedBy': return issue.closedBy?.toLowerCase().includes(term);
            case 'dispatched': return (issue.dispatched === 'yes' ? 'yes' : 'no').includes(term);
            case 'status': return (issue.solved === 'yes' ? 'closed' : 'open').includes(term);
            case 'createdAt':
              const cDate = issue.createdAt ? new Date(issue.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A';
              return cDate.toLowerCase().includes(term);
            case 'pisDate':
              const pDate = issue.pisDate ? new Date(issue.pisDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
              return pDate.toLowerCase().includes(term);
            case 'date':
              const rDate = issue.date ? new Date(issue.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
              return rDate.toLowerCase().includes(term);
            default: return true;
          }
        });
      });
    }

    return filtered;
  }, [issues, sourceFilter, supervisorFilter, searchTerm, startDate, endDate, monthFilter, dateTypeFilter, activeAdvSearch, advSearchFields, columnFilters]);

  useEffect(() => {
    let filtered = filteredByBaseOptions;

    // Filter by status
    if (statusFilter === 'resolved') {
      filtered = filtered.filter(issue => issue.solved === 'yes');
    } else if (statusFilter === 'unresolved') {
      filtered = filtered.filter(issue => issue.solved === 'no');
    } else if (statusFilter === 'dispatchedOpen') {
      filtered = filtered.filter(issue => issue.dispatched === 'yes' && issue.solved === 'no');
    } else if (statusFilter === 'notDispatchedOpen') {
      filtered = filtered.filter(issue => issue.dispatched !== 'yes' && issue.solved === 'no');
    }

    setFilteredIssues(filtered);
  }, [filteredByBaseOptions, statusFilter]);

  const handleMenuOpen = (event, issue) => {
    setAnchorEl(event.currentTarget);
    setCurrentIssue(issue);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleEditClick = () => {
    setOpenEditDialog(true);
    handleMenuClose();
  };

  const handleDeleteClick = () => {
    setOpenDeleteDialog(true);
    handleMenuClose();
  };

  const handleIssueSubmit = async (issueData, id) => {
    try {
      // Auto-save new supervisor if provided
      if (issueData.solved === 'yes' && issueData.closedBy && issueData.closedBy.trim() !== '') {
        try {
          await api.post('/dropdown-options', {
            category: 'CIN_SUPERVISORS',
            value: issueData.closedBy.trim(),
            label: issueData.closedBy.trim(),
            order: 99
          }, {
            headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
          });
        } catch (opErr) {
          // console.error("Could not auto-save supervisor:", opErr);
          // Don't block issue submission if this fails
        }
      }

      if (id) {
        // Update
        const response = await api.put(
          `/customer-issues/${id}`,
          {
            ...issueData,
            date: issueData.date ? new Date(issueData.date).toISOString() : null,
            pisDate: issueData.pisDate ? new Date(issueData.pisDate).toISOString() : null,
          },
          { headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` } }
        );
        const updated = response.data.data;
        setIssues(prev => prev.map(isl => isl._id === id ? updated : isl));
        setFilteredIssues(prev => prev.map(isl => isl._id === id ? updated : isl));
        setOpenEditDialog(false);
        await fetchIssues(true); // Refetch silently
        toast.success("Issue updated successfully");
      } else {
        // Create
        const response = await api.post('/customer-issues', issueData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
        });
        const created = response.data.data;
        setIssues(prev => [created, ...prev]);
        setFilteredIssues(prev => [created, ...prev]);
        setOpenAddDialog(false);
        // setOpenAnalytics(true); // User wants to see list/analytics updated
        // setOpenAnalytics(true); // User wants to see list/analytics updated
        await fetchIssues(true); // Refetch silently to ensure everything is synced
        toast.success("Issue reported successfully");
      }
    } catch (error) {
      toast.error(id ? "Failed to update issue" : "Failed to create issue");
    }
  };

  const handleDeleteConfirm = async () => {
    try {
      await api.delete(
        `/customer-issues/${currentIssue._id}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
        }
      );

      setIssues(issues.filter(issue => issue._id !== currentIssue._id));
      setFilteredIssues(filteredIssues.filter(issue => issue._id !== currentIssue._id));
      setOpenDeleteDialog(false);
    } catch (error) {
      // console.error('Error deleting issue:', error);
      alert('Failed to delete issue. Please try again.');
    }
  };



  const handleIssueChange = (index, field, value) => {
    const updatedIssues = [...editFormData.issues];
    updatedIssues[index][field] = value;
    setEditFormData(prev => ({ ...prev, issues: updatedIssues }));
  };

  const addIssueRow = () => {
    setEditFormData(prev => ({
      ...prev,
      issues: [...prev.issues, { category: '', subCategory: '' }]
    }));
  };

  const removeIssueRow = (index) => {
    if (editFormData.issues.length > 1) {
      setEditFormData(prev => ({
        ...prev,
        issues: prev.issues.filter((_, i) => i !== index)
      }));
    }
  };

  const exportToExcel = () => {
    const worksheet = utils.json_to_sheet(filteredIssues.map(issue => ({
      'Ticket ID': issue.ticketId || '',
      'SLID': issue.slid,
      'Src (Main)': issue.fromMain || issue.from || '',
      'Src (Sub)': issue.fromSub || '',
      'Team Name': issue.teamName || '',
      'Team Code': issue.teamCode || '',
      'Reporter': issue.reporter,
      'Contact Method': issue.contactMethod,
      'Customer Name': issue.customerName || '',
      'Customer Contact': issue.customerContact || '',
      'Area': issue.area || 'N/A',
      'Caller Name': issue.callerName || 'N/A',
      'Caller Details': issue.callerDetails || 'N/A',
      'Call Date': issue.callDate ? new Date(issue.callDate).toLocaleDateString() : 'N/A',
      'Reporter Note': issue.reporterNote || '',
      'Problem Description': (issue.issues && issue.issues.length > 0)
        ? issue.issues.map(i => `${i.category}${i.subCategory ? ` (${i.subCategory})` : ''}`).join(' | ')
        : issue.issueCategory || '',
      'Assigned User': issue.assignedTo,
      'Installing Team': issue.installingTeam || 'N/A',
      'Assignee Note': issue.assigneeNote || '',
      'Dispatched Status': issue.dispatched === 'yes' ? 'Yes' : 'No',
      'Dispatched Date': issue.dispatchedAt ? new Date(issue.dispatchedAt).toLocaleDateString() : 'N/A',
      'Life Cycle Status': issue.solved === 'yes' ? 'Closed' : 'Open',
      'Resolution Method': issue.resolvedBy || 'N/A',
      'Field Resolution Date': issue.resolveDate ? new Date(issue.resolveDate).toLocaleDateString() : 'N/A',
      'Responsible Supervisor': issue.closedBy || 'N/A',
      'Close Date (Approval)': issue.closedAt ? new Date(issue.closedAt).toLocaleDateString() : 'N/A',
      'Resolution Summary': issue.resolutionDetails || '',
      'ITN Related': (Array.isArray(issue.itnRelated) ? (issue.itnRelated.includes('Yes') ? 'Yes' : 'No') : (issue.itnRelated || 'No')),
      'Subscription Related': (Array.isArray(issue.relatedToSubscription) ? (issue.relatedToSubscription.includes('Yes') ? 'Yes' : 'No') : (issue.relatedToSubscription || 'No')),
      'Date Reported': issue.date ? new Date(issue.date).toLocaleDateString() : 'N/A',
      'PIS Date': issue.pisDate ? new Date(issue.pisDate).toLocaleDateString() : 'N/A',
      'Created At': issue.createdAt ? new Date(issue.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A'
    })));

    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, 'OJO Snags');
    writeFile(workbook, 'OJO_Snags.xlsx');
  };

  const handleExportPDF = async () => {
    try {
      if (filteredIssues.length === 0) {
        toast.error("No issues to export");
        return;
      }

      toast.info("Generating professional PDF report...");

      const reportTitle = "OJO Snags Analytics Report";
      let markdownContent = `**Date Range**: ${startDate || 'All Time'} to ${endDate || 'Now'}\n`;
      markdownContent += `**Total Records**: ${filteredIssues.length}\n`;
      markdownContent += `**Status Filter**: ${statusFilter.toUpperCase()}\n\n---\n\n`;

      filteredIssues.forEach((issue, index) => {
        markdownContent += `## ${index + 1}. Snag - SLID: ${issue.slid}\n`;
        markdownContent += `- **Created At**: ${issue.createdAt ? new Date(issue.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A'}\n`;
        markdownContent += `- **Date Reported**: ${issue.date ? new Date(issue.date).toLocaleDateString() : 'N/A'}\n`;
        markdownContent += `- **Reporter**: ${issue.reporter || 'N/A'}\n`;
        markdownContent += `- **Area**: ${issue.area || 'N/A'}\n`;
        markdownContent += `- **Caller Name**: ${issue.callerName || 'N/A'}\n`;
        markdownContent += `- **Caller Details**: ${issue.callerDetails || 'N/A'}\n`;
        markdownContent += `- **Call Date**: ${issue.callDate ? new Date(issue.callDate).toLocaleDateString() : 'N/A'}\n`;
        markdownContent += `- **From (Main)**: ${issue.fromMain || issue.from || 'N/A'}\n`;
        markdownContent += `- **From (Sub)**: ${issue.fromSub || 'N/A'}\n`;
        markdownContent += `- **Assigned To**: ${issue.assignedTo || 'Unassigned'}\n`;
        markdownContent += `- **Installing Team**: ${issue.installingTeam || 'N/A'}\n`;
        markdownContent += `- **Status**: ${issue.solved === 'yes' ? 'Resolved ✅' : 'Unresolved ❌'}\n`;
        if (issue.resolveDate) markdownContent += `- **Resolve Date**: ${new Date(issue.resolveDate).toLocaleDateString()}\n`;

        markdownContent += `\n### Snags Highlighted:\n`;
        if (issue.issues && issue.issues.length > 0) {
          issue.issues.forEach(i => {
            markdownContent += `- **${i.category}**: ${i.subCategory || 'No Details'}\n`;
          });
        } else {
          markdownContent += `- ${issue.issueCategory || 'N/A'}\n`;
        }

        if (issue.reporterNote) markdownContent += `\n**Reporter Note**: ${issue.reporterNote}\n`;
        if (issue.resolutionDetails) markdownContent += `\n**Resolution Details**: ${issue.resolutionDetails}\n`;

        markdownContent += `\n---\n\n`;
      });

      markdownContent += `\n*Generated by Reach Quality Team - ${new Date().toLocaleString()}*`;

      const response = await api.post('/ai/report/download', {
        reportContent: markdownContent,
        title: reportTitle,
        format: 'pdf'
      }, {
        responseType: 'blob',
        headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `OJO_Snags_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      toast.success("PDF Report exported successfully");
    } catch (error) {
      console.error("PDF Export Error:", error);
      toast.error("Failed to export professional PDF report");
    }
  };

  const handleWhatsAppContact = async (issue) => {
    // Build comprehensive message
    let formattedMessage = `*OJO SNAG REPORT*\n\n`;

    formattedMessage += `*IDENTIFICATION*\n`;
    formattedMessage += `*SLID:* ${issue.slid}\n`;
    if (issue.ticketId) formattedMessage += `*Ticket ID:* ${issue.ticketId}\n`;
    formattedMessage += `*Area:* ${issue.area || 'N/A'}\n`;
    formattedMessage += `*Status:* ${issue.solved === 'yes' ? 'Resolved' : 'Open'}\n\n`;

    formattedMessage += `*CUSTOMER INFO*\n`;
    formattedMessage += `*Name:* ${issue.customerName || 'N/A'}\n`;
    formattedMessage += `*Contact:* ${issue.customerContact || 'N/A'}\n`;
    if (issue.callerName) formattedMessage += `*Caller:* ${issue.callerName} (${issue.callerDetails || 'No details'})\n`;
    formattedMessage += `\n`;

    formattedMessage += `*SOURCE & TEAM*\n`;
    formattedMessage += `*Source:* ${issue.fromMain || issue.from || 'N/A'} ${issue.fromSub ? `(${issue.fromSub})` : ''}\n`;
    formattedMessage += `*Team Company:* ${issue.teamCompany || 'N/A'}\n`;
    formattedMessage += `*Installing Team:* ${issue.installingTeam || 'N/A'}\n`;
    formattedMessage += `*Assigned To:* ${issue.assignedTo || 'Unassigned'}\n\n`;

    formattedMessage += `*SNAG DETAILS*\n`;
    const snagCategories = issue.issues?.map(i => i.category + (i.subCategory ? ` - ${i.subCategory}` : '')).join('\n• ') || 'N/A';
    formattedMessage += `• ${snagCategories}\n`;

    if (issue.reporterNote) formattedMessage += `\n*Reporter Note:* ${issue.reporterNote}\n`;
    if (issue.assigneeNote) formattedMessage += `*Assignee Note:* ${issue.assigneeNote}\n`;

    formattedMessage += `\n*RELATIONSHIPS*\n`;
    formattedMessage += `*ITN Related:* ${issue.itnRelated ? (Array.isArray(issue.itnRelated) ? issue.itnRelated.join(', ') : issue.itnRelated) : 'No'}\n`;
    formattedMessage += `*Subscription Related:* ${issue.relatedToSubscription ? (Array.isArray(issue.relatedToSubscription) ? issue.relatedToSubscription.join(', ') : issue.relatedToSubscription) : 'No'}\n`;

    formattedMessage += `\n*TIMELINE*\n`;
    formattedMessage += `*Reported:* ${issue.date ? new Date(issue.date).toLocaleDateString() : 'N/A'}\n`;
    if (issue.pisDate) formattedMessage += `*PIS Date:* ${new Date(issue.pisDate).toLocaleDateString()}\n`;

    if (issue.dispatched === 'yes') {
      formattedMessage += `*Dispatched:* ${issue.dispatchedAt ? new Date(issue.dispatchedAt).toLocaleDateString() : 'Yes'}\n`;
    }

    if (issue.solved === 'yes') {
      formattedMessage += `\n*RESOLUTION*\n`;
      if (issue.resolveDate) formattedMessage += `*Resolved Date:* ${new Date(issue.resolveDate).toLocaleDateString()}\n`;
      if (issue.resolvedBy) formattedMessage += `*Resolution Method:* ${issue.resolvedBy}\n`;
      if (issue.closedBy) formattedMessage += `*Supervisor:* ${issue.closedBy}\n`;
      if (issue.closedAt) formattedMessage += `*Close Date:* ${new Date(issue.closedAt).toLocaleDateString()}\n`;
      if (issue.resolutionDetails) formattedMessage += `*Summary:* ${issue.resolutionDetails}\n`;
    }

    const teamToContact = issue.installingTeam || issue.teamName;

    if (!teamToContact) {
      toast.error('Team not specified');
      return;
    }

    try {
      // Fetch field team data to get contact number
      const response = await api.get('/field-teams/get-field-teams', {
        headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
      });

      const fieldTeam = response.data.find(team =>
        team.teamName?.trim().toLowerCase() === teamToContact.trim().toLowerCase()
      );

      if (!fieldTeam || !fieldTeam.contactNumber) {
        toast.error('Team contact number not found');
        return;
      }

      let phoneNumber = fieldTeam.contactNumber;

      // Clean and validate phone number
      let cleanNumber = phoneNumber.toString().trim();
      const hasPlus = cleanNumber.startsWith('+');
      cleanNumber = cleanNumber.replace(/[^0-9]/g, '');
      if (hasPlus && cleanNumber) cleanNumber = '+' + cleanNumber;

      const digitsOnly = cleanNumber.replace(/\+/g, '');
      if (digitsOnly.length < 10 || digitsOnly.length > 15) {
        toast.error('Invalid phone number format');
        console.error('Invalid phone number:', phoneNumber, 'cleaned to:', cleanNumber);
        return;
      }

      navigator.clipboard.writeText(formattedMessage).catch(() => { });

      const whatsappUrl = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(formattedMessage)}`;
      window.open(whatsappUrl, '_blank');
    } catch (error) {
      console.error('Error fetching team data:', error);
      toast.error('Failed to fetch team contact information');
    }
  };

  const availableSources = ['Overall', ...new Set(issues.map(i => i.fromMain || i.from).filter(Boolean))];

  const availableSupervisors = useMemo(() => {
    const listSupervisors = issues.map(i => i.closedBy).filter(Boolean);
    const dropdownSupervisors = (dropdownOptions['CIN_SUPERVISORS'] || []).map(opt => opt.value);
    return ['all', ...new Set([...dropdownSupervisors, ...listSupervisors])];
  }, [issues, dropdownOptions]);




  const paginatedIssues = filteredIssues.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (loading) {
    return <LoadingSpinner variant="page" />;
  }

  if (error) {
    return (
      <Box p={4}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }



  const handleColumnFilterChange = (column, value) => {
    setColumnFilters(prev => ({
      ...prev,
      [column]: value
    }));
    setPage(0);
  };

  const renderFilterInput = (column, placeholder = "Filter...") => (
    <Autocomplete
      freeSolo
      size="small"
      options={allColumnOptions[column] || []}
      value={columnFilters[column] || ''}
      onInputChange={(event, newValue) => {
        handleColumnFilterChange(column, newValue);
      }}
      onChange={(event, newValue) => {
        handleColumnFilterChange(column, newValue || '');
      }}
      renderInput={(params) => (
        <TextField
          {...params}
          variant="standard"
          placeholder={placeholder}
          onClick={(e) => e.stopPropagation()}
          sx={{
            '& .MuiInput-root': {
              fontSize: '0.65rem',
              color: 'var(--text)',
              '&:before': { borderBottomColor: 'var(--border)' },
              '&:after': { borderBottomColor: 'var(--accent)' },
            },
            '& .MuiInput-input': {
              padding: '2px 0 2px 0 !important',
              '&::placeholder': { color: 'rgba(255,255,255,0.3)', opacity: 1 }
            }
          }}
        />
      )}
      PaperProps={{
        sx: {
          backgroundColor: 'var(--surface)',
          color: 'var(--text)',
          fontSize: '0.75rem',
          '& .MuiAutocomplete-option': {
            padding: '4px 8px',
            '&[aria-selected="true"]': {
              backgroundColor: 'rgba(123, 104, 238, 0.2)',
            },
            '&.Mui-focused': {
              backgroundColor: 'rgba(123, 104, 238, 0.1)',
            }
          }
        }
      }}
      sx={{
        mt: 0.5,
        width: '100%',
        '& .MuiAutocomplete-clearIndicator': {
          color: 'rgba(255,255,255,0.5)',
          padding: 0,
          '& .MuiSvgIcon-root': { fontSize: '0.8rem' }
        },
        '& .MuiAutocomplete-popupIndicator': {
          color: 'rgba(255,255,255,0.5)',
          padding: 0,
          '& .MuiSvgIcon-root': { fontSize: '0.8rem' }
        }
      }}
    />
  );

  return (
    <Box sx={{
      // maxWidth: '1100px',
      mx: 'auto',
      p: isMobile ? 1 : 3,
      // px: isMobile ? 1 : 3
    }}>
      <Box sx={{
        display: 'flex',
        flexDirection: isMobile ? 'column' : 'row',
        justifyContent: 'space-between',
        alignItems: isMobile ? 'flex-start' : 'center',
        gap: isMobile ? 2 : 0,
        mb: 3
      }}>
        <Typography variant="h5" sx={{
          color: 'var(--accent-text)',
          fontWeight: 'bold',
          fontSize: isMobile ? '1.2rem' : '1.75rem',
        }}>
          Customer Issues
        </Typography>

        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => user?.role === 'Admin' && setOpenAddDialog(true)}
            startIcon={<MdAdd />}
            size={isMobile ? 'small' : 'medium'}
            disabled={user?.role !== 'Admin'}
            sx={{
              backgroundColor: '#1976d2',
              '&:hover': { backgroundColor: '#1565c0' },
              textTransform: 'none',
              borderRadius: '8px',
              px: isMobile ? 1.5 : 3,
            }}
          >
            {isMobile ? 'New' : 'New Issue'}
          </Button>
          <Button
            variant="outlined"
            onClick={exportToExcel}
            startIcon={<MdFileDownload />}
            size={isMobile ? 'small' : 'medium'}
            sx={{
              borderColor: 'var(--border)',
              color: '#4caf50',
              '&:hover': { borderColor: '#4caf50', backgroundColor: 'rgba(76, 175, 80, 0.05)' },
              textTransform: 'none',
              borderRadius: '8px',
              px: isMobile ? 1.5 : 2,
            }}
          >
            {isMobile ? 'Excel' : 'Excel'}
          </Button>
          <Button
            variant="outlined"
            onClick={handleExportPDF}
            startIcon={<FaFilePdf />}
            size={isMobile ? 'small' : 'medium'}
            sx={{
              borderColor: 'var(--border)',
              color: '#f44336',
              '&:hover': { borderColor: '#f44336', backgroundColor: 'rgba(244, 67, 54, 0.05)' },
              textTransform: 'none',
              borderRadius: '8px',
              px: isMobile ? 1.5 : 2,
            }}
          >
            {isMobile ? 'PDF' : 'Pro Report'}
          </Button>

        </Box>
      </Box>

      {latestIssue && (
        <Paper
          elevation={0}
          sx={{
            mb: 3,
            p: 2,
            background: 'linear-gradient(90deg, rgba(123, 104, 238, 0.15) 0%, rgba(30, 30, 30, 1) 100%)',
            border: '1px solid rgba(123, 104, 238, 0.3)',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 2
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: '50%',
                backgroundColor: 'rgba(123, 104, 238, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--accent-text)'
              }}
            >
              <MdNewReleases size={24} />
            </Box>
            <Box>
              <Typography variant="subtitle2" sx={{ color: 'var(--accent-text)', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Latest Issue Reported
              </Typography>
              <Typography variant="body1" sx={{ color: 'var(--text)', fontWeight: 500 }}>
                {latestIssue.slid} <span style={{ opacity: 0.6, margin: '0 8px' }}>•</span> {new Date(latestIssue.date).toLocaleDateString(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' })}
              </Typography>
            </Box>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, flexWrap: 'wrap' }}>
            <Box>
              <Typography variant="caption" sx={{ color: 'var(--text-secondary)', display: 'block' }}>Reporter</Typography>
              <Typography variant="body2" sx={{ color: 'var(--text)' }}>{latestIssue.reporter}</Typography>
            </Box>
            <Box>
              <Typography variant="caption" sx={{ color: 'var(--text-secondary)', display: 'block' }}>Category</Typography>
              <Typography variant="body2" sx={{ color: 'var(--text)' }}>
                {latestIssue.issues && latestIssue.issues.length > 0
                  ? latestIssue.issues[0].category
                  : (latestIssue.issueCategory || 'N/A')}
              </Typography>
            </Box>
            <Button
              size="small"
              variant="outlined"
              onClick={() => {
                setCurrentIssue(latestIssue);
                setOpenViewDialog(true);
              }}
              sx={{
                borderColor: 'var(--accent)',
                color: 'var(--accent-text)',
                '&:hover': {
                  backgroundColor: 'rgba(123, 104, 238, 0.1)',
                  borderColor: 'var(--accent)'
                },
                textTransform: 'none',
                borderRadius: '6px'
              }}
            >
              View Details
            </Button>
          </Box>
        </Paper>
      )}

      {latestCreatedIssue && (
        <Paper
          elevation={0}
          sx={{
            mb: 3,
            p: 2,
            background: 'linear-gradient(90deg, rgba(33, 150, 243, 0.15) 0%, rgba(30, 30, 30, 1) 100%)', // Blue gradient for distinction
            border: '1px solid rgba(33, 150, 243, 0.3)',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 2
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: '50%',
                backgroundColor: 'rgba(33, 150, 243, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#2196f3'
              }}
            >
              <MdAccessTime size={24} />
            </Box>
            <Box>
              <Typography variant="subtitle2" sx={{ color: '#2196f3', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Latest Issue Created
              </Typography>
              <Typography variant="body1" sx={{ color: 'var(--text)', fontWeight: 500 }}>
                {latestCreatedIssue.slid} <span style={{ opacity: 0.6, margin: '0 8px' }}>•</span> {new Date(latestCreatedIssue.createdAt).toLocaleString(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </Typography>
            </Box>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, flexWrap: 'wrap' }}>
            <Box>
              <Typography variant="caption" sx={{ color: 'var(--text-secondary)', display: 'block' }}>Reporter</Typography>
              <Typography variant="body2" sx={{ color: 'var(--text)' }}>{latestCreatedIssue.reporter}</Typography>
            </Box>
            <Box>
              <Typography variant="caption" sx={{ color: 'var(--text-secondary)', display: 'block' }}>Category</Typography>
              <Typography variant="body2" sx={{ color: 'var(--text)' }}>
                {latestCreatedIssue.issues && latestCreatedIssue.issues.length > 0
                  ? latestCreatedIssue.issues[0].category
                  : (latestCreatedIssue.issueCategory || 'N/A')}
              </Typography>
            </Box>
            <Button
              size="small"
              variant="outlined"
              onClick={() => {
                setCurrentIssue(latestCreatedIssue);
                setOpenViewDialog(true);
              }}
              sx={{
                borderColor: '#2196f3',
                color: '#2196f3',
                '&:hover': {
                  backgroundColor: 'rgba(33, 150, 243, 0.1)',
                  borderColor: '#2196f3'
                },
                textTransform: 'none',
                borderRadius: '6px'
              }}
            >
              View Details
            </Button>
          </Box>
        </Paper>
      )}

      <Box sx={{
        backgroundColor: 'var(--surface)',
        p: 2,
        borderRadius: '12px',
        border: '1px solid var(--border)',
        mb: 3,
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
      }}>
        {/* Source Tabs */}
        <Box sx={{ mb: 2, borderBottom: 1, borderColor: 'var(--border)' }}>
          <Tabs
            value={sourceFilter}
            onChange={(e, val) => { setSourceFilter(val); setPage(0); }}
            variant="scrollable"
            scrollButtons="auto"
            allowScrollButtonsMobile
            sx={{
              '& .MuiTabs-indicator': { backgroundColor: 'var(--accent)' },
              '& .MuiTab-root': {
                color: 'var(--text-secondary)',
                textTransform: 'none',
                fontWeight: 500,
                fontSize: '1rem',
                '&.Mui-selected': { color: 'var(--accent-text)' }
              }
            }}
          >
            {availableSources.map(source => (
              <Tab key={source} value={source} label={source} />
            ))}
          </Tabs>
        </Box>

        <Box sx={{
          display: 'flex',
          flexDirection: isMobile ? 'column' : 'row',
          gap: 2,
          mb: 2,
          alignItems: isMobile ? 'stretch' : 'center'
        }}>
          <Button
            variant="outlined"
            onClick={() => setAdvancedSearchOpen(true)}
            startIcon={<MdFilterList />}
            sx={{
              borderColor: activeAdvSearch ? '#7b68ee' : '#3d3d3d',
              color: activeAdvSearch ? '#7b68ee' : '#b3b3b3',
              '&:hover': { borderColor: 'var(--accent)', backgroundColor: 'rgba(123, 104, 238, 0.05)' },
              textTransform: 'none',
              borderRadius: '8px',
              px: 2,
              fontWeight: 'bold',
              minWidth: 'fit-content'
            }}
          >
            {activeAdvSearch ? 'Refine Search' : 'Advanced Search'}
          </Button>

          <TextField
            size="small"
            placeholder="Quick Search (SLID, Name, Number...)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <MdSearch size={20} color={theme.palette.text.secondary} />
                </InputAdornment>
              ),
              endAdornment: searchTerm && (
                <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearchTerm('')}>
                    <MdClose size={16} />
                  </IconButton>
                </InputAdornment>
              )
            }}
            sx={{
              width: isMobile ? '100%' : '300px',
              '& .MuiOutlinedInput-root': {
                backgroundColor: 'var(--surface)',
                borderRadius: '8px',
                '& fieldset': { borderColor: 'var(--border)' },
                '&:hover fieldset': { borderColor: 'var(--accent)' },
                '&.Mui-focused fieldset': { borderColor: 'var(--accent)' },
              }
            }}
          />

          {activeAdvSearch && (
            <Button
              size="small"
              onClick={() => {
                setAdvSearchFields({ slid: '', gaiaId: '', requestNumber: '', customerName: '', contactNumber: '', teamName: '' });
                setActiveAdvSearch(false);
              }}
              sx={{
                color: '#f44336',
                textTransform: 'none',
                fontWeight: 'bold',
                '&:hover': { bgcolor: 'rgba(244, 67, 54, 0.08)' }
              }}
            >
              Clear Search
            </Button>
          )}

          <Box sx={{
            display: 'flex',
            backgroundColor: 'var(--surface)',
            borderRadius: '8px',
            p: 0.5,
            border: '1px solid var(--border)'
          }}>
            {[
              { id: 'list', icon: <MdViewList />, label: 'List' },
              { id: 'analytics', icon: <MdBarChart />, label: 'Analytics' },
              { id: 'grid', icon: <MdViewModule />, label: 'Grid' }
            ].map((mode) => (
              <Tooltip key={mode.id} title={mode.label}>
                <IconButton
                  size="small"
                  onClick={() => setViewMode(mode.id)}
                  sx={{
                    borderRadius: '6px',
                    color: viewMode === mode.id ? '#ffffff' : '#b3b3b3',
                    backgroundColor: viewMode === mode.id ? '#7b68ee' : 'transparent',
                    '&:hover': {
                      backgroundColor: viewMode === mode.id ? '#6c5ce7' : 'rgba(255,255,255,0.05)'
                    },
                    transition: 'all 0.2s',
                    px: 1,
                    gap: 0.5
                  }}
                >
                  {mode.icon}
                  {!isMobile && <Typography variant="caption">{mode.label}</Typography>}
                </IconButton>
              </Tooltip>
            ))}
          </Box>
        </Box>

        <Divider sx={{ mb: 2, borderColor: 'var(--border)' }} />

        <Box sx={{
          display: 'flex',
          flexDirection: isMobile ? 'column' : 'row',
          gap: 2,
          mb: 2,
          alignItems: isMobile ? 'stretch' : 'center'
        }}>
          <Typography variant="body2" sx={{ color: 'var(--text-secondary)', minWidth: 'fit-content' }}>Filter by Date:</Typography>

          {/* Month Filter Controls */}
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <FormControl size="small" sx={{ minWidth: 120 }}>
              <Select
                value={dateTypeFilter}
                onChange={(e) => setDateTypeFilter(e.target.value)}
                sx={{
                  backgroundColor: 'var(--surface)',
                  color: 'var(--text)',
                  fontSize: '0.875rem',
                  height: '40px',
                  '& .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                  '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                  '& .MuiSvgIcon-root': { color: 'var(--text-secondary)' }
                }}
              >
                <MenuItem value="reported">Reported Date</MenuItem>
                <MenuItem value="pis">PIS Date</MenuItem>
              </Select>
            </FormControl>

            <TextField
              type="month"
              value={monthFilter}
              onChange={(e) => {
                setMonthFilter(e.target.value);
                setStartDate(''); // Clear range if month selected
                setEndDate('');
              }}
              size="small"
              sx={{
                width: 160,
                '& .MuiInputBase-root': { color: 'var(--text)', backgroundColor: 'var(--surface)', height: '40px' },
                '& .MuiOutlinedInput-root fieldset': { borderColor: 'var(--border)' },
                '&:hover fieldset': { borderColor: 'var(--accent)' },
                '&.Mui-focused fieldset': { borderColor: 'var(--accent)' },
              }}
            />
            {monthFilter && (
              <IconButton
                size="small"
                onClick={() => setMonthFilter('')}
                sx={{ color: '#f44336' }}
              >
                <MdClose />
              </IconButton>
            )}
          </Box>

          <Divider orientation="vertical" flexItem sx={{ mx: 1, borderColor: 'var(--border)' }} />

          <TextField
            type="date"
            label="From"
            value={startDate}
            onChange={(e) => {
              setStartDate(e.target.value);
              setMonthFilter(''); // Clear month if range selected
            }}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{
              maxWidth: isMobile ? 'none' : '160px',
              '& .MuiInputBase-root': { color: 'var(--text)', backgroundColor: 'var(--surface)' },
              '& .MuiInputLabel-root': { color: 'var(--text-secondary)' },
              '& .MuiOutlinedInput-root fieldset': { borderColor: 'var(--border)' },
              '&:hover fieldset': { borderColor: '#666' },
            }}
          />
          <TextField
            type="date"
            label="To"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{
              maxWidth: isMobile ? 'none' : '200px',
              '& .MuiInputBase-root': { color: 'var(--text)', backgroundColor: 'var(--surface)' },
              '& .MuiInputLabel-root': { color: 'var(--text-secondary)' },
              '& .MuiOutlinedInput-root fieldset': { borderColor: 'var(--border)' },
              '&:hover fieldset': { borderColor: '#666' },
            }}
          />
          {(startDate || endDate) && (
            <Button
              size="small"
              onClick={() => { setStartDate(''); setEndDate(''); }}
              sx={{ color: '#f44336', textTransform: 'none' }}
            >
              Clear Dates
            </Button>
          )}

          <Divider orientation="vertical" flexItem sx={{ mx: 1, borderColor: 'var(--border)', display: isMobile ? 'none' : 'block' }} />

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flex: 1 }}>
            <Typography variant="body2" sx={{ color: 'var(--text-secondary)', minWidth: 'fit-content' }}>Supervisor:</Typography>
            <FormControl size="small" sx={{ minWidth: 200, flex: isMobile ? 1 : 0 }}>
              <Select
                value={supervisorFilter}
                onChange={(e) => { setSupervisorFilter(e.target.value); setPage(0); }}
                sx={{
                  backgroundColor: 'var(--surface)',
                  color: 'var(--text)',
                  '& .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                  '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                  '& .MuiSvgIcon-root': { color: 'var(--text-secondary)' }
                }}
              >
                {availableSupervisors.map(sup => (
                  <MenuItem key={sup} value={sup}>
                    {sup === 'all' ? 'All Supervisors' : sup}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        </Box>

        <Divider sx={{ mb: 2, borderColor: 'var(--border)' }} />

        <Tabs
          value={statusFilter}
          onChange={(e, val) => setStatusFilter(val)}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
          sx={{
            '& .MuiTabs-indicator': {
              backgroundColor: 'var(--accent)',
              height: 3,
              borderRadius: '3px 3px 0 0'
            },
            '& .MuiTab-root': {
              color: 'var(--text-secondary)',
              textTransform: 'none',
              fontWeight: 500,
              fontSize: '0.9rem',
              minWidth: 100,
              '&.Mui-selected': {
                color: 'var(--text)',
              }
            }
          }}
        >
          <Tab value="all" label={`All (${filteredByBaseOptions.length})`} />
          <Tab value="resolved" label={`Closed (${filteredByBaseOptions.filter(i => i.solved === 'yes').length})`} />
          <Tab value="unresolved" label={`Open (${filteredByBaseOptions.filter(i => i.solved === 'no').length})`} />
          <Tab value="dispatchedOpen" label={`Dispatched (Open) (${filteredByBaseOptions.filter(i => i.dispatched === 'yes' && i.solved === 'no').length})`} />
          <Tab value="notDispatchedOpen" label={`Not Dispatched (Open) (${filteredByBaseOptions.filter(i => i.dispatched !== 'yes' && i.solved === 'no').length})`} />
        </Tabs>
      </Box>

      {viewMode === 'analytics' ? (
        <CustomerIssuesAnalytics issues={filteredIssues} />
      ) : viewMode === 'list' ? (
        <>
          <TableContainer component={Paper} sx={{
            mt: 2,
            maxWidth: '100%',
            overflowX: 'auto',
            flex: 1,
            width: "100%",
            border: "1px solid var(--border)",
            borderRadius: "12px",
            color: "var(--text)",
            maxHeight: "calc(100vh - 350px)", // Advanced sticky scroll
            "&.MuiTableContainer-root": {
              backgroundColor: 'var(--surface)',
            },
            "& .MuiTable-root": {
              backgroundColor: "var(--surface)",
              borderCollapse: 'separate',
              borderSpacing: 0,
            },
            "& .MuiTableHead-root": {
              position: 'sticky',
              top: 0,
              zIndex: 3,
              "& .MuiTableCell-root": {
                color: "var(--text-secondary)",
                fontSize: "0.72rem",
                fontWeight: "800",
                textTransform: 'uppercase',
                letterSpacing: '0.8px',
                borderBottom: "2px solid var(--border)",
                whiteSpace: "nowrap",
                padding: "10px 14px",
                backgroundColor: "rgba(30, 30, 30, 0.95)", // Glassmorphism base
                backdropFilter: "blur(8px)", // Advanced effect
              }
            },
            "& .MuiTableBody-root": {
              "& .MuiTableCell-root": {
                borderBottom: "1px solid var(--border)",
                color: "var(--text)",
                fontSize: "0.8rem",
                padding: "6px 12px", // Compact padding
                maxWidth: "180px",
              },
              "& .MuiTableRow-root": {
                backgroundColor: "transparent",
                "&:hover": {
                  backgroundColor: "rgba(123, 104, 238, 0.08)",
                },
                "&:nth-of-type(even)": {
                  backgroundColor: "var(--overlay-subtle)",
                }
              }
            },
            "& .MuiPaper-root": {
              backgroundColor: "transparent",
              boxShadow: "none",
            },
            // Custom Scrollbar
            "&::-webkit-scrollbar": {
              width: "6px",
              height: "6px",
            },
            "&::-webkit-scrollbar-thumb": {
              backgroundColor: "var(--surface-hover)",
              borderRadius: "10px",
              "&:hover": { backgroundColor: "#4d4d4d" }
            },
            "&::-webkit-scrollbar-track": {
              backgroundColor: "transparent",
            },
          }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ pl: 3 }}>Created At</TableCell>
                  <TableCell>PIS Date</TableCell>
                  <TableCell>Report Date</TableCell>
                  <TableCell>SLID</TableCell>
                  <TableCell>Customer</TableCell>
                  <TableCell>Contact</TableCell>
                  <Hidden smDown>
                    <TableCell>Src (Main)</TableCell>
                    <TableCell>Src (Sub)</TableCell>
                  </Hidden>
                  <TableCell>Reporter</TableCell>
                  <Hidden smDown>
                    <TableCell>Team Name</TableCell>
                    <TableCell>Team Code</TableCell>
                    <TableCell>Installing Team</TableCell>
                  </Hidden>
                  <TableCell>Issues</TableCell>
                  <TableCell>Q-Ops Status</TableCell>
                  <TableCell>Q-Ops Reason</TableCell>
                  <TableCell>Q-Ops Log</TableCell>
                  <Hidden mdDown>
                    <TableCell>Assigned</TableCell>
                    <TableCell>Supervisor</TableCell>
                    <TableCell>Dispatched</TableCell>
                    <TableCell>Assignee Note</TableCell>
                  </Hidden>
                  <TableCell>Status</TableCell>
                  <TableCell
                    sx={{
                      pr: 3,
                      textAlign: 'right',
                      position: 'sticky',
                      right: 0,
                      zIndex: 10,
                      backgroundColor: "var(--bg) !important",
                      boxShadow: "-4px 0 12px rgba(0,0,0,0.5)",
                      "&::before": {
                        content: '""',
                        position: 'absolute',
                        left: -1,
                        top: 0,
                        bottom: 0,
                        width: '1px',
                        backgroundColor: 'var(--overlay-subtle)'
                      }
                    }}
                  >
                    Actions
                  </TableCell>
                </TableRow>
                <TableRow sx={{ backgroundColor: "rgba(30, 30, 30, 0.98)" }}>
                  <TableCell sx={{ pl: 3 }}>{renderFilterInput('createdAt')}</TableCell>
                  <TableCell>{renderFilterInput('pisDate')}</TableCell>
                  <TableCell>{renderFilterInput('date')}</TableCell>
                  <TableCell>{renderFilterInput('slid')}</TableCell>
                  <TableCell>{renderFilterInput('customerName')}</TableCell>
                  <TableCell>{renderFilterInput('customerContact')}</TableCell>
                  <Hidden smDown>
                    <TableCell>{renderFilterInput('fromMain')}</TableCell>
                    <TableCell>{renderFilterInput('fromSub')}</TableCell>
                  </Hidden>
                  <TableCell>{renderFilterInput('reporter')}</TableCell>
                  <Hidden smDown>
                    <TableCell>{renderFilterInput('teamName')}</TableCell>
                    <TableCell>{renderFilterInput('teamCode')}</TableCell>
                    <TableCell>{renderFilterInput('installingTeam')}</TableCell>
                  </Hidden>
                  <TableCell>{renderFilterInput('issues')}</TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <Hidden mdDown>
                    <TableCell>{renderFilterInput('assignedTo')}</TableCell>
                    <TableCell>{renderFilterInput('closedBy')}</TableCell>
                    <TableCell>{renderFilterInput('dispatched')}</TableCell>
                    <TableCell></TableCell>
                  </Hidden>
                  <TableCell>{renderFilterInput('status')}</TableCell>
                  <TableCell
                    sx={{
                      pr: 3,
                      position: 'sticky',
                      right: 0,
                      zIndex: 10,
                      backgroundColor: "var(--bg) !important",
                      boxShadow: "-4px 0 12px rgba(0,0,0,0.5)",
                    }}
                  ></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedIssues.length > 0 ? (
                  paginatedIssues.map((issue) => (
                    <TableRow
                      key={issue._id}
                      sx={{
                        '&:hover': { backgroundColor: 'rgba(123, 104, 238, 0.05) !important' },
                        transition: 'background-color 0.2s',
                      }}
                    >
                      <TableCell sx={{ pl: 3, fontSize: '0.85rem' }}>
                        {issue.createdAt ? new Date(issue.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.85rem' }}>
                        {issue.pisDate ? new Date(issue.pisDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A'}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.85rem' }}>
                        {issue.date ? new Date(issue.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A'}
                      </TableCell>
                      <TableCell sx={{ fontWeight: 500, color: 'var(--accent-text) !important' }}>{issue.slid}</TableCell>
                      <TableCell>
                        <TruncatedCell value={issue.customerName} label="Customer Name" theme={theme} />
                      </TableCell>
                      <TableCell>
                        <TruncatedCell value={issue.customerContact} label="Contact Number" theme={theme} />
                      </TableCell>
                      <Hidden smDown>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.fromMain || issue.from} label="Src (Main)" theme={theme} />
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.fromSub} label="Src (Sub)" theme={theme} />
                        </TableCell>
                      </Hidden>
                      <TableCell sx={{ fontSize: '0.85rem' }}>
                        <TruncatedCell value={issue.reporter} label="Reporter" theme={theme} />
                      </TableCell>
                      <Hidden smDown>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.teamName} label="Team Name" theme={theme} />
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.teamCode} label="Team Code" theme={theme} />
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.installingTeam} label="Installing Team" theme={theme} />
                        </TableCell>
                      </Hidden>
                      <TableCell>
                        {issue.issues && issue.issues.length > 0 ? (
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                            {issue.issues.map((i, idx) => (
                              <Chip
                                key={idx}
                                label={i.category}
                                size="small"
                                sx={{
                                  height: 18,
                                  fontSize: '0.65rem',
                                  fontWeight: 700,
                                  backgroundColor: 'rgba(123, 104, 238, 0.08)',
                                  color: 'var(--accent-text)',
                                  border: '1px solid rgba(123, 104, 238, 0.2)',
                                  '&:hover': {
                                    backgroundColor: 'rgba(123, 104, 238, 0.15)',
                                    borderColor: 'var(--accent)'
                                  }
                                }}
                              />
                            ))}
                          </Box>
                        ) : (
                          <Typography variant="body2" sx={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>No Category</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <Tooltip title={dropdownOptions['TRANSACTION_TYPE']?.find(opt => opt.value === issue.latestGaia?.transactionType)?.label || issue.latestGaia?.transactionType || "N/A"}>
                            <Typography variant="body2" sx={{ fontWeight: 900, color: 'primary.main', fontSize: '0.85rem' }}>
                              {issue.latestGaia?.transactionType || "-"}
                            </Typography>
                          </Tooltip>
                          <Tooltip title={dropdownOptions['TRANSACTION_STATE']?.find(opt => opt.value === issue.latestGaia?.transactionState)?.label || issue.latestGaia?.transactionState || "N/A"}>
                            <Typography variant="caption" sx={{ fontWeight: 900, color: 'text.secondary', mt: -0.5, fontSize: '0.7rem' }}>
                              {issue.latestGaia?.transactionState || "-"}
                            </Typography>
                          </Tooltip>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Tooltip title={dropdownOptions['UNF_REASON_CODE']?.find(opt => opt.value === issue.latestGaia?.unfReasonCode)?.label || issue.latestGaia?.unfReasonCode || "N/A"}>
                          <Typography variant="caption" sx={{ color: '#FF5722', fontWeight: 900, fontSize: '0.8rem' }}>
                            {issue.latestGaia?.unfReasonCode || "—"}
                          </Typography>
                        </Tooltip>
                        <Typography variant="caption" sx={{ display: 'block', fontSize: '0.65rem', opacity: 0.6 }}>
                          {issue.latestGaia?.agentName || ""}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="small"
                          variant="text"
                          startIcon={<MdHistory size={14} />}
                          onClick={(e) => {
                            e.stopPropagation();
                            setGaiaStepsTask(issue);
                            setGaiaStepsDialogOpen(true);
                          }}
                          sx={{
                            fontSize: '0.65rem',
                            fontWeight: 700,
                            textTransform: 'none',
                            color: 'var(--accent-text)',
                            padding: '2px 8px',
                            minWidth: 'auto',
                            '&:hover': {
                              backgroundColor: 'rgba(123, 104, 238, 0.1)',
                              textDecoration: 'underline'
                            }
                          }}
                        >
                          View Steps
                        </Button>
                      </TableCell>
                      <Hidden mdDown>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.assignedTo} label="Assigned To" theme={theme} />
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.closedBy} label="Supervisor" theme={theme} />
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={issue.dispatched === 'yes' ? 'Yes' : 'No'}
                            size="small"
                            sx={{
                              height: 20,
                              fontSize: '0.7rem',
                              bgcolor: issue.dispatched === 'yes' ? 'rgba(76, 175, 80, 0.1)' : 'rgba(158, 158, 158, 0.1)',
                              color: issue.dispatched === 'yes' ? '#4caf50' : '#9e9e9e',
                              border: `1px solid ${issue.dispatched === 'yes' ? 'rgba(76, 175, 80, 0.2)' : 'rgba(158, 158, 158, 0.2)'}`
                            }}
                          />
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.85rem' }}>
                          <TruncatedCell value={issue.assigneeNote} label="Assignee Note" theme={theme} />
                        </TableCell>
                      </Hidden>
                      <TableCell>
                        <Chip
                          label={issue.solved === 'yes' ? 'Closed' : 'Open'}
                          size="small"
                          sx={{
                            height: 24,
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            backgroundColor: issue.solved === 'yes' ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)',
                            color: issue.solved === 'yes' ? '#4caf50' : '#f44336',
                            border: `1px solid ${issue.solved === 'yes' ? 'rgba(76, 175, 80, 0.2)' : 'rgba(244, 67, 54, 0.2)'}`,
                            borderRadius: '6px'
                          }}
                        />
                      </TableCell>
                      <Hidden xsDown>
                      </Hidden>
                      <TableCell
                        sx={{
                          pr: 3,
                          textAlign: 'right',
                          position: 'sticky',
                          right: 0,
                          zIndex: 5,
                          backgroundColor: "var(--bg) !important",
                          borderBottom: "1px solid var(--border)",
                          boxShadow: "-4px 0 12px rgba(0,0,0,0.5)",
                          "&::before": {
                            content: '""',
                            position: 'absolute',
                            left: -1,
                            top: 0,
                            bottom: 0,
                            width: '1px',
                            backgroundColor: 'var(--overlay-subtle)'
                          }
                        }}
                      >
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          {(issue.teamName || issue.installingTeam) && (
                            <Tooltip title="Contact Team via WhatsApp">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleWhatsAppContact(issue);
                                }}
                                sx={{ color: '#25D366', '&:hover': { backgroundColor: 'rgba(37, 211, 102, 0.1)' } }}
                              >
                                <FaWhatsapp size={16} />
                              </IconButton>
                            </Tooltip>
                          )}
                          <Tooltip title="Record Transaction / History">
                            <IconButton
                              size="small"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedIssueForTicket(issue);
                                setRecordTicketDialogOpen(true);
                              }}
                              sx={{
                                color: '#10b981',
                                '&:hover': { color: '#059669', backgroundColor: 'rgba(16, 185, 129, 0.1)' }
                              }}
                            >
                              <MdHistory size={18} />
                            </IconButton>
                          </Tooltip>
                          <IconButton
                            size="small"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMenuOpen(e, issue);
                            }}
                            sx={{
                              color: 'var(--text-secondary)',
                              '&:hover': { color: '#ffffff', backgroundColor: 'var(--overlay-subtle)' }
                            }}
                          >
                            <MdMoreVert />
                          </IconButton>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={isMobile ? 6 : 12} align="center" sx={{ color: 'var(--text)' }}>
                      {searchTerm ? 'No matching issues found' : 'No issues available'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={filteredIssues.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            sx={{
              color: 'var(--text-secondary)',
              borderTop: '1px solid var(--border)',
              backgroundColor: 'var(--surface)',
              borderBottomLeftRadius: '12px',
              borderBottomRightRadius: '12px',
              '& .MuiTablePagination-selectIcon': { color: 'var(--text)' },
              '& .MuiTablePagination-actions': { color: 'var(--text)' },
              '& .MuiTablePagination-select': { color: 'var(--text)' },
              '& .MuiTablePagination-displayedRows': { color: 'var(--text)', fontWeight: 600 }
            }}
          />
        </>
      ) : (
        // Grid View
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Box sx={{ mt: 2, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 2 }}>
            {paginatedIssues.length > 0 ? (
              paginatedIssues.map((issue) => (
                <Paper
                  key={issue._id}
                  sx={{
                    p: 2,
                    bgcolor: 'var(--surface)',
                    color: 'var(--text)',
                    borderRadius: 2,
                    border: '1px solid var(--border)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 1.5,
                    position: 'relative'
                  }}
                >
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'var(--accent-text)', fontSize: '1rem' }}>
                      {issue.slid}
                    </Typography>
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuOpen(e, issue)}
                      sx={{ color: 'var(--text)', mt: -1, mr: -1 }}
                    >
                      <MdMoreVert />
                    </IconButton>
                  </Box>

                  <Box>
                    <Typography variant="caption" color="var(--text-secondary)">From</Typography>
                    <Typography variant="body2">{issue.from}</Typography>
                  </Box>

                  <Box>
                    <Typography variant="caption" color="var(--text-secondary)">Issue</Typography>
                    {issue.issues && issue.issues.length > 0 ? (
                      <Stack spacing={0.5}>
                        {issue.issues.map((i, idx) => (
                          <Typography key={idx} variant="body2" noWrap>
                            {i.category}{i.subCategory ? ` - ${i.subCategory}` : ''}
                          </Typography>
                        ))}
                      </Stack>
                    ) : (
                      <Typography variant="body2" noWrap>{issue.issueCategory}</Typography>
                    )}
                  </Box>

                  <Box>
                    <Typography variant="caption" color="var(--text-secondary)">Assigned To</Typography>
                    <Typography variant="body2">{issue.assignedTo}</Typography>
                  </Box>

                  <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1 }}>
                    <Chip
                      label={issue.solved === 'yes' ? 'Resolved' : 'Unresolved'}
                      color={issue.solved === 'yes' ? 'success' : 'error'}
                      size="small"
                      sx={{
                        color: "var(--text)",
                        '&.MuiChip-colorSuccess': { backgroundColor: '#4caf50' },
                        '&.MuiChip-colorError': { backgroundColor: '#f44336' }
                      }}
                    />
                  </Stack>

                  <Divider sx={{ bgcolor: 'var(--surface-hover)' }} />

                  <Box sx={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    <span>Reported: {new Date(issue.date).toLocaleDateString()}</span>
                    {issue.resolveDate && <span>Resolved: {new Date(issue.resolveDate).toLocaleDateString()}</span>}
                  </Box>
                </Paper>
              ))
            ) : (
              <Typography sx={{ color: 'var(--text)', gridColumn: '1/-1', textAlign: 'center', py: 4 }}>
                {searchTerm ? 'No matching issues found' : 'No issues available'}
              </Typography>
            )}
          </Box>
          <Pagination
            count={Math.ceil(filteredIssues.length / rowsPerPage)}
            page={page + 1}
            onChange={(e, p) => setPage(p - 1)}
            color="primary"
            sx={{ alignSelf: 'center', '& .MuiPaginationItem-root': { color: 'var(--text)' } }}
          />
        </Box>
      )}

      {/* Action Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        sx={{
          "& .MuiPaper-root": {
            backgroundColor: 'var(--surface)',
            color: 'var(--text)',
            boxShadow: 'none',
            borderRadius: '8px',
            border: '1px solid var(--border)',
            minWidth: '200px',
          },
          "& .MuiList-root": {
            padding: '4px 0',
          }
        }}
      >
        <MenuItem
          onClick={() => { setOpenViewDialog(true); handleMenuClose(); }}
          sx={{
            '&:hover': {
              backgroundColor: 'var(--surface)',
            },
            '&.MuiMenuItem-root': {
              padding: '8px 16px',
            }
          }}
        >
          <MdVisibility style={{ marginRight: 8, color: 'var(--text)' }} />
          <Typography variant="body1" color="var(--text)">View</Typography>
        </MenuItem>

        {user && user.role === 'Admin' && [
          <MenuItem
            key="edit"
            onClick={handleEditClick}
            sx={{
              '&:hover': {
                backgroundColor: 'var(--surface)',
              },
              '&.MuiMenuItem-root': {
                padding: '8px 16px',
              }
            }}
          >
            <MdEdit style={{ marginRight: 8, color: 'var(--text)' }} />
            <Typography variant="body1" color="var(--text)">Edit</Typography>
          </MenuItem>,

          <MenuItem
            key="delete"
            onClick={handleDeleteClick}
            sx={{
              '&:hover': {
                backgroundColor: 'var(--surface)',
              },
              '&.MuiMenuItem-root': {
                padding: '8px 16px',
              },
              color: '#f44336',
            }}
          >
            <MdDelete style={{ marginRight: 8, color: '#f44336' }} />
            <Typography variant="body1" color="#f44336">Delete</Typography>
          </MenuItem>,

          <Divider key="div" sx={{ my: 1, borderColor: 'var(--border)' }} />,

          <MenuItem
            key="record"
            onClick={() => {
              setSelectedIssueForTicket(currentIssue);
              setRecordTicketDialogOpen(true);
              handleMenuClose();
            }}
            sx={{
              '&:hover': {
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
              },
              '&.MuiMenuItem-root': {
                padding: '8px 16px',
              },
              color: '#10b981',
            }}
          >
            <MdHistory style={{ marginRight: 8, color: '#10b981' }} />
            <Typography variant="body1" color="#10b981">Record Transaction</Typography>
          </MenuItem>
        ]}
      </Menu>




      <CustomerIssueDialog
        open={openAddDialog}
        onClose={() => setOpenAddDialog(false)}
        onSubmit={handleIssueSubmit}
      />

      <CustomerIssueDialog
        open={openEditDialog}
        onClose={() => setOpenEditDialog(false)}
        onSubmit={handleIssueSubmit}
        issue={currentIssue}
      />

      <ViewIssueDetailsDialog
        open={openViewDialog}
        onClose={() => setOpenViewDialog(false)}
        issue={currentIssue}
        onUpdate={handleIssueSubmit}
        fullScreen={isMobile}
      />

      <GaiaStepsDialog
        open={gaiaStepsDialogOpen}
        onClose={() => {
          setGaiaStepsDialogOpen(false);
          setGaiaStepsTask(null);
        }}
        task={gaiaStepsTask}
      />


      <Dialog
        open={openDeleteDialog}
        onClose={() => setOpenDeleteDialog(false)}
        fullScreen={isMobile}
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this issue? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenDeleteDialog(false)}
            size={isMobile ? 'small' : 'medium'}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDeleteConfirm}
            variant="contained"
            color="error"
            size={isMobile ? 'small' : 'medium'}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Record Performance Ticket Dialog */}
      <RecordTicketDialog
        key={selectedIssueForTicket?._id || 'issue-ticket-dialog'}
        open={recordTicketDialogOpen}
        onClose={() => {
          setRecordTicketDialogOpen(false);
          setSelectedIssueForTicket(null);
        }}
        task={selectedIssueForTicket}
        taskType="CustomerIssue"
        onTicketAdded={() => fetchIssues(true)}
      />

      {/* Advanced Search Dialog */}
      <AdvancedSearch
        open={advancedSearchOpen}
        onClose={() => setAdvancedSearchOpen(false)}
        fields={advSearchFields}
        setFields={setAdvSearchFields}
        onInitiate={() => {
          setActiveAdvSearch(true);
          setAdvancedSearchOpen(false);
        }}
        onClear={() => {
          setAdvSearchFields({ slid: '', gaiaId: '', requestNumber: '', customerName: '', contactNumber: '', teamName: '' });
          setActiveAdvSearch(false);
          setAdvancedSearchOpen(false);
        }}
      />
    </Box >
  );
};

export default CustomerIssuesList;