import React, { useState, useMemo, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  useMediaQuery,
  Stack,
  FormControlLabel,
  Switch,
  TextField,
  Button
} from '@mui/material';
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarDensitySelector
} from '@mui/x-data-grid';
import { getAvailableWeeks, filterTasksByWeek, filterTasksByDateRange } from '../utils/dateFilterHelpers';
import api from '../api/api';
import { format, startOfWeek } from 'date-fns';
import { getCustomWeekNumber } from '../utils/helpers';
import * as XLSX from 'xlsx';
import { MdFileDownload, MdTrendingUp } from 'react-icons/md';
import { IconButton, Tooltip } from '@mui/material';
// import AIAnalysisButton from './AIAnalysisButton';
import ViolationDetailsDialog from './ViolationDetailsDialog';
import TrendsSummaryModal from './TrendsSummaryModal';
import { MdVisibility } from 'react-icons/md';

const CustomToolbar = () => {
  return (
    <GridToolbarContainer>
      <GridToolbarColumnsButton />
      <GridToolbarDensitySelector />
    </GridToolbarContainer>
  );
};

const WeeklySummaryTable = ({ tasks, fieldTeams = [] }) => {
  const isMobile = useMediaQuery('(max-width:503px)');
  const [selectedWeek, setSelectedWeek] = useState(null);
  const [isCustomRange, setIsCustomRange] = useState(false);
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  const [paginationModel, setPaginationModel] = useState({
    pageSize: 10,
    page: 0,
  });

  const [settings, setSettings] = useState(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await api.get("/settings");
        setSettings(response.data);
      } catch (err) {
        console.error("Error fetching settings:", err);
      }
    };
    fetchSettings();
  }, []);

  const weekStartDay = settings?.weekStartDay || 0;

  // Get available weeks from tasks
  const availableWeeks = useMemo(() => getAvailableWeeks(tasks, settings || {}), [tasks, settings]);

  // Set initial week to most recent
  useEffect(() => {
    if (availableWeeks.length > 0 && !isCustomRange) {
      const isValid = availableWeeks.some(w => w.key === selectedWeek);
      if (!selectedWeek || !isValid) {
        setSelectedWeek(availableWeeks[0].key);
      }
    }
  }, [availableWeeks, selectedWeek, isCustomRange]);


  // Filter tasks by selected week or custom range
  const filteredTasks = useMemo(() => {
    if (isCustomRange) {
      if (!customStart || !customEnd) return [];
      return filterTasksByDateRange(tasks, customStart, customEnd);
    } else {
      if (!selectedWeek) return [];
      const week = availableWeeks.find(w => w.key === selectedWeek);
      if (!week) return [];
      return filterTasksByWeek(tasks, week.year, week.week, settings || {});
    }
  }, [tasks, selectedWeek, availableWeeks, isCustomRange, customStart, customEnd, settings]);

  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [trendModalOpen, setTrendModalOpen] = useState(false);

  // Calculate violation data for each team
  const rows = useMemo(() => {
    const teamViolations = {};

    // Initialize all teams
    fieldTeams.forEach(team => {
      teamViolations[team.teamName] = {
        id: team._id,
        teamName: team.teamName,
        teamCompany: team.teamCompany || 'N/A',
        detractorCount: 0,
        neutralCount: 0,
        lowPriorityCount: 0,
        mediumPriorityCount: 0,
        highPriorityCount: 0,
        tasks: [] // Store tasks for this team
      };
    });

    // Count violations from filtered tasks
    filteredTasks.forEach(task => {
      const teamName = task.teamName;
      if (!teamViolations[teamName]) {
        teamViolations[teamName] = {
          id: `temp-${teamName}`,
          teamName,
          teamCompany: 'N/A',
          detractorCount: 0,
          neutralCount: 0,
          lowPriorityCount: 0,
          mediumPriorityCount: 0,
          highPriorityCount: 0,
          tasks: []
        };
      }

      // Add task to specific team list
      teamViolations[teamName].tasks.push(task);

      // Count by evaluation score
      if (task.evaluationScore >= 1 && task.evaluationScore <= 6) {
        teamViolations[teamName].detractorCount++;
      } else if (task.evaluationScore >= 7 && task.evaluationScore <= 8) {
        teamViolations[teamName].neutralCount++;
      }

      // Count by priority
      if (task.priority === 'Low') {
        teamViolations[teamName].lowPriorityCount++;
      } else if (task.priority === 'Medium') {
        teamViolations[teamName].mediumPriorityCount++;
      } else if (task.priority === 'High') {
        teamViolations[teamName].highPriorityCount++;
      }
    });

    // Calculate totals and equivalent detractors
    return Object.values(teamViolations).map(team => ({
      ...team,
      totalViolations: team.detractorCount + team.neutralCount,
      equivalentDetractorCount: team.detractorCount + Math.floor(team.neutralCount / 3),
    })).filter(team => team.totalViolations > 0).sort((a, b) => {
      if (b.totalViolations !== a.totalViolations) {
        return b.totalViolations - a.totalViolations;
      }
      return b.equivalentDetractorCount - a.equivalentDetractorCount;
    });
  }, [filteredTasks, fieldTeams]);

  const handleViewDetails = (row) => {
    setSelectedRowData(row);
    setDetailsOpen(true);
  };

  const columns = useMemo(() => [
    {
      field: 'teamName',
      headerName: 'Team Name',
      width: 200,
      renderCell: (params) => (
        <Typography sx={{ color: 'var(--text)', fontWeight: 500 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'teamCompany',
      headerName: 'Group',
      width: 100,
      renderCell: (params) => (
        <Typography variant="body2" sx={{ color: 'var(--text)' }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'slids',
      headerName: 'SLID(s)',
      width: 150,
      renderCell: (params) => {
        const slids = params.row.tasks.map(t => t.slid).filter(Boolean);
        const text = slids.join(', ');
        return (
          <Tooltip title={text} arrow>
            <span style={{
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: 'block'
            }}>
              {text || 'N/A'}
            </span>
          </Tooltip>
        );
      }
    },
    {
      field: 'detractorCount',
      headerName: 'Detractors',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#f44336' : '#6b7280', fontWeight: 'bold' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'neutralCount',
      headerName: 'Neutrals',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#ff9800' : '#6b7280', fontWeight: 'bold' }}>
          {params.value}
        </Box>
      ),
    },
    // {
    //   field: 'equivalentDetractorCount',
    //   headerName: 'Eq. Detractors',
    //   width: 140,
    //   renderCell: (params) => (
    //     <Box sx={{
    //       fontWeight: 'bold',
    //       color: params.value >= 3 ? '#f44336' :
    //         params.value === 2 ? '#ff9800' : '#4caf50'
    //     }}>
    //       {params.value}
    //     </Box>
    //   ),
    // },
    {
      field: 'totalViolations',
      headerName: 'Total Violations',
      width: 140,
      renderCell: (params) => (
        <Box sx={{
          fontWeight: 'bold',
          color: params.value > 0 ? '#f44336' : '#6b7280',
          backgroundColor: 'var(--surface-hover)',
          padding: '4px 8px',
          borderRadius: '4px'
        }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'lowPriorityCount',
      headerName: 'Low Impact',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#4caf50' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'mediumPriorityCount',
      headerName: 'Medium Impact',
      width: 140,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#ff9800' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'highPriorityCount',
      headerName: 'High Impact',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#f44336' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'actions',
      headerName: 'Details',
      width: 80,
      sortable: false,
      renderCell: (params) => (
        <Tooltip title="View Violation Details">
          <IconButton
            onClick={() => handleViewDetails(params.row)}
            size="small"
            sx={{ color: '#00e5ff' }}
          >
            <MdVisibility />
          </IconButton>
        </Tooltip>
      )
    }
  ], []);

  const exportToExcel = () => {
    if (!rows.length) return;

    let periodLabel = '';
    if (isCustomRange) {
      periodLabel = `Custom_${customStart}_to_${customEnd}`;
    } else {
      const week = availableWeeks.find(w => w.key === selectedWeek);
      periodLabel = week?.label.replace(/[^a-z0-9]/gi, '_');
    }

    const exportData = [];

    rows.forEach(row => {
      // Base summary data that repeats for every task of this team
      const teamSummary = {
        'Team Name': row.teamName,
        'Group': row.teamCompany,
        'Detractors (Count)': row.detractorCount,
        'Neutrals (Count)': row.neutralCount,
        // 'Eq. Detractors': row.equivalentDetractorCount,
        'Total Violations': row.totalViolations,
        'Low Impact (Count)': row.lowPriorityCount,
        'Medium Impact (Count)': row.mediumPriorityCount,
        'High Impact (Count)': row.highPriorityCount,
      };

      // Only export teams that have violations/tasks in the selected period
      if (row.tasks && row.tasks.length > 0) {
        row.tasks.forEach(task => {
          let weekStr = 'N/A';
          let dateStr = 'N/A';

          if (task.interviewDate) {
            try {
              const date = new Date(task.interviewDate);
              const start = startOfWeek(date, { weekStartsOn: weekStartDay });
              weekStr = `W${getCustomWeekNumber(start, start.getFullYear(), settings || {})}`;
              dateStr = format(date, 'yyyy-MM-dd');
            } catch (e) {
              // ignore
            }
          }

          exportData.push({
            'Team Name': teamSummary['Team Name'],
            'Group': teamSummary['Group'],
            'Week': weekStr,
            'Interview Date': dateStr,
            'SLID': task.slid || 'N/A',
            'Customer Feedback': task.customerFeedback || '',
            'Score': task.evaluationScore,
            'Impact': task.priority,
            'Detractors': teamSummary['Detractors (Count)'],
            'Neutrals': teamSummary['Neutrals (Count)'],
            // 'Eq. Detractors': teamSummary['Eq. Detractors'],
            'Total Violations': teamSummary['Total Violations'],
            'Low Impact': teamSummary['Low Impact (Count)'],
            'Medium Impact': teamSummary['Medium Impact (Count)'],
            'High Impact': teamSummary['High Impact (Count)'],
          });
        });
      }
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Weekly Summary');
    const fileName = `Weekly_Summary_${periodLabel}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(workbook, fileName, { compression: true });
  };

  return (
    <Box sx={{ my: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, flexDirection: isMobile ? 'column' : 'row' }}>
        <Typography variant="h6" sx={{ color: '#c2c2c2', fontWeight: 'bold' }}>
          Weekly Summary Table
        </Typography>

        <Box sx={{ display: 'flex', gap: 2, width: isMobile ? '100%' : 'auto', flexWrap: 'wrap' }}>

          <FormControlLabel
            control={
              <Switch
                checked={isCustomRange}
                onChange={(e) => setIsCustomRange(e.target.checked)}
                color="secondary"
              />
            }
            label="Custom Date Range"
            sx={{ color: 'var(--text)', whiteSpace: 'nowrap', width: isMobile ? '100%' : 'auto', m: 0 }}
          />

          <Stack
            direction="row"
            spacing={1}
            alignItems="center"
            sx={{ width: isMobile ? '100%' : 'auto', flexWrap: 'nowrap' }}
          >
            {!isCustomRange ? (
              <FormControl sx={{ flex: 1, minWidth: isMobile ? 0 : 200 }} size="small">
                <InputLabel sx={{ color: 'var(--text-secondary)' }}>Select Week</InputLabel>
                <Select
                  value={selectedWeek || ''}
                  onChange={(e) => setSelectedWeek(e.target.value)}
                  label="Select Week"
                  sx={{
                    backgroundColor: 'var(--surface)',
                    color: 'var(--text)',
                    '& .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                    '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                    '& .MuiSvgIcon-root': { color: 'var(--text-secondary)' },
                  }}
                >
                  {availableWeeks.map((week) => (
                    <MenuItem key={week.key} value={week.key}>
                      {week.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            ) : (
              <Box sx={{ display: 'flex', gap: 1, flex: 1 }}>
                <TextField
                  type="date"
                  label="From"
                  fullWidth
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  InputLabelProps={{ shrink: true, style: { color: 'var(--text-secondary)' } }}
                  size="small"
                  sx={{
                    input: { color: 'var(--text)', fontSize: isMobile ? '0.75rem' : 'inherit' },
                    fieldset: { borderColor: 'var(--border)' },
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#777' },
                      '&.Mui-focused fieldset': { borderColor: 'var(--accent)' }
                    }
                  }}
                />
                <TextField
                  type="date"
                  label="To"
                  fullWidth
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  InputLabelProps={{ shrink: true, style: { color: 'var(--text-secondary)' } }}
                  size="small"
                  sx={{
                    input: { color: 'var(--text)', fontSize: isMobile ? '0.75rem' : 'inherit' },
                    fieldset: { borderColor: 'var(--border)' },
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#777' },
                      '&.Mui-focused fieldset': { borderColor: 'var(--accent)' }
                    }
                  }}
                />
              </Box>
            )}

            <Stack direction="row" spacing={0.5}>
              <Tooltip title="Export to Excel">
                <IconButton
                  onClick={exportToExcel}
                  disabled={!rows.length}
                  size="small"
                  sx={{
                    color: '#4caf50',
                    backgroundColor: 'rgba(76, 175, 80, 0.05)',
                    '&:hover': { backgroundColor: 'rgba(76, 175, 80, 0.15)' },
                    '&.Mui-disabled': { color: 'var(--text-muted)' }
                  }}
                >
                  <MdFileDownload fontSize="20px" />
                </IconButton>
              </Tooltip>

              <Tooltip title="View Weekly Trends">
                <IconButton
                  onClick={() => setTrendModalOpen(true)}
                  size="small"
                  sx={{
                    color: 'var(--accent-text)',
                    backgroundColor: 'rgba(123, 104, 238, 0.05)',
                    '&:hover': { backgroundColor: 'rgba(123, 104, 238, 0.15)' }
                  }}
                >
                  <MdTrendingUp fontSize="20px" />
                </IconButton>
              </Tooltip>
            </Stack>
          </Stack>

          {/* <AIAnalysisButton
            data={rows}
            title={`Weekly Summary - ${selectedWeek ? availableWeeks.find(w => w.key === selectedWeek)?.label : 'Custom Range'}`}
            context={`Detailed weekly performance analysis for ${rows.length} teams. Period: ${selectedWeek ? availableWeeks.find(w => w.key === selectedWeek)?.label : 'Custom Range'}`}
          /> */}
        </Box>
      </Box>

      <Paper sx={{ height: 400, width: '100%', backgroundColor: 'var(--surface)' }}>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSizeOptions={[5, 10, 25]}
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          disableSelectionOnClick
          slots={{ toolbar: CustomToolbar }}
          sx={{
            border: 0,
            color: 'var(--text)',
            '& .MuiDataGrid-main': { backgroundColor: 'var(--surface)' },
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: 'var(--surface)',
              color: 'var(--text-secondary)',
              fontSize: '0.875rem',
              fontWeight: 'bold',
              borderBottom: '1px solid var(--border)',
            },
            '& .MuiDataGrid-container--top [role=row]': {
              backgroundColor: '#3f3f3f'
            },
            '& .MuiDataGrid-cell': { borderBottom: '1px solid var(--border)' },
            '& .MuiDataGrid-row': {
              backgroundColor: 'var(--surface)',
              '&:hover': { backgroundColor: 'var(--surface-hover)' },
            },
            '& .MuiDataGrid-footerContainer': {
              backgroundColor: 'var(--surface)',
              color: 'var(--text)',
              borderTop: '1px solid var(--border)',
            },
            '& .MuiTablePagination-root': { color: 'var(--text)' },
            '& .MuiDataGrid-columnHeaderTitle': {
              fontWeight: 'bold',
            },
          }}
        />
      </Paper>

      {selectedRowData && (
        <ViolationDetailsDialog
          open={detailsOpen}
          onClose={() => setDetailsOpen(false)}
          title={`Detailed Violations - ${selectedRowData.teamName}`}
          teamName={selectedRowData.teamName}
          tasks={selectedRowData.tasks}
        />
      )}

      <TrendsSummaryModal
        open={trendModalOpen}
        onClose={() => setTrendModalOpen(false)}
        tasks={tasks}
        period="week"
      />
    </Box>
  );
};

export default React.memo(WeeklySummaryTable);
