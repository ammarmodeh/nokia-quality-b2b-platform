import React, { useState, useMemo, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  useMediaQuery,
  Stack,
  FormControlLabel,
  Switch,
  TextField,
  Button
} from '@mui/material';
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarDensitySelector
} from '@mui/x-data-grid';
import { getAvailableMonths, filterTasksByMonth, filterTasksByDateRange } from '../utils/dateFilterHelpers';
import { format, startOfWeek } from 'date-fns';
import { getCustomWeekNumber } from '../utils/helpers';
import * as XLSX from 'xlsx';
import { MdFileDownload, MdTrendingUp } from 'react-icons/md';
import { IconButton, Tooltip } from '@mui/material';
// import AIAnalysisButton from './AIAnalysisButton';
import ViolationDetailsDialog from './ViolationDetailsDialog';
import TrendsSummaryModal from './TrendsSummaryModal';
import { MdVisibility } from 'react-icons/md';
import api from '../api/api';

const CustomToolbar = () => {
  return (
    <GridToolbarContainer>
      <GridToolbarColumnsButton />
      <GridToolbarDensitySelector />
    </GridToolbarContainer>
  );
};

const MonthlySummaryTable = ({ tasks, fieldTeams = [] }) => {
  const isMobile = useMediaQuery('(max-width:503px)');
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [isCustomRange, setIsCustomRange] = useState(false);
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  const [paginationModel, setPaginationModel] = useState({
    pageSize: 10,
    page: 0,
  });

  const [settings, setSettings] = useState(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await api.get("/settings");
        setSettings(response.data);
      } catch (err) {
        console.error("Error fetching settings:", err);
      }
    };
    fetchSettings();
  }, []);

  const weekStartDay = settings?.weekStartDay || 0;

  // Get available months from tasks
  const availableMonths = useMemo(() => getAvailableMonths(tasks, settings || {}), [tasks, settings]);

  // Set initial month to most recent
  useEffect(() => {
    if (availableMonths.length > 0 && !isCustomRange) {
      const isValid = availableMonths.some(m => m.key === selectedMonth);
      if (!selectedMonth || !isValid) {
        setSelectedMonth(availableMonths[0].key);
      }
    }
  }, [availableMonths, selectedMonth, isCustomRange]);


  // Filter tasks by selected month or custom range
  const filteredTasks = useMemo(() => {
    if (isCustomRange) {
      if (!customStart || !customEnd) return [];
      return filterTasksByDateRange(tasks, customStart, customEnd);
    } else {
      if (!selectedMonth) return [];
      const month = availableMonths.find(m => m.key === selectedMonth);
      if (!month) return [];
      return filterTasksByMonth(tasks, month.year, month.month, settings || {});
    }
  }, [tasks, selectedMonth, availableMonths, isCustomRange, customStart, customEnd, settings]);

  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [trendModalOpen, setTrendModalOpen] = useState(false);

  const [samplesTokenData, setSamplesTokenData] = useState({});

  // Fetch samples token data (same fix as TeamViolationTracker)
  useEffect(() => {
    const fetchSamplesData = async () => {
      try {
        const yearsToFetch = new Set();
        const currentYear = new Date().getFullYear();
        yearsToFetch.add(currentYear);

        tasks.forEach(task => {
          if (task.interviewDate) {
            yearsToFetch.add(new Date(task.interviewDate).getFullYear());
          }
        });

        const promises = Array.from(yearsToFetch).map(year =>
          api.get(`/samples-token/${year}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
          }).then(res => ({ year, data: res.data || [] }))
            .catch(err => {
              console.error(`Error fetching samples for ${year}:`, err);
              return { year, data: [] };
            })
        );

        const results = await Promise.all(promises);
        const newData = {};
        results.forEach(({ year, data }) => {
          newData[year] = {};
          data.forEach(item => {
            newData[year][`W${item.weekNumber}`] = item;
          });
        });

        setSamplesTokenData(newData);
      } catch (error) {
        console.error("Error fetching samples token data:", error);
      }
    };

    fetchSamplesData();
  }, [tasks]);

  // Calculate total samples from fetched state based on weeks in the current filtered view
  const totalMonthlySamples = useMemo(() => {
    if (!filteredTasks.length) return 0;

    try {
      // ── Priority 1: Manually-entered monthly total ──
      // Only apply this logic if we are viewing a single month (not custom range)
      if (!isCustomRange && selectedMonth) {
        const monthNumMatch = selectedMonth.match(/Month-(\d+)/);
        if (monthNumMatch) {
          const mNum = parseInt(monthNumMatch[1], 10);
          const targetWeekNumber = 100 + mNum;
          
          // Try to find it in the fetched years
          const availableYears = Object.keys(samplesTokenData);
          for (let y of availableYears) {
            const manualRecord = samplesTokenData[y][`W${targetWeekNumber}`];
            if (manualRecord && Number(manualRecord.sampleSize) > 0) {
               return Number(manualRecord.sampleSize);
            }
          }
        }
      }

      // ── Priority 2: Fallback to summing individual weeks ──
      const uniqueWeeks = new Set();

      filteredTasks.forEach(task => {
        if (task.interviewDate) {
          const date = new Date(task.interviewDate);
          const start = startOfWeek(date, { weekStartsOn: weekStartDay });
          const year = start.getFullYear();
          const weekNum = getCustomWeekNumber(start, year, settings || {}); // Use existing helper
          // Exclude our manual month markers (101-112)
          if (weekNum <= 100) {
            uniqueWeeks.add(`${year}-W${weekNum}`);
          }
        }
      });

      let total = 0;
      uniqueWeeks.forEach(key => {
        const [year, weekKey] = key.split('-');
        if (samplesTokenData[year] && samplesTokenData[year][weekKey]) {
          total += parseFloat(samplesTokenData[year][weekKey].sampleSize) || 0;
        }
      });

      return total;
    } catch (error) {
      console.error("Error calculating total samples:", error);
      return 0;
    }
  }, [filteredTasks, samplesTokenData, isCustomRange, selectedMonth, settings, weekStartDay]);

  // Calculate violation data for each team
  const rows = useMemo(() => {
    const teamViolations = {};

    // Initialize all teams
    fieldTeams.forEach(team => {
      teamViolations[team.teamName] = {
        id: team._id,
        teamName: team.teamName,
        teamCompany: team.teamCompany || 'N/A',
        detractorCount: 0,
        neutralCount: 0,
        lowPriorityCount: 0,
        mediumPriorityCount: 0,
        highPriorityCount: 0,
        tasks: [] // Store tasks for this team
      };
    });

    // Count violations from filtered tasks
    filteredTasks.forEach(task => {
      const teamName = task.teamName;
      if (!teamViolations[teamName]) {
        teamViolations[teamName] = {
          id: `temp-${teamName}`,
          teamName,
          teamCompany: 'N/A',
          detractorCount: 0,
          neutralCount: 0,
          lowPriorityCount: 0,
          mediumPriorityCount: 0,
          highPriorityCount: 0,
          tasks: []
        };
      }

      // Add task to specific team list
      teamViolations[teamName].tasks.push(task);

      // Count by evaluation score
      if (task.evaluationScore >= 1 && task.evaluationScore <= 6) {
        teamViolations[teamName].detractorCount++;
      } else if (task.evaluationScore >= 7 && task.evaluationScore <= 8) {
        teamViolations[teamName].neutralCount++;
      }

      // Count by priority
      if (task.priority === 'Low') {
        teamViolations[teamName].lowPriorityCount++;
      } else if (task.priority === 'Medium') {
        teamViolations[teamName].mediumPriorityCount++;
      } else if (task.priority === 'High') {
        teamViolations[teamName].highPriorityCount++;
      }
    });

    // Calculate totals and rates
    return Object.values(teamViolations).map(team => {
      // Safe denominator to avoid NaN/Infinity
      const denominator = totalMonthlySamples > 0 ? totalMonthlySamples : 1;

      const detractorRate = totalMonthlySamples > 0 ? ((team.detractorCount / denominator) * 100).toFixed(1) : '0.0';
      const neutralRate = totalMonthlySamples > 0 ? ((team.neutralCount / denominator) * 100).toFixed(1) : '0.0';

      return {
        ...team,
        totalViolations: team.detractorCount + team.neutralCount,
        detractorRate,
        neutralRate
      };
    }).filter(team => team.totalViolations > 0).sort((a, b) => {
      // Sort by Detractor Rate descending, then Neutral Rate descending
      const detA = parseFloat(a.detractorRate);
      const detB = parseFloat(b.detractorRate);
      if (detB !== detA) return detB - detA;
      return parseFloat(b.neutralRate) - parseFloat(a.neutralRate);
    });
  }, [filteredTasks, fieldTeams, totalMonthlySamples]);

  const handleViewDetails = (row) => {
    setSelectedRowData(row);
    setDetailsOpen(true);
  };

  const columns = useMemo(() => [
    {
      field: 'teamName',
      headerName: 'Team Name',
      width: 200,
      renderCell: (params) => (
        <Typography sx={{ color: 'var(--text)', fontWeight: 500 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'teamCompany',
      headerName: 'Group',
      width: 100,
      renderCell: (params) => (
        <Typography variant="body2" sx={{ color: 'var(--text)' }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'slids',
      headerName: 'SLID(s)',
      width: 150,
      renderCell: (params) => {
        const slids = params.row.tasks.map(t => t.slid).filter(Boolean);
        const text = slids.join(', ');
        return (
          <Tooltip title={text} arrow>
            <span style={{
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: 'block'
            }}>
              {text || 'N/A'}
            </span>
          </Tooltip>
        );
      }
    },
    {
      field: 'detractorCount',
      headerName: 'Detractors',
      width: 100,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#f44336' : '#6b7280', fontWeight: 'bold' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'detractorRate',
      headerName: 'Detractor %',
      width: 120,
      renderCell: (params) => {
        const val = parseFloat(params.value);
        const isHigh = val > 9;
        return (
          <Box sx={{
            color: isHigh ? '#f44336' : '#4caf50',
            fontWeight: 'bold',
            border: isHigh ? '1px solid #f44336' : '1px solid transparent',
            borderRadius: '4px',
            padding: '2px 6px',
            backgroundColor: isHigh ? 'rgba(244, 67, 54, 0.1)' : 'transparent'
          }}>
            {params.value}%
          </Box>
        );
      },
    },
    {
      field: 'neutralCount',
      headerName: 'Neutrals',
      width: 100,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#ff9800' : '#6b7280', fontWeight: 'bold' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'neutralRate',
      headerName: 'Neutral %',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: 'var(--text)', fontWeight: '500' }}>
          {params.value}%
        </Box>
      ),
    },
    {
      field: 'totalViolations',
      headerName: 'Total Violations',
      width: 140,
      renderCell: (params) => (
        <Box sx={{
          fontWeight: 'bold',
          color: params.value > 0 ? '#f44336' : '#6b7280',
          backgroundColor: 'var(--surface-hover)',
          padding: '4px 8px',
          borderRadius: '4px'
        }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'lowPriorityCount',
      headerName: 'Low Impact',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#4caf50' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'mediumPriorityCount',
      headerName: 'Medium Impact',
      width: 140,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#ff9800' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'highPriorityCount',
      headerName: 'High Impact',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#f44336' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'actions',
      headerName: 'Details',
      width: 80,
      sortable: false,
      renderCell: (params) => (
        <Tooltip title="View Violation Details">
          <IconButton
            onClick={() => handleViewDetails(params.row)}
            size="small"
            sx={{ color: '#00e5ff' }}
          >
            <MdVisibility />
          </IconButton>
        </Tooltip>
      )
    }
  ], []);

  const exportToExcel = () => {
    if (!rows.length) return;

    let periodLabel = '';
    if (isCustomRange) {
      periodLabel = `Custom_${customStart}_to_${customEnd}`;
    } else {
      const month = availableMonths.find(m => m.key === selectedMonth);
      periodLabel = month?.label.replace(/[^a-z0-9]/gi, '_');
    }

    const exportData = [];

    rows.forEach(row => {
      // Base summary data
      const teamSummary = {
        'Team Name': row.teamName,
        'Group': row.teamCompany,
        'Detractors (Count)': row.detractorCount,
        'Detractor Rate (%)': `${row.detractorRate}%`,
        'Neutrals (Count)': row.neutralCount,
        'Neutral Rate (%)': `${row.neutralRate}%`,
        'Total Violations': row.totalViolations,
        'Low Impact (Count)': row.lowPriorityCount,
        'Medium Impact (Count)': row.mediumPriorityCount,
        'High Impact (Count)': row.highPriorityCount,
        'Global Sample Size': totalMonthlySamples
      };

      // Only export teams that have violations/tasks in the selected period
      if (row.tasks && row.tasks.length > 0) {
        row.tasks.forEach(task => {
          let weekStr = 'N/A';
          let dateStr = 'N/A';

          if (task.interviewDate) {
            try {
              const date = new Date(task.interviewDate);
              const start = startOfWeek(date, { weekStartsOn: weekStartDay });
              weekStr = `W${getCustomWeekNumber(start, start.getFullYear(), settings || {})}`;
              dateStr = format(date, 'yyyy-MM-dd');
            } catch (e) {
              // ignore
            }
          }

          exportData.push({
            'Team Name': teamSummary['Team Name'],
            'Group': teamSummary['Group'],
            'Week': weekStr,
            'Interview Date': dateStr,
            'SLID': task.slid || 'N/A',
            'Customer Feedback': task.customerFeedback || '',
            'Score': task.evaluationScore,
            'Impact': task.priority,
            'Detractors': teamSummary['Detractors (Count)'],
            'Detractor Rate (%)': teamSummary['Detractor Rate (%)'],
            'Neutrals': teamSummary['Neutrals (Count)'],
            'Neutral Rate (%)': teamSummary['Neutral Rate (%)'],
            'Total Violations': teamSummary['Total Violations'],
            'Low Impact': teamSummary['Low Impact (Count)'],
            'Medium Impact': teamSummary['Medium Impact (Count)'],
            'High Impact': teamSummary['High Impact (Count)'],
            'Global Sample Size': teamSummary['Global Sample Size']
          });
        });
      }
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Monthly Summary');
    const fileName = `Monthly_Summary_${periodLabel}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(workbook, fileName, { compression: true });
  };

  return (
    <Box sx={{ my: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, flexDirection: isMobile ? 'column' : 'row' }}>
        <Typography variant="h6" sx={{ color: '#c2c2c2', fontWeight: 'bold' }}>
          Monthly Summary Table
        </Typography>

        <Box sx={{ display: 'flex', gap: 2, width: isMobile ? '100%' : 'auto', flexWrap: 'wrap' }}>

          <FormControlLabel
            control={
              <Switch
                checked={isCustomRange}
                onChange={(e) => setIsCustomRange(e.target.checked)}
                color="secondary"
              />
            }
            label="Custom Date Range"
            sx={{ color: 'var(--text)', whiteSpace: 'nowrap', width: isMobile ? '100%' : 'auto', m: 0 }}
          />

          <Stack
            direction="row"
            spacing={1}
            alignItems="center"
            sx={{ width: isMobile ? '100%' : 'auto', flexWrap: 'nowrap' }}
          >
            {!isCustomRange ? (
              <FormControl sx={{ flex: 1, minWidth: isMobile ? 0 : 200 }} size="small">
                <InputLabel sx={{ color: 'var(--text-secondary)' }}>Select Month</InputLabel>
                <Select
                  value={selectedMonth || ''}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  label="Select Month"
                  sx={{
                    backgroundColor: 'var(--surface)',
                    color: 'var(--text)',
                    '& .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                    '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                    '& .MuiSvgIcon-root': { color: 'var(--text-secondary)' },
                  }}
                >
                  {availableMonths.map((month) => (
                    <MenuItem key={month.key} value={month.key}>
                      {month.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            ) : (
              <Box sx={{ display: 'flex', gap: 1, flex: 1 }}>
                <TextField
                  type="date"
                  label="From"
                  fullWidth
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  InputLabelProps={{ shrink: true, style: { color: 'var(--text-secondary)' } }}
                  size="small"
                  sx={{
                    input: { color: 'var(--text)', fontSize: isMobile ? '0.75rem' : 'inherit' },
                    fieldset: { borderColor: 'var(--border)' },
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#777' },
                      '&.Mui-focused fieldset': { borderColor: 'var(--accent)' }
                    }
                  }}
                />
                <TextField
                  type="date"
                  label="To"
                  fullWidth
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  InputLabelProps={{ shrink: true, style: { color: 'var(--text-secondary)' } }}
                  size="small"
                  sx={{
                    input: { color: 'var(--text)', fontSize: isMobile ? '0.75rem' : 'inherit' },
                    fieldset: { borderColor: 'var(--border)' },
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#777' },
                      '&.Mui-focused fieldset': { borderColor: 'var(--accent)' }
                    }
                  }}
                />
              </Box>
            )}

            <Stack direction="row" spacing={0.5}>
              <Tooltip title="Export to Excel">
                <IconButton
                  onClick={exportToExcel}
                  disabled={!rows.length}
                  size="small"
                  sx={{
                    color: '#4caf50',
                    backgroundColor: 'rgba(76, 175, 80, 0.05)',
                    '&:hover': { backgroundColor: 'rgba(76, 175, 80, 0.15)' },
                    '&.Mui-disabled': { color: 'var(--text-muted)' }
                  }}
                >
                  <MdFileDownload fontSize="20px" />
                </IconButton>
              </Tooltip>

              <Tooltip title="View Monthly Trends">
                <IconButton
                  onClick={() => setTrendModalOpen(true)}
                  size="small"
                  sx={{
                    color: 'var(--accent-text)',
                    backgroundColor: 'rgba(123, 104, 238, 0.05)',
                    '&:hover': { backgroundColor: 'rgba(123, 104, 238, 0.15)' }
                  }}
                >
                  <MdTrendingUp fontSize="20px" />
                </IconButton>
              </Tooltip>
            </Stack>
          </Stack>

          {/* <AIAnalysisButton
            data={rows}
            title={`Monthly Summary - ${selectedMonth ? availableMonths.find(m => m.key === selectedMonth)?.label : 'Custom Range'}`}
            context={`Detailed monthly performance analysis for ${rows.length} teams. Period: ${selectedMonth ? availableMonths.find(m => m.key === selectedMonth)?.label : 'Custom Range'}`}
          /> */}
        </Box>
      </Box>

      <Paper sx={{ height: 400, width: '100%', backgroundColor: 'var(--surface)' }}>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSizeOptions={[5, 10, 25]}
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          disableSelectionOnClick
          slots={{ toolbar: CustomToolbar }}
          sx={{
            border: 0,
            color: 'var(--text)',
            '& .MuiDataGrid-main': { backgroundColor: 'var(--surface)' },
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: 'var(--surface)',
              color: 'var(--text-secondary)',
              fontSize: '0.875rem',
              fontWeight: 'bold',
              borderBottom: '1px solid var(--border)',
            },
            '& .MuiDataGrid-container--top [role=row]': {
              backgroundColor: '#3f3f3f'
            },
            '& .MuiDataGrid-cell': { borderBottom: '1px solid var(--border)' },
            '& .MuiDataGrid-row': {
              backgroundColor: 'var(--surface)',
              '&:hover': { backgroundColor: 'var(--surface-hover)' },
            },
            '& .MuiDataGrid-footerContainer': {
              backgroundColor: 'var(--surface)',
              color: 'var(--text)',
              borderTop: '1px solid var(--border)',
            },
            '& .MuiTablePagination-root': { color: 'var(--text)' },
            '& .MuiDataGrid-columnHeaderTitle': {
              fontWeight: 'bold',
            },
          }}
        />
      </Paper>

      {selectedRowData && (
        <ViolationDetailsDialog
          open={detailsOpen}
          onClose={() => setDetailsOpen(false)}
          title={`Detailed Violations - ${selectedRowData.teamName}`}
          teamName={selectedRowData.teamName}
          tasks={selectedRowData.tasks}
        />
      )}

      <TrendsSummaryModal
        open={trendModalOpen}
        onClose={() => setTrendModalOpen(false)}
        tasks={tasks}
        period="month"
      />
    </Box>
  );
};

export default React.memo(MonthlySummaryTable);
