import { useState, useMemo, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  useMediaQuery,
  Stack,
  FormControlLabel,
  Switch,
  TextField,
  Button
} from '@mui/material';
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarDensitySelector
} from '@mui/x-data-grid';
import { getAvailableMonths, filterTasksByMonth, filterTasksByDateRange } from '../utils/dateFilterHelpers';
import { format, startOfWeek } from 'date-fns';
import { getCustomWeekNumber } from '../utils/helpers';
import * as XLSX from 'xlsx';
import { MdFileDownload, MdTrendingUp } from 'react-icons/md';
import { IconButton, Tooltip } from '@mui/material';
import ViolationDetailsDialog from './ViolationDetailsDialog';
import TrendsSummaryModal from './TrendsSummaryModal';
import { MdVisibility } from 'react-icons/md';
import api from '../api/api';

const CustomToolbar = () => {
  return (
    <GridToolbarContainer>
      <GridToolbarColumnsButton />
      <GridToolbarDensitySelector />
    </GridToolbarContainer>
  );
};

const MonthlyReasonTable = ({ tasks }) => {
  const isMobile = useMediaQuery('(max-width:503px)');
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [isCustomRange, setIsCustomRange] = useState(false);
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  const [paginationModel, setPaginationModel] = useState({
    pageSize: 10,
    page: 0,
  });

  const [settings, setSettings] = useState(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await api.get("/settings");
        setSettings(response.data);
      } catch (err) {
        console.error("Error fetching settings:", err);
      }
    };
    fetchSettings();
  }, []);

  const weekStartDay = settings?.weekStartDay || 0;

  // Get available months from tasks
  const availableMonths = useMemo(() => getAvailableMonths(tasks, settings || {}), [tasks, settings]);

  // Set initial month to most recent
  useEffect(() => {
    if (availableMonths.length > 0 && !isCustomRange) {
      const isValid = availableMonths.some(m => m.key === selectedMonth);
      if (!selectedMonth || !isValid) {
        setSelectedMonth(availableMonths[0].key);
      }
    }
  }, [availableMonths, selectedMonth, isCustomRange]);


  // Filter tasks by selected month or custom range
  const filteredTasks = useMemo(() => {
    if (isCustomRange) {
      if (!customStart || !customEnd) return [];
      return filterTasksByDateRange(tasks, customStart, customEnd);
    } else {
      if (!selectedMonth) return [];
      const month = availableMonths.find(m => m.key === selectedMonth);
      if (!month) return [];
      return filterTasksByMonth(tasks, month.year, month.month, settings || {});
    }
  }, [tasks, selectedMonth, availableMonths, isCustomRange, customStart, customEnd, settings]);

  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [trendModalOpen, setTrendModalOpen] = useState(false);

  // Calculate violation data for each reason
  const rows = useMemo(() => {
    const reasonViolations = {};

    // Count violations from filtered tasks
    filteredTasks.forEach(task => {
      const reason = task.reason || "Unspecified";
      if (!reasonViolations[reason]) {
        reasonViolations[reason] = {
          id: `reason-${reason}`,
          reason,
          detractorCount: 0,
          neutralCount: 0,
          lowPriorityCount: 0,
          mediumPriorityCount: 0,
          highPriorityCount: 0,
          tasks: []
        };
      }

      // Add task to specific reason list
      reasonViolations[reason].tasks.push(task);

      // Count by evaluation score
      if (task.evaluationScore >= 1 && task.evaluationScore <= 6) {
        reasonViolations[reason].detractorCount++;
      } else if (task.evaluationScore >= 7 && task.evaluationScore <= 8) {
        reasonViolations[reason].neutralCount++;
      }

      // Count by priority
      if (task.priority === 'Low') {
        reasonViolations[reason].lowPriorityCount++;
      } else if (task.priority === 'Medium') {
        reasonViolations[reason].mediumPriorityCount++;
      } else if (task.priority === 'High') {
        reasonViolations[reason].highPriorityCount++;
      }
    });

    // Calculate totals
    return Object.values(reasonViolations).map(item => ({
      ...item,
      totalViolations: item.detractorCount + item.neutralCount,
    })).sort((a, b) => b.totalViolations - a.totalViolations);
  }, [filteredTasks]);

  const handleViewDetails = (row) => {
    // Adapter for ViolationDetailsDialog which expects teamName
    // We'll pass reason as teamName for display purposes in the dialog title
    setSelectedRowData({
      ...row,
      teamName: row.reason
    });
    setDetailsOpen(true);
  };

  const columns = useMemo(() => [
    {
      field: 'reason',
      headerName: 'Reason',
      width: 250,
      renderCell: (params) => (
        <Typography sx={{ color: 'var(--text)', fontWeight: 500 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'detractorCount',
      headerName: 'Detractors',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#f44336' : '#6b7280', fontWeight: 'bold' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'neutralCount',
      headerName: 'Neutrals',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#ff9800' : '#6b7280', fontWeight: 'bold' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'totalViolations',
      headerName: 'Total Violations',
      width: 140,
      renderCell: (params) => (
        <Box sx={{
          fontWeight: 'bold',
          color: params.value > 0 ? '#f44336' : '#6b7280',
          backgroundColor: 'var(--surface-hover)',
          padding: '4px 8px',
          borderRadius: '4px'
        }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'lowPriorityCount',
      headerName: 'Low Impact',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#4caf50' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'mediumPriorityCount',
      headerName: 'Medium Impact',
      width: 140,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#ff9800' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'highPriorityCount',
      headerName: 'High Impact',
      width: 120,
      renderCell: (params) => (
        <Box sx={{ color: params.value > 0 ? '#f44336' : '#6b7280' }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: 'actions',
      headerName: 'Details',
      width: 80,
      sortable: false,
      renderCell: (params) => (
        <Tooltip title="View Violation Details">
          <IconButton
            onClick={() => handleViewDetails(params.row)}
            size="small"
            sx={{ color: '#00e5ff' }}
          >
            <MdVisibility />
          </IconButton>
        </Tooltip>
      )
    }
  ], []);

  const exportToExcel = () => {
    if (!rows.length) return;

    let periodLabel = '';
    if (isCustomRange) {
      periodLabel = `Custom_${customStart}_to_${customEnd}`;
    } else {
      const month = availableMonths.find(m => m.key === selectedMonth);
      periodLabel = month?.label.replace(/[^a-z0-9]/gi, '_');
    }

    const exportData = [];

    rows.forEach(row => {
      // Base summary data
      const reasonSummary = {
        'Reason': row.reason,
        'Detractors (Count)': row.detractorCount,
        'Neutrals (Count)': row.neutralCount,
        'Total Violations': row.totalViolations,
        'Low Impact (Count)': row.lowPriorityCount,
        'Medium Impact (Count)': row.mediumPriorityCount,
        'High Impact (Count)': row.highPriorityCount,
      };

      // Only export rows that have violations/tasks in the selected period
      if (row.tasks && row.tasks.length > 0) {
        row.tasks.forEach(task => {
          let weekStr = 'N/A';
          let dateStr = 'N/A';

          if (task.interviewDate) {
            try {
              const date = new Date(task.interviewDate);
              const start = startOfWeek(date, { weekStartsOn: weekStartDay });
              weekStr = `W${getCustomWeekNumber(start, start.getFullYear(), settings || {})}`;
              dateStr = format(date, 'yyyy-MM-dd');
            } catch (e) {
              // ignore
            }
          }

          exportData.push({
            'Reason': reasonSummary['Reason'],
            'Team Name': task.teamName || 'N/A',
            'Week': weekStr,
            'Interview Date': dateStr,
            'SLID': task.slid || 'N/A',
            'Customer Feedback': task.customerFeedback || '',
            'Score': task.evaluationScore,
            'Impact': task.priority,
            'Detractors': reasonSummary['Detractors (Count)'],
            'Neutrals': reasonSummary['Neutrals (Count)'],
            'Total Violations': reasonSummary['Total Violations'],
            'Low Impact': reasonSummary['Low Impact (Count)'],
            'Medium Impact': reasonSummary['Medium Impact (Count)'],
            'High Impact': reasonSummary['High Impact (Count)'],
          });
        });
      }
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Monthly Reason Summary');
    const fileName = `Monthly_Reason_Summary_${periodLabel}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(workbook, fileName, { compression: true });
  };

  return (
    <Box sx={{ my: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, flexDirection: isMobile ? 'column' : 'row' }}>
        <Typography variant="h6" sx={{ color: '#c2c2c2', fontWeight: 'bold' }}>
          Monthly Reason Analysis
        </Typography>

        <Box sx={{ display: 'flex', gap: 2, width: isMobile ? '100%' : 'auto', flexWrap: 'wrap' }}>

          <FormControlLabel
            control={
              <Switch
                checked={isCustomRange}
                onChange={(e) => setIsCustomRange(e.target.checked)}
                color="secondary"
              />
            }
            label="Custom Date Range"
            sx={{ color: 'var(--text)', whiteSpace: 'nowrap' }}
          />

          <Stack
            direction="row"
            spacing={1}
            alignItems="center"
            sx={{ width: isMobile ? '100%' : 'auto', flexWrap: 'nowrap' }}
          >
            {!isCustomRange ? (
              <FormControl sx={{ flex: 1, minWidth: isMobile ? 0 : 200 }} size="small">
                <InputLabel sx={{ color: 'var(--text-secondary)' }}>Select Month</InputLabel>
                <Select
                  value={selectedMonth || ''}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  label="Select Month"
                  sx={{
                    backgroundColor: 'var(--surface)',
                    color: 'var(--text)',
                    '& .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                    '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--border)' },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'var(--accent)' },
                    '& .MuiSvgIcon-root': { color: 'var(--text-secondary)' },
                  }}
                >
                  {availableMonths.map((month) => (
                    <MenuItem key={month.key} value={month.key}>
                      {month.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            ) : (
              <Box sx={{ display: 'flex', gap: 1, flex: 1 }}>
                <TextField
                  type="date"
                  label="From"
                  fullWidth
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  InputLabelProps={{ shrink: true, style: { color: 'var(--text-secondary)' } }}
                  size="small"
                  sx={{
                    input: { color: 'var(--text)', fontSize: isMobile ? '0.75rem' : 'inherit' },
                    fieldset: { borderColor: 'var(--border)' },
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#777' },
                      '&.Mui-focused fieldset': { borderColor: 'var(--accent)' }
                    }
                  }}
                />
                <TextField
                  type="date"
                  label="To"
                  fullWidth
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  InputLabelProps={{ shrink: true, style: { color: 'var(--text-secondary)' } }}
                  size="small"
                  sx={{
                    input: { color: 'var(--text)', fontSize: isMobile ? '0.75rem' : 'inherit' },
                    fieldset: { borderColor: 'var(--border)' },
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#777' },
                      '&.Mui-focused fieldset': { borderColor: 'var(--accent)' }
                    }
                  }}
                />
              </Box>
            )}

            <Stack direction="row" spacing={0.5}>
              <Tooltip title="Export to Excel">
                <IconButton
                  onClick={exportToExcel}
                  disabled={!rows.length}
                  size="small"
                  sx={{
                    color: '#4caf50',
                    backgroundColor: 'rgba(76, 175, 80, 0.05)',
                    '&:hover': { backgroundColor: 'rgba(76, 175, 80, 0.15)' },
                    '&.Mui-disabled': { color: 'var(--text-muted)' }
                  }}
                >
                  <MdFileDownload fontSize="20px" />
                </IconButton>
              </Tooltip>

              <Tooltip title="View Monthly Trends">
                <IconButton
                  onClick={() => setTrendModalOpen(true)}
                  size="small"
                  sx={{
                    color: 'var(--accent-text)',
                    backgroundColor: 'rgba(123, 104, 238, 0.05)',
                    '&:hover': { backgroundColor: 'rgba(123, 104, 238, 0.15)' }
                  }}
                >
                  <MdTrendingUp fontSize="20px" />
                </IconButton>
              </Tooltip>
            </Stack>
          </Stack>
        </Box>
      </Box>

      <Paper sx={{ height: 400, width: '100%', backgroundColor: 'var(--surface)' }}>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSizeOptions={[5, 10, 25]}
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          disableSelectionOnClick
          slots={{ toolbar: CustomToolbar }}
          sx={{
            border: 0,
            color: 'var(--text)',
            '& .MuiDataGrid-main': { backgroundColor: 'var(--surface)' },
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: 'var(--surface)',
              color: 'var(--text-secondary)',
              fontSize: '0.875rem',
              fontWeight: 'bold',
              borderBottom: '1px solid var(--border)',
            },
            '& .MuiDataGrid-container--top [role=row]': {
              backgroundColor: '#3f3f3f'
            },
            '& .MuiDataGrid-cell': { borderBottom: '1px solid var(--border)' },
            '& .MuiDataGrid-row': {
              backgroundColor: 'var(--surface)',
              '&:hover': { backgroundColor: 'var(--surface-hover)' },
            },
            '& .MuiDataGrid-footerContainer': {
              backgroundColor: 'var(--surface)',
              color: 'var(--text)',
              borderTop: '1px solid var(--border)',
            },
            '& .MuiTablePagination-root': { color: 'var(--text)' },
            '& .MuiDataGrid-columnHeaderTitle': {
              fontWeight: 'bold',
            },
          }}
        />
      </Paper>

      {selectedRowData && (
        <ViolationDetailsDialog
          open={detailsOpen}
          onClose={() => setDetailsOpen(false)}
          title={`Detailed Violations - ${selectedRowData.reason}`}
          teamName={selectedRowData.reason} // Passing reason as teamName specifically for this dialog reuse
          tasks={selectedRowData.tasks}
        />
      )}

      {/* <TrendsSummaryModal
        open={trendModalOpen}
        onClose={() => setTrendModalOpen(false)}
        tasks={tasks}
        period="month"
      /> */}
    </Box>
  );
};

export default MonthlyReasonTable;
