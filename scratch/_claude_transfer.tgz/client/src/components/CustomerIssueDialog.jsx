import { alpha } from "../theme/colorFns";
import AsyncButton from './ui/AsyncButton';
import { useState, useEffect } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, MenuItem, Select, FormControl, InputLabel, Box, Typography, useTheme, useMediaQuery, IconButton, Grid, Checkbox, FormControlLabel, Tooltip } from "@mui/material";
import { useSelector } from "react-redux";
import ManagedAutocomplete from "./common/ManagedAutocomplete";
import { MdAdd, MdDelete, MdHistory } from "react-icons/md";
import api from "../api/api";
import { FaUser } from "react-icons/fa";
import { Autocomplete as MuiAutocomplete } from "@mui/material";

const CATEGORY_MAPPING = {
  "Outdoor Problem": [
    "DB_ Closing",
    "DB_ DF's Label",
    "DB-Cabling system",
    "UG_ Install.",
    "DF_ Laying on Poles",
    "DF_ Accessories",
    "DF_ Laying to BEP/OTO",
    "BEP_ Install. & location",
    "BEP_ label (Orange sticker)",
    "BEP_ Cabling system",
    "BEP_ DFs label",
    "Civil Work (HC) Status Restoration",
    "Clean waste & material"
  ],
  "Indoor Problem": [
    "DF_ Indoor laying",
    "OTO_ Install.",
    "OTO_ label",
    "Modem label",
    "Modem Location",
    "Indoor, Status Restoration",
    "Clean waste & material"
  ],
  "QoS": [
    "Modem Power level > -23.99",
    "Modem/Extender Config.",
    "Wi-Fi Coverage",
    "(FTTH Offer) speed test",
    "VOIP Active",
    "Hanging"
  ],
  "Behaviour": [
    "Technicians Skills",
    "Technicians Behaviour",
    "Technicians Clothes",
    "Technicians Health & Safety"
  ]
};

const CustomerIssueDialog = ({ open, onClose, onSubmit, issue = null }) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const user = useSelector((state) => state?.auth?.user);
  const isAdmin = user.role === "Admin";

  const initialFormState = {
    slid: "",
    fromMain: "Snags",
    fromSub: "Joint Quality",
    snagType: "Installation",
    reporter: "",
    reporterNote: "",
    contactMethod: "Whatsapp",
    issues: [{ category: '', subCategory: '' }],
    teamName: "",
    teamCode: "",
    pisDateKnown: true,
    pisDate: new Date().toISOString().split('T')[0],
    dateKnown: true,
    date: new Date().toISOString().split('T')[0],
    solved: "no",
    assignedTo: "",
    installingTeam: "",
    teamCompany: '',
    customerName: '',
    customerContact: '',
    assigneeNote: '',
    resolvedBy: '',
    resolveDateKnown: true,
    resolveDate: '',
    closedBy: "",
    closedAtKnown: true,
    closedAt: "",
    dispatched: "no",
    dispatchedAtKnown: true,
    dispatchedAt: "",
    resolutionDetails: "",
    area: "",
    callerName: "",
    callerDetails: "",
    callDate: "",
    isQoS: false,
    scoringKeys: []
  };

  const [formData, setFormData] = useState(initialFormState);
  const [duplicateIssues, setDuplicateIssues] = useState([]);
  const [duplicateDialogOpen, setDuplicateDialogOpen] = useState(false);
  const [fieldTeams, setFieldTeams] = useState([]);
  const [scoringKeyOptions, setScoringKeyOptions] = useState([]);

  useEffect(() => {
    const fetchTeams = async () => {
      try {
        const res = await api.get('/field-teams/get-field-teams', {
          headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
        });
        setFieldTeams(res.data || []);
      } catch (err) {
        console.error("Failed to fetch teams", err);
      }
    };
    fetchTeams();
  }, []);

  // Fetch Scoring Keys from Settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const { data } = await api.get("/settings");
        if (data && data.scoringKeys) {
          setScoringKeyOptions(data.scoringKeys);
        }
      } catch (error) {
        console.error("Failed to load settings for scoring keys", error);
      }
    };
    fetchSettings();
  }, []);

  // Persistence & Edit Logic
  useEffect(() => {
    if (open) {
      if (issue) {
        // Robust date formatter to prevent crashes on invalid dates
        const safeDate = (dateVal) => {
          if (!dateVal) return "";
          try {
            const d = new Date(dateVal);
            if (isNaN(d.getTime())) return "";
            return d.toISOString().split('T')[0];
          } catch {
            return "";
          }
        };

        // Handle legacy issue format
        let issuesArray = issue.issues;
        if (!issuesArray || issuesArray.length === 0) {
          if (issue.issueCategory) {
            issuesArray = [{ category: issue.issueCategory, subCategory: issue.issueSubCategory || '' }];
          } else {
            issuesArray = [{ category: '', subCategory: '' }];
          }
        }

        // Create a base object from issue, ensuring no undefined values for controlled inputs
        const baseData = {
          ...initialFormState,
          ...issue,
          // Explicit fallbacks for legacy or renamed fields
          fromMain: issue.fromMain || issue.from || '',
          fromSub: issue.fromSub || '',
          snagType: issue.snagType || 'Installation',
          teamCompany: issue.teamCompany || '',
          assignedTo: issue.assignedTo || '',
          closedBy: issue.closedBy || '',
          resolvedBy: issue.resolvedBy || '',
          reporter: issue.reporter || '',
          contactMethod: issue.contactMethod || '',

          // Controlled Date Formatting
          pisDateKnown: issue.pisDateKnown !== undefined ? issue.pisDateKnown : !!issue.pisDate,
          pisDate: safeDate(issue.pisDate) || initialFormState.pisDate,
          dateKnown: issue.dateKnown !== undefined ? issue.dateKnown : !!issue.date,
          date: safeDate(issue.date) || initialFormState.date,
          resolveDateKnown: issue.resolveDateKnown !== undefined ? issue.resolveDateKnown : !!issue.resolveDate,
          resolveDate: safeDate(issue.resolveDate),
          closedAtKnown: issue.closedAtKnown !== undefined ? issue.closedAtKnown : !!issue.closedAt,
          closedAt: safeDate(issue.closedAt),
          dispatchedAtKnown: issue.dispatchedAtKnown !== undefined ? issue.dispatchedAtKnown : !!issue.dispatchedAt,
          dispatchedAt: safeDate(issue.dispatchedAt),

          // Status fields
          dispatched: issue.dispatched || (issue.dispatchedAt ? 'yes' : 'no'),
          solved: issue.solved || (issue.closedAt ? 'yes' : 'no'),

          // Managed array
          issues: issuesArray,

          // Area field
          area: issue.area || '',

          // Caller fields
          callerName: issue.callerName || '',
          callerDetails: issue.callerDetails || '',
          callDate: issue.callDate ? new Date(issue.callDate).toISOString().split('T')[0] : '',

          isQoS: issue.isQoS || false,
          scoringKeys: issue.scoringKeys || []
        };

        setFormData(baseData);
      } else {
        // If creating, check local storage
        const savedData = localStorage.getItem('customerIssueFormData');
        const today = new Date().toISOString().split('T')[0];
        if (savedData) {
          const parsed = JSON.parse(savedData);
          setFormData(prev => ({
            ...prev,
            ...parsed,
            pisDate: today, // Always default to today for new entries
            dateKnown: true,
            date: today     // Always default to today for new entries
          }));
        } else {
          setFormData({
            ...initialFormState,
            pisDateKnown: true,
            pisDate: today,
            dateKnown: true,
            date: today
          });
        }
      }
    }
  }, [open, issue]);

  useEffect(() => {
    if (open && !issue) {
      // Debounce localStorage save to prevent excessive updates
      const timeoutId = setTimeout(() => {
        localStorage.setItem('customerIssueFormData', JSON.stringify(formData));
      }, 300);

      return () => clearTimeout(timeoutId);
    }
  }, [formData, open, issue]);

  const checkExistingIssues = async (manual = false) => {
    // Only check if creating a new issue or if the SLID has changed significantly
    // And avoid checking if we are editing the same issue (though backend filter handles exact match)
    if (formData.slid && formData.slid.length > 2 && !issue) {
      try {
        const res = await api.get('/customer-issues', {
          params: { slid: formData.slid }, // Uses the new exact match filter backend
          headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
        });

        if (res.data.data && res.data.data.length > 0) {
          setDuplicateIssues(res.data.data);
          setDuplicateDialogOpen(true);
        } else {
          setDuplicateIssues([]);
          if (manual) {
            alert("No existing issues found for this SLID.");
          }
        }
      } catch (err) {
        console.error("Duplicate check failed", err);
      }
    } else if (manual && (!formData.slid || formData.slid.length <= 2)) {
      alert("Please enter a valid SLID (at least 3 characters) to check.");
    }
  };

  useEffect(() => {
    const checkExistingIssues = async () => {
      // Only check if creating a new issue or if the SLID has changed significantly
      // And avoid checking if we are editing the same issue (though backend filter handles exact match)
      if (formData.slid && formData.slid.length > 5 && !issue) {
        try {
          const res = await api.get('/customer-issues', {
            params: { slid: formData.slid }, // Uses the new exact match filter backend
            headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` }
          });

          if (res.data.data && res.data.data.length > 0) {
            setDuplicateIssues(res.data.data);
            setDuplicateDialogOpen(true);
          } else {
            setDuplicateIssues([]);
          }
        } catch (err) {
          console.error("Duplicate check failed", err);
        }
      }
    };

    // Debounce the API call
    const timer = setTimeout(() => {
      checkExistingIssues();
    }, 800);

    return () => clearTimeout(timer);
  }, [formData.slid, issue]);

  const handleChange = (e) => {
    if (!isAdmin) return;
    const { name, value, type, checked } = e.target;

    setFormData(prev => {
      let updated = {
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      };

      // Reset resolution/closure fields if ticket is toggled back to "Open"
      if (name === 'solved' && value === 'no' && prev.solved === 'yes') {
        updated = {
          ...updated,
          resolvedBy: '',
          resolveDate: '',
          resolutionDetails: '',
          closedBy: '',
          closedAt: ''
        };
      }

      if (name === 'dispatched' && value === 'no') {
        updated = {
          ...updated,
          dispatchedAt: ''
        };
      }

      // Auto-fill Team Code when Team Name is selected
      if (name === 'teamName') {
        if (value === 'Unknown') {
          updated.teamCode = 'Unknown';
        } else {
          const selectedTeam = fieldTeams.find(t => t.teamName === value);
          if (selectedTeam) {
            updated.teamCode = selectedTeam.teamCode;
          } else {
            updated.teamCode = '';
          }
        }
      }

      return updated;
    });
  };

  // Issue Management
  const handleIssueChange = (index, field, value) => {
    const updatedIssues = [...formData.issues];
    updatedIssues[index][field] = value;

    // Reset subCategory if category changes
    if (field === 'category') {
      updatedIssues[index].subCategory = '';
    }

    setFormData(prev => ({ ...prev, issues: updatedIssues }));
  };

  const addIssueRow = () => {
    setFormData(prev => ({
      ...prev,
      issues: [...prev.issues, { category: '', subCategory: '' }]
    }));
  };

  const removeIssueRow = (index) => {
    if (formData.issues.length > 1) {
      setFormData(prev => ({
        ...prev,
        issues: prev.issues.filter((_, i) => i !== index)
      }));
    }
  };

  const validateForm = () => {
    if (!formData.slid || (typeof formData.slid === 'string' && !formData.slid.trim())) {
      alert("SLID is required.");
      return false;
    }

    // Workflow Validation: Enforce Dispatch before Resolution
    if (formData.solved === 'yes') {
      if (formData.dispatched !== 'yes') {
        alert("CRITICAL: Issue must be marked as 'Dispatched' before it can be 'Closed'.");
        return false;
      }
      if (formData.dispatchedAtKnown && !formData.dispatchedAt) {
        alert("Dispatched Date is required if 'Known' is checked.");
        return false;
      }
      if (formData.resolveDateKnown && !formData.resolveDate) {
        alert("Field Resolution Date is required if 'Known' is checked.");
        return false;
      }
      if (formData.closedAtKnown && !formData.closedAt) {
        alert("Close Date (Supervisor Approval) is required if 'Known' is checked.");
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!isAdmin) return;

    if (!validateForm()) return;

    const submitData = {
      ...formData,
      pisDate: formData.pisDateKnown ? formData.pisDate : null,
      date: formData.dateKnown ? formData.date : null,
      dispatchedAt: formData.dispatchedAtKnown ? formData.dispatchedAt : null,
      resolveDate: formData.resolveDateKnown ? formData.resolveDate : null,
      closedAt: formData.closedAtKnown ? formData.closedAt : null
    };
    // keep the dialog (and the typed data) open until the server confirms
    const ok = await onSubmit(submitData, issue?._id);
    if (ok === false) return;
    if (!issue) localStorage.removeItem('customerIssueFormData');
    onClose();
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset the form? This will clear all entered data.")) {
      localStorage.removeItem('customerIssueFormData');
      setFormData(initialFormState);
    }
  };

  const handleClose = () => {
    // Persist data is already handled by useEffect, so just close
    onClose();
  }

  // Style constants with disabled state
  const textFieldStyles = {
    '& .MuiInputBase-root': {
      color: 'var(--text)',
      cursor: isAdmin ? 'text' : 'not-allowed',
    },
    '& .MuiInputLabel-root': {
      color: 'var(--text-secondary)',
    },
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: 'var(--border)',
      },
      '&:hover fieldset': {
        borderColor: isAdmin ? 'var(--text-muted)' : '#e5e7eb',
      },
      '&.Mui-focused fieldset': {
        borderColor: isAdmin ? '#2563EB' : '#e5e7eb',
      },
      '&.Mui-disabled': {
        cursor: 'not-allowed',
      }
    },
    '& .MuiFormHelperText-root': {
      color: 'var(--text-secondary)',
    },
  };

  const formControlStyles = {
    '& .MuiInputBase-root': {
      color: 'var(--text)',
      cursor: isAdmin ? 'pointer' : 'not-allowed',
    },
    '& .MuiOutlinedInput-notchedOutline': {
      borderColor: 'var(--border)',
    },
    '&:hover .MuiOutlinedInput-notchedOutline': {
      borderColor: isAdmin ? 'var(--text-muted)' : '#e5e7eb',
    },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: isAdmin ? '#2563EB' : '#e5e7eb',
    },
  };

  const inputLabelStyles = {
    color: 'var(--text-secondary)',
    '&.Mui-focused': {
      color: isAdmin ? '#2563EB' : '#6b7280',
    },
  };

  const selectStyles = {
    '& .MuiSelect-icon': {
      color: 'var(--text-secondary)',
    },
  };

  const menuItemStyles = {
    color: 'var(--text)',
    backgroundColor: 'var(--surface)',
    '&:hover': {
      backgroundColor: 'var(--surface)',
    },
    '&.Mui-selected': {
      backgroundColor: '#2563EB',
      '&:hover': {
        backgroundColor: '#1565c0',
      },
    },
  };




  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullScreen={fullScreen}
      maxWidth="lg"
      fullWidth
    >
      <DialogTitle>
        <Typography variant="h6" component="div">
          {issue ? 'Edit OJO snag' : 'Report OJO snag'}
        </Typography>
      </DialogTitle>

      <DialogContent dividers sx={{ padding: '20px 24px', '&.MuiDialogContent-root': {
          padding: '20px 24px',
        } }}>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          {/* Section 1: Customer & Reported Date */}
          <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
              <FaUser size={18} /> Customer & Primary Info
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Ticket ID (Optional)"
                  name="ticketId"
                  value={formData.ticketId || ''}
                  onChange={handleChange}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  <TextField
                    fullWidth
                    label="SLID (Subscription Number)"
                    name="slid"
                    value={formData.slid || ''}
                    onChange={handleChange}
                    required
                    disabled={!isAdmin}
                    sx={textFieldStyles}
                  />
                  <Tooltip title="Check Existing Issues">
                    <IconButton
                      onClick={() => checkExistingIssues(true)}
                      sx={{
                        backgroundColor: 'rgba(217, 119, 6, 0.1)',
                        color: '#D97706',
                        '&:hover': { backgroundColor: 'rgba(217, 119, 6, 0.2)' }
                      }}
                    >
                      <MdHistory />
                    </IconButton>
                  </Tooltip>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Customer Name"
                  name="customerName"
                  value={formData.customerName}
                  onChange={handleChange}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Customer Contact Info"
                  name="customerContact"
                  value={formData.customerContact}
                  onChange={handleChange}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.pisDateKnown}
                        onChange={handleChange}
                        name="pisDateKnown"
                        sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                      />
                    }
                    label="PIS Date Known"
                    sx={{ color: 'var(--text)', minWidth: '150px' }}
                  />
                  {formData.pisDateKnown && (
                    <TextField
                      fullWidth
                      label="PIS Date"
                      type="date"
                      name="pisDate"
                      value={formData.pisDate}
                      onChange={handleChange}
                      InputLabelProps={{ shrink: true }}
                      disabled={!isAdmin}
                      sx={textFieldStyles}
                    />
                  )}
                </Box>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Area"
                  name="area"
                  value={formData.area || ''}
                  onChange={handleChange}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.dateKnown}
                        onChange={handleChange}
                        name="dateKnown"
                        sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                      />
                    }
                    label="Reported Date Known"
                    sx={{ color: 'var(--text)', minWidth: '150px' }}
                  />
                  {formData.dateKnown && (
                    <TextField
                      fullWidth
                      label="Reported Date"
                      type="date"
                      name="date"
                      value={formData.date}
                      onChange={handleChange}
                      InputLabelProps={{ shrink: true }}
                      disabled={!isAdmin}
                      sx={textFieldStyles}
                    />
                  )}
                </Box>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={formData.isQoS}
                      onChange={handleChange}
                      name="isQoS"
                      sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                    />
                  }
                  label={
                    <Box>
                      <Typography variant="body2" sx={{ color: 'var(--text)', fontWeight: '600' }}>Quality of Service (QoS)</Typography>
                      <Typography variant="caption" sx={{ color: 'var(--text-secondary)', display: 'block' }}>Flag for higher weighting in rankings</Typography>
                    </Box>
                  }
                  disabled={!isAdmin}
                />
              </Grid>


              {/* Dynamic Scoring Keys - Autocomplete */}
              {scoringKeyOptions.length > 0 && (
                <Grid item xs={12}>
                  <Box sx={{ p: 2, border: '1px solid var(--border)', borderRadius: 2, mt: 2 }}>
                    <Typography variant="subtitle2" sx={{ color: 'var(--accent-text)', mb: 1 }}>Scoring Factors</Typography>
                    <MuiAutocomplete
                      multiple
                      id="scoring-keys-autocomplete"
                      options={scoringKeyOptions.filter(key => key.targetForm === 'Issue' || key.targetForm === 'Both')}
                      getOptionLabel={(option) => `${option.label} (${option.points > 0 ? '+' : ''}${option.points})`}
                      value={scoringKeyOptions.filter(key => formData.scoringKeys?.includes(key.label))}
                      onChange={(event, newValue) => {
                        setFormData(prev => ({
                          ...prev,
                          scoringKeys: newValue.map(item => item.label)
                        }));
                      }}
                      disabled={!isAdmin}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          label="Select Scoring Factors"
                          placeholder="Search factors..."
                          sx={textFieldStyles}
                        />
                      )}
                      renderOption={(props, option, { selected }) => (
                        <li {...props} style={{ backgroundColor: 'var(--surface)', color: 'var(--text)' }}>
                          <Checkbox
                            icon={<Box component="span" sx={{ width: 16, height: 16, border: '1px solid gray', borderRadius: '3px' }} />}
                            checkedIcon={<Box component="span" sx={{ width: 16, height: 16, bgcolor: 'var(--accent)', borderRadius: '3px' }} />}
                            style={{ marginRight: 8 }}
                            checked={selected}
                            sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                          />
                          {option.label} <span style={{ color: 'var(--text-secondary)', fontSize: '0.8em', marginLeft: '4px' }}>({option.points > 0 ? '+' : ''}{option.points})</span>
                        </li>
                      )}
                      fullWidth
                      ChipProps={{
                        sx: {
                          backgroundColor: 'var(--accent)',
                          color: 'var(--text)',
                          '& .MuiChip-deleteIcon': {
                            color: 'var(--text)',
                            '&:hover': {
                              color: 'var(--text-secondary)',
                            },
                          },
                        },
                      }}
                    />
                  </Box>
                </Grid>
              )}
            </Grid>
          </Box>

          {/* Section 2: Reporter Details */}
          <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2 }}>Reporter Information</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <ManagedAutocomplete
                  category="ISSUE_FROM_MAIN"
                  label="Src (Main)"
                  fullWidth
                  value={formData.fromMain}
                  onChange={(val) => handleChange({ target: { name: 'fromMain', value: val } })}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <ManagedAutocomplete
                  category="ISSUE_FROM_SUB"
                  label="Src (Sub)"
                  fullWidth
                  value={formData.fromSub}
                  onChange={(val) => handleChange({ target: { name: 'fromSub', value: val } })}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  label="Snag type"
                  size="medium"
                  fullWidth
                  name="snagType"
                  value={formData.snagType || 'Installation'}
                  onChange={handleChange}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                >
                  <MenuItem value="Installation">Installation</MenuItem>
                  <MenuItem value="Maintenance">Maintenance</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <ManagedAutocomplete
                  category="REPORTERS"
                  label="Reporter Name"
                  fullWidth
                  freeSolo
                  value={formData.reporter}
                  onChange={(val) => handleChange({ target: { name: 'reporter', value: val } })}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
                  <ManagedAutocomplete
                    category="CONTACT_METHOD"
                    label="Contact Method"
                    fullWidth
                    freeSolo
                    value={formData.contactMethod}
                    onChange={(val) => handleChange({ target: { name: 'contactMethod', value: val } })}
                    disabled={!isAdmin}
                    sx={textFieldStyles}
                  />
                  <Button
                    onClick={() => handleChange({ target: { name: 'contactMethod', value: formData.reporter } })}
                    disabled={!isAdmin || !formData.reporter}
                    variant="outlined"
                    size="small"
                    sx={{
                      mt: 1,
                      minWidth: '90px',
                      borderColor: 'var(--border)',
                      color: 'var(--accent-text)',
                      fontSize: '0.65rem',
                      textTransform: 'none',
                      '&:hover': { borderColor: 'var(--accent)', backgroundColor: alpha('#6C47FF', 0.05) }
                    }}
                  >
                    Use Reporter
                  </Button>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Reporter Note"
                  name="reporterNote"
                  value={formData.reporterNote}
                  onChange={handleChange}
                  multiline
                  rows={2}
                  dir="rtl"
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
            </Grid>
          </Box>

          {/* Section 3: Problem Description (Issues) */}
          <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2 }}>Problem Description</Typography>
            {formData.issues.map((issue, index) => (
              <Grid container spacing={2} key={index} alignItems="center" sx={{ mb: 2 }}>
                <Grid item xs={11}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <MuiAutocomplete
                        freeSolo
                        options={Object.keys(CATEGORY_MAPPING)}
                        value={issue.category}
                        onInputChange={(e, val) => handleIssueChange(index, 'category', val)}
                        onChange={(e, val) => handleIssueChange(index, 'category', val)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={`Category ${index + 1}`}
                            sx={textFieldStyles}
                          />
                        )}
                        disabled={!isAdmin}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <MuiAutocomplete
                        freeSolo
                        options={issue.category && CATEGORY_MAPPING[issue.category] ? CATEGORY_MAPPING[issue.category] : []}
                        value={issue.subCategory}
                        onInputChange={(e, val) => handleIssueChange(index, 'subCategory', val)}
                        onChange={(e, val) => handleIssueChange(index, 'subCategory', val)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={`Sub Category ${index + 1}`}
                            sx={textFieldStyles}
                          />
                        )}
                        disabled={!isAdmin || !issue.category}
                      />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={1}>
                  <IconButton onClick={() => removeIssueRow(index)} disabled={formData.issues.length === 1 || !isAdmin}>
                    <MdDelete color="#DC2626" />
                  </IconButton>
                </Grid>
              </Grid>
            ))}
            <Button startIcon={<MdAdd />} onClick={addIssueRow} disabled={!isAdmin} sx={{ color: 'var(--accent-text)', textTransform: 'none' }}>
              Add Another Category
            </Button>
          </Box>

          {/* Section 4: Team Information */}
          <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2 }}>Team Information</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <MuiAutocomplete
                  options={['Unknown', ...fieldTeams.map(t => t.teamName)]}
                  value={formData.teamName}
                  onChange={(e, val) => handleChange({ target: { name: 'teamName', value: val } })}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Team Name"
                      sx={textFieldStyles}
                    />
                  )}
                  disabled={!isAdmin}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Team Code"
                  name="teamCode"
                  value={formData.teamCode}
                  InputProps={{ readOnly: true }}
                  disabled={!isAdmin}
                  sx={{
                    ...textFieldStyles,
                    '& .MuiInputBase-root': {
                      backgroundColor: 'var(--overlay-subtle)',
                      color: 'var(--text-secondary)'
                    }
                  }}
                />
              </Grid>
            </Grid>
          </Box>
          {/* Section: Caller Details - Separately after Assignment */}
          {/* <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2 }}>Caller Information</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <ManagedAutocomplete
                  category="CALLERS"
                  label="Caller Name"
                  fullWidth
                  value={formData.callerName}
                  onChange={(val) => handleChange({ target: { name: 'callerName', value: val } })}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Caller Details"
                  name="callerDetails"
                  value={formData.callerDetails || ''}
                  onChange={handleChange}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Call Date"
                  type="date"
                  name="callDate"
                  value={formData.callDate || ''}
                  onChange={handleChange}
                  InputLabelProps={{ shrink: true }}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
            </Grid>
          </Box> */}

          {/* Section 5: Dispatch & Closure */}
          <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2 }}>Dispatch & Supervisor Approval</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <FormControl fullWidth sx={formControlStyles}>
                  <InputLabel sx={inputLabelStyles}>Dispatched Status</InputLabel>
                  <Select
                    name="dispatched"
                    value={formData.dispatched || 'no'}
                    label="Dispatched Status"
                    onChange={handleChange}
                    disabled={!isAdmin}
                    sx={selectStyles}
                    MenuProps={{ PaperProps: { sx: { backgroundColor: 'var(--surface)', color: 'var(--text)', '& .MuiMenuItem-root': menuItemStyles } } }}
                  >
                    <MenuItem value="yes" sx={menuItemStyles}>Yes (Dispatched)</MenuItem>
                    <MenuItem value="no" sx={menuItemStyles}>No (Pending)</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={4}>
                {formData.dispatched === 'yes' && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={formData.dispatchedAtKnown}
                          onChange={handleChange}
                          name="dispatchedAtKnown"
                          sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                        />
                      }
                      label="Dispatched Date Known"
                      sx={{ color: 'var(--text)', minWidth: '150px' }}
                    />
                    {formData.dispatchedAtKnown && (
                      <TextField
                        fullWidth
                        label="Dispatched Date"
                        type="date"
                        name="dispatchedAt"
                        value={formData.dispatchedAt || ''}
                        onChange={handleChange}
                        InputLabelProps={{ shrink: true }}
                        disabled={!isAdmin}
                        sx={textFieldStyles}
                      />
                    )}
                  </Box>
                )}
              </Grid>
              <Grid item xs={12} sm={4}>
                <ManagedAutocomplete
                  category="CIN_SUPERVISORS"
                  label="Responsible Supervisor"
                  fullWidth
                  freeSolo
                  value={formData.closedBy || ''}
                  onChange={(val) => handleChange({ target: { name: 'closedBy', value: val } })}
                  disabled={!isAdmin}
                  sx={textFieldStyles}
                />
              </Grid>
            </Grid>
          </Box>

          {/* Section 6: Resolution Status */}
          <Box sx={{ border: '1px solid var(--border)', borderRadius: 2, p: 2 }}>
            <Typography variant="subtitle1" gutterBottom sx={{ color: 'var(--accent-text)', mb: 2 }}>Final Status & Resolution</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <FormControl fullWidth required sx={formControlStyles}>
                  <InputLabel sx={inputLabelStyles}>Life Cycle Status</InputLabel>
                  <Select
                    name="solved"
                    value={formData.solved}
                    label="Life Cycle Status"
                    onChange={handleChange}
                    disabled={!isAdmin}
                    sx={selectStyles}
                    MenuProps={{ PaperProps: { sx: { backgroundColor: 'var(--surface)', color: 'var(--text)', '& .MuiMenuItem-root': menuItemStyles } } }}
                  >
                    <MenuItem value="yes" sx={menuItemStyles}>Closed (Resolved)</MenuItem>
                    <MenuItem value="no" sx={menuItemStyles}>Open (In Progress)</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={4}>
                {formData.solved === 'yes' && (
                  <FormControl fullWidth sx={formControlStyles}>
                    <InputLabel sx={inputLabelStyles}>Resolution Method</InputLabel>
                    <Select
                      name="resolvedBy"
                      value={formData.resolvedBy}
                      label="Resolution Method"
                      onChange={handleChange}
                      disabled={!isAdmin}
                      sx={selectStyles}
                      MenuProps={{ PaperProps: { sx: { backgroundColor: 'var(--surface)', color: 'var(--text)', '& .MuiMenuItem-root': menuItemStyles } } }}
                    >
                      <MenuItem value="" sx={menuItemStyles}>Not Specified</MenuItem>
                      <MenuItem value="Phone" sx={menuItemStyles}>Phone</MenuItem>
                      <MenuItem value="Visit" sx={menuItemStyles}>Visit</MenuItem>
                    </Select>
                  </FormControl>
                )}
              </Grid>
              <Grid item xs={12} sm={4}>
                {formData.solved === 'yes' && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={formData.closedAtKnown}
                          onChange={handleChange}
                          name="closedAtKnown"
                          sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                        />
                      }
                      label="Close Date Known"
                      sx={{ color: 'var(--text)', minWidth: '150px' }}
                    />
                    {formData.closedAtKnown && (
                      <TextField
                        fullWidth
                        label="Close Date"
                        type="date"
                        name="closedAt"
                        value={formData.closedAt || ''}
                        onChange={handleChange}
                        InputLabelProps={{ shrink: true }}
                        disabled={!isAdmin}
                        sx={textFieldStyles}
                      />
                    )}
                  </Box>
                )}
              </Grid>
              {formData.solved === 'yes' && (
                <>
                  <Grid item xs={12} sm={6}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={formData.resolveDateKnown}
                            onChange={handleChange}
                            name="resolveDateKnown"
                            sx={{ color: 'var(--text-secondary)', '&.Mui-checked': { color: 'var(--accent-text)' } }}
                          />
                        }
                        label="Resolution Date Known"
                        sx={{ color: 'var(--text)', minWidth: '150px' }}
                      />
                      {formData.resolveDateKnown && (
                        <TextField
                          fullWidth
                          label="Field Resolution Date"
                          type="date"
                          name="resolveDate"
                          value={formData.resolveDate || ''}
                          onChange={handleChange}
                          InputLabelProps={{ shrink: true }}
                          required
                          disabled={!isAdmin}
                          sx={textFieldStyles}
                          helperText="When field team finished work"
                        />
                      )}
                    </Box>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Resolution Summary"
                      name="resolutionDetails"
                      value={formData.resolutionDetails}
                      onChange={handleChange}
                      multiline
                      rows={2}
                      dir="rtl"
                      disabled={!isAdmin}
                      sx={textFieldStyles}
                    />
                  </Grid>
                </>
              )}
            </Grid>
          </Box>
        </Box>
      </DialogContent >


      <DialogActions sx={{ justifyContent: 'space-between' }}>
        <Button variant="text" onClick={handleReset} disabled={!isAdmin} sx={{ color: 'var(--text-secondary)' }}>
          Reset form
        </Button>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" onClick={handleClose}>Cancel</Button>
          <AsyncButton variant="contained" onClick={handleSubmit} disabled={!isAdmin} pendingLabel="Saving…">
            {issue ? 'Save changes' : 'Submit'}
          </AsyncButton>
        </Box>
      </DialogActions>

      {/* Duplicate Issue Warning Dialog */}
      <Dialog
        open={duplicateDialogOpen}
        onClose={() => setDuplicateDialogOpen(false)}
        maxWidth="md"
        fullWidth
       
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <MdHistory size={24} />
          <Typography variant="h6" fontWeight="600">
            Existing Issue(s) Found
          </Typography>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Typography variant="body1" sx={{ mb: 3 }}>
            This SLID <strong>({formData.slid})</strong> already exists in the database. Please review the details below before proceeding to avoid creating duplicates.
          </Typography>

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {duplicateIssues.map((issue, index) => (
              <Box key={issue._id || index} sx={{
                p: 2,
                borderRadius: '8px',
                backgroundColor: 'var(--overlay-subtle)',
                border: '1px solid var(--border)'
              }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4}>
                    <Typography variant="caption" color="var(--text-secondary)">Reported Date</Typography>
                    <Typography variant="body2" fontWeight="600">
                      {issue.date ? new Date(issue.date).toLocaleDateString() : 'N/A'}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <Typography variant="caption" color="var(--text-secondary)">Reporter</Typography>
                    <Typography variant="body2" fontWeight="600">{issue.reporter}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <Typography variant="caption" color="var(--text-secondary)">Assigned To</Typography>
                    <Typography variant="body2" fontWeight="600">{issue.assignedTo}</Typography>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <Typography variant="caption" color="var(--text-secondary)">Customer Name</Typography>
                    <Typography variant="body2">{issue.customerName || 'N/A'}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <Typography variant="caption" color="var(--text-secondary)">Status</Typography>
                    <Typography variant="body2" sx={{
                      color: issue.solved === 'yes' ? '#16A34A' : '#DC2626',
                      fontWeight: '600',
                      textTransform: 'capitalize'
                    }}>
                      {issue.solved === 'yes' ? 'Closed' : 'Open'}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <Typography variant="caption" color="var(--text-secondary)">Category</Typography>
                    <Typography variant="body2">
                      {issue.issues?.[0]?.category || 'N/A'}
                    </Typography>
                  </Grid>
                </Grid>
              </Box>
            ))}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDuplicateDialogOpen(false)}
            variant="contained"
            sx={{ '&:hover': { backgroundColor: '#d97706' } }}
          >
            Acknowledge & Continue
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog >
  );
};

export default CustomerIssueDialog;
