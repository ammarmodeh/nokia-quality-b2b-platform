import { useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import RemoveIcon from '@mui/icons-material/Remove';
import { Paper, Box, Chip, Typography } from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import TrendingFlatIcon from '@mui/icons-material/TrendingFlat';

export const DataTable = ({ groupedData, settings = {} }) => {
  const [paginationModel, setPaginationModel] = useState({
    pageSize: 10,
    page: 0,
  });

  const promoterTarget = settings?.npsTargets?.promoters ?? 75;
  const detractorTarget = settings?.npsTargets?.detractors ?? 8;
  const npsTarget = promoterTarget - detractorTarget;

  const sortedKeysDescending = Object.keys(groupedData).sort((a, b) => {
    const matchWkA = a.match(/Wk-(\d+) \((\d+)\)/);
    const matchWkB = b.match(/Wk-(\d+) \((\d+)\)/);
    if (matchWkA && matchWkB) {
      const yearA = parseInt(matchWkA[2], 10);
      const yearB = parseInt(matchWkB[2], 10);
      const weekA = parseInt(matchWkA[1], 10);
      const weekB = parseInt(matchWkB[1], 10);
      if (yearA !== yearB) return yearB - yearA;
      return weekB - weekA;
    }

    const matchMonA = a.match(/Month (\d+)/);
    const matchMonB = b.match(/Month (\d+)/);
    if (matchMonA && matchMonB) {
      return parseInt(matchMonB[1], 10) - parseInt(matchMonA[1], 10);
    }

    return b.localeCompare(a);
  });

  const rows = sortedKeysDescending.map((key, index) => {
    const previousKey = sortedKeysDescending[index + 1];
    const current = groupedData[key];
    const previous = previousKey ? groupedData[previousKey] : null;

    const npsValue = (current.Promoters || 0) - (current.Detractors || 0);
    const prevNpsValue = previous ? (previous.Promoters || 0) - (previous.Detractors || 0) : null;

    const getTrendIcon = (currentValue, previousValue, inverse = false) => {
      if (!previousValue && previousValue !== 0) return null;
      const diff = currentValue - previousValue;

      if (inverse) {
        if (diff > 0) return <TrendingDownIcon sx={{ fontSize: 16, color: '#ef4444' }} />;
        if (diff < 0) return <TrendingUpIcon sx={{ fontSize: 16, color: '#10b981' }} />;
      } else {
        if (diff > 0) return <TrendingUpIcon sx={{ fontSize: 16, color: '#10b981' }} />;
        if (diff < 0) return <TrendingDownIcon sx={{ fontSize: 16, color: '#ef4444' }} />;
      }
      return <TrendingFlatIcon sx={{ fontSize: 16, color: 'var(--text-secondary)' }} />;
    };

    const getChangeValue = (currentValue, previousValue) => {
      if (!previousValue && previousValue !== 0) return '';
      const diff = currentValue - previousValue;
      const sign = diff > 0 ? '+' : '';
      return `${sign}${diff}`;
    };

    const getNPSStatus = (nps) => {
      if (nps >= npsTarget) return { label: 'Met Target', color: '#10b981' };
      return { label: 'Out of Target', color: '#ef4444' };
    };

    const getPromoterStatus = (val) => {
      if (val >= promoterTarget) return { label: 'Met Target', color: '#10b981' };
      return { label: 'Out of Target', color: '#ef4444' };
    };

    const getDetractorStatus = (val) => {
      if (val <= detractorTarget) return { label: 'Met Target', color: '#10b981' };
      return { label: 'Out of Target', color: '#ef4444' };
    };

    const npsStatus = getNPSStatus(npsValue);

    return {
      id: key,
      period: key,
      sampleSize: current.sampleSize || 0,
      nps: npsValue,
      npsChange: getChangeValue(npsValue, prevNpsValue),
      npsTrend: getTrendIcon(npsValue, prevNpsValue),
      npsStatus: npsStatus,
      promoters: current.Promoters || 0,
      promotersChange: previous ? getChangeValue(current.Promoters, previous.Promoters) : '',
      promotersTrend: previous ? getTrendIcon(current.Promoters, previous.Promoters) : null,
      promotersStatus: getPromoterStatus(current.Promoters || 0),
      detractors: current.Detractors || 0,
      detractorsChange: previous ? getChangeValue(current.Detractors, previous.Detractors) : '',
      detractorsTrend: previous ? getTrendIcon(current.Detractors, previous.Detractors, true) : null,
      detractorsStatus: getDetractorStatus(current.Detractors || 0),
      neutrals: current.Neutrals || 0,
      neutralsChange: previous ? getChangeValue(current.Neutrals, previous.Neutrals) : '',
      neutralsTrend: previous ? getTrendIcon(current.Neutrals, previous.Neutrals, true) : null,
    };
  });

  const columns = [
    {
      field: 'period',
      headerName: (rows[0] && rows[0].period.includes('Month')) ? 'Month' : 'Week',
      flex: 1.2,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Typography variant="body2" fontWeight="700" color="var(--text-secondary)">
          {params.value}
        </Typography>
      )
    },
    {
      field: 'sampleSize',
      headerName: 'Samples',
      flex: 0.8,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Chip
          label={params.value}
          size="small"
          sx={{
            bgcolor: 'rgba(59, 130, 246, 0.15)',
            color: '#3b82f6',
            fontWeight: 600,
            fontSize: '0.75rem'
          }}
        />
      )
    },
    {
      field: 'nps',
      headerName: 'NPS',
      flex: 1.2,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5 }}>
          <Typography variant="body2" fontWeight="700" color={params.row.npsStatus.color}>
            {params.value}
          </Typography>
          {params.row.npsTrend}
          {params.row.npsChange && (
            <Typography variant="caption" color="var(--text-secondary)" sx={{ ml: 0.5 }}>
              ({params.row.npsChange})
            </Typography>
          )}
        </Box>
      ),
    },
    {
      field: 'npsStatus',
      headerName: 'Status',
      flex: 1,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Chip
          label={params.value.label}
          size="small"
          sx={{
            bgcolor: `${params.value.color}20`,
            color: params.value.color,
            fontWeight: 700,
            fontSize: '0.7rem',
            borderRadius: 2
          }}
        />
      ),
    },
    {
      field: 'promoters',
      headerName: 'Promoters %',
      flex: 1,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5 }}>
          <Typography variant="body2" color="#10b981" fontWeight="600">
            {params.value}%
          </Typography>
          {params.row.promotersTrend}
          {params.row.promotersChange && (
            <Typography variant="caption" color="var(--text-secondary)">
              ({params.row.promotersChange})
            </Typography>
          )}
        </Box>
      ),
    },
    {
      field: 'promotersStatus',
      headerName: 'P-Status',
      flex: 1,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Chip
          label={params.value.label}
          size="small"
          sx={{
            bgcolor: `${params.value.color}20`,
            color: params.value.color,
            fontWeight: 700,
            fontSize: '0.65rem',
            borderRadius: 2
          }}
        />
      ),
    },
    {
      field: 'detractors',
      headerName: 'Detractors %',
      flex: 1,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5 }}>
          <Typography variant="body2" color="#ef4444" fontWeight="600">
            {params.value}%
          </Typography>
          {params.row.detractorsTrend}
          {params.row.detractorsChange && (
            <Typography variant="caption" color="var(--text-secondary)">
              ({params.row.detractorsChange})
            </Typography>
          )}
        </Box>
      ),
    },
    {
      field: 'detractorsStatus',
      headerName: 'D-Status',
      flex: 1,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Chip
          label={params.value.label}
          size="small"
          sx={{
            bgcolor: `${params.value.color}20`,
            color: params.value.color,
            fontWeight: 700,
            fontSize: '0.65rem',
            borderRadius: 2
          }}
        />
      ),
    },
    {
      field: 'neutrals',
      headerName: 'Neutrals %',
      flex: 1.2,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5 }}>
          <Typography variant="body2" color="#fb923c" fontWeight="600">
            {params.value}%
          </Typography>
          {params.row.neutralsTrend}
          {params.row.neutralsChange && (
            <Typography variant="caption" color="var(--text-secondary)">
              ({params.row.neutralsChange})
            </Typography>
          )}
        </Box>
      ),
    },
  ];

  return (
    <div style={{ width: '100%' }}>
      <Paper sx={{
        minHeight: 400,
        width: "100%",
        backgroundColor: "var(--surface)",
        overflow: "hidden",
        border: '1px solid var(--border)',
        borderRadius: 3
      }}>
        <Box sx={{ p: 2, borderBottom: '1px solid var(--border)' }}>
          <Typography variant="subtitle2" sx={{ color: 'var(--text-secondary)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1 }}>
            {(rows[0] && rows[0].period.includes('Month')) ? 'Monthly' : 'Weekly'} Performance Details
          </Typography>
        </Box>
        <DataGrid
          rows={rows}
          columns={columns}
          getRowHeight={() => 52}
          pageSizeOptions={[5, 10, 25, 50]}
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          disableColumnResize
          disableVirtualization={true}
          sx={{
            border: 0,
            color: 'var(--text)',
            '& .MuiDataGrid-container--top [role="row"]': {
              background: 'none',
            },
            '& .MuiDataGrid-row': {
              '&:hover': {
                backgroundColor: 'rgba(59, 130, 246, 0.08)',
              },
            },
            "&.MuiDataGrid-root": {
              background: 'none'
            },
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: 'var(--surface)',
              fontSize: '0.75rem',
              fontWeight: 700,
              overflow: 'hidden',
              textTransform: 'uppercase',
              letterSpacing: 0.5,
            },
            '& .MuiDataGrid-columnHeader': {
              backgroundColor: 'rgba(59, 130, 246, 0.05)',
            },
            '& .MuiDataGrid-cell': {
              borderBottom: '1px solid var(--border)',
              display: 'flex',
              alignItems: 'center',
            },
            '& .MuiDataGrid-footerContainer': {
              minHeight: '64px',
              backgroundColor: 'var(--surface)',
              borderTop: '1px solid var(--border)',
            },
            '& .MuiDataGrid-virtualScroller': {
              overflow: 'auto',
              '&::-webkit-scrollbar': {
                width: '8px',
                height: '8px',
              },
              '&::-webkit-scrollbar-thumb': {
                backgroundColor: '#3b82f6',
                borderRadius: '4px',
              },
              '&::-webkit-scrollbar-track': {
                backgroundColor: 'var(--overlay-subtle)',
              },
            },
            '& .MuiDataGrid-scrollbarFiller': {
              backgroundColor: 'var(--surface)',
            },
          }}
        />
      </Paper>
    </div>
  );
};