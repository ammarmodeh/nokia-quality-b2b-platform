import { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import { logout } from "../redux/slices/authSlice";
import {
  Box,
  Typography,
  TextField,
  Button as MuiButton,
  Snackbar,
  Alert,
  Divider,
  InputAdornment,
  IconButton,
  useMediaQuery,
  useTheme
} from "@mui/material";
import {
  Visibility,
  VisibilityOff,
  Lock as LockIcon,
  LockOpen as LockOpenIcon,
  Verified as VerifiedIcon,
  ArrowBack as ArrowBackIcon
} from "@mui/icons-material";
import { HashLoader } from "react-spinners";

const ChangePassword = ({ embedded = false } = {}) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [loading, setLoading] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("success");
  const [showPassword, setShowPassword] = useState({
    oldPassword: false,
    newPassword: false,
    confirmPassword: false
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm();

  const newPassword = watch("newPassword", "");

  const togglePasswordVisibility = (field) => {
    setShowPassword(prev => ({
      ...prev,
      [field]: !prev[field]
    }));
  };

  const submitHandler = async (data) => {
    setLoading(true);
    try {
      const response = await api.post("/users/change-password",
        { oldPassword: data.oldPassword, newPassword: data.newPassword },
        { headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` } }
      );

      if (response.data.message === "Password changed successfully") {
        setSnackbarMessage(response.data.message);
        setSnackbarSeverity("success");
        setOpenSnackbar(true);

        setTimeout(() => {
          dispatch(logout());
          navigate("/auth");
        }, 1500);
      }
    } catch (error) {
      setSnackbarMessage(error.response?.data?.message || "An error occurred");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnackbar(false);
  };

  const handleBackClick = () => {
    navigate(-1);
  };

  // Style constants
  const textFieldStyles = {
    '& .MuiInputBase-root': {
      color: 'var(--text)',
    },
    '& .MuiInputLabel-root': {
      color: 'var(--text-secondary)',
    },
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: 'var(--border)',
      },
      '&:hover fieldset': {
        borderColor: 'var(--text-muted)',
      },
      '&.Mui-focused fieldset': {
        borderColor: 'var(--accent)',
      },
    },
    '& .MuiFormHelperText-root': {
      color: 'var(--text-secondary)',
    },
  };

  const buttonStyles = {
    backgroundColor: 'var(--accent)',
    color: 'var(--text)',
    fontWeight: '600',
    '&:hover': {
      backgroundColor: 'var(--accent-hover)',
    },
    '&:disabled': {
      backgroundColor: 'var(--border-strong)',
      color: 'var(--text-muted)'
    }
  };

  // const cancelButtonStyles = {
  //   color: 'var(--text)',
  //   backgroundColor: 'var(--border-strong)',
  //   fontWeight: '600',
  //   '&:hover': {
  //     backgroundColor: 'var(--text-muted)',
  //   }
  // };

  return (
    <Box
      sx={embedded ? { display: 'block' } : {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: 'var(--surface)',
        p: isMobile ? 0 : 2
      }}
    >
      {loading && (
        <Box
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: 1300
          }}
        >
          <HashLoader color="var(--accent)" size={80} />
        </Box>
      )}

      <Box
        sx={{
          width: '100%',
          height: isMobile ? '100vh' : 'auto',
          maxWidth: isMobile ? '100%' : '450px',
          backgroundColor: 'var(--surface)',
          borderRadius: isMobile ? 0 : '8px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
          border: isMobile ? 'none' : '1px solid #f3f4f6',
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        <Box sx={{ p: isMobile ? '16px' : '24px', flex: 1 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            {!embedded && (<MuiButton
              startIcon={<ArrowBackIcon />}
              onClick={handleBackClick}
              sx={{ color: 'var(--text)' }}
            >
              {isMobile ? '' : 'Back'}
            </MuiButton>)}
          </Box>

          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <LockIcon sx={{
              fontSize: isMobile ? 40 : 50,
              color: 'var(--accent)',
              mb: 1
            }} />
            <Typography
              variant={isMobile ? 'h6' : 'h5'}
              component="h1"
              sx={{ color: 'var(--text)', fontWeight: '600' }}
            >
              Change Password
            </Typography>
            <Typography
              variant={isMobile ? 'body2' : 'body1'}
              sx={{ color: 'var(--text-secondary)', mt: 1 }}
            >
              Secure your account with a new password
            </Typography>
          </Box>

          <Divider sx={{ borderColor: '#f3f4f6', mb: 3 }} />

          <Box
            component="form"
            onSubmit={handleSubmit(submitHandler)}
            sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}
          >
            <TextField
              label="Current Password"
              type={showPassword.oldPassword ? 'text' : 'password'}
              variant="outlined"
              fullWidth
              {...register("oldPassword", {
                required: "Current password is required",
                minLength: {
                  value: 8,
                  message: "Password must be at least 8 characters"
                }
              })}
              error={!!errors.oldPassword}
              helperText={errors.oldPassword?.message}
              sx={textFieldStyles}
              size={isMobile ? 'small' : 'medium'}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start" sx={{ color: 'var(--text-muted)' }}>
                    <LockIcon fontSize={isMobile ? 'small' : 'medium'} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => togglePasswordVisibility('oldPassword')}
                      edge="end"
                      sx={{ color: 'var(--text-muted)' }}
                      size={isMobile ? 'small' : 'medium'}
                    >
                      {showPassword.oldPassword ? <VisibilityOff fontSize={isMobile ? 'small' : 'medium'} /> : <Visibility fontSize={isMobile ? 'small' : 'medium'} />}
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />

            <TextField
              label="New Password"
              type={showPassword.newPassword ? 'text' : 'password'}
              variant="outlined"
              fullWidth
              {...register("newPassword", {
                required: "New password is required",
                minLength: {
                  value: 8,
                  message: "Password must be at least 8 characters"
                },
                validate: {
                  hasNumber: value => /\d/.test(value) || "Should contain at least one number",
                  hasSpecialChar: value => /[!@#$%^&*(),.?":{}|<>]/.test(value) || "Should contain at least one special character"
                }
              })}
              error={!!errors.newPassword}
              helperText={errors.newPassword?.message}
              sx={textFieldStyles}
              size={isMobile ? 'small' : 'medium'}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start" sx={{ color: 'var(--text-muted)' }}>
                    <LockOpenIcon fontSize={isMobile ? 'small' : 'medium'} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => togglePasswordVisibility('newPassword')}
                      edge="end"
                      sx={{ color: 'var(--text-muted)' }}
                      size={isMobile ? 'small' : 'medium'}
                    >
                      {showPassword.newPassword ? <VisibilityOff fontSize={isMobile ? 'small' : 'medium'} /> : <Visibility fontSize={isMobile ? 'small' : 'medium'} />}
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />

            <TextField
              label="Confirm New Password"
              type={showPassword.confirmPassword ? 'text' : 'password'}
              variant="outlined"
              fullWidth
              {...register("confirmPassword", {
                required: "Please confirm your new password",
                validate: value => value === newPassword || "Passwords do not match"
              })}
              error={!!errors.confirmPassword}
              helperText={errors.confirmPassword?.message}
              sx={textFieldStyles}
              size={isMobile ? 'small' : 'medium'}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start" sx={{ color: 'var(--text-muted)' }}>
                    <VerifiedIcon fontSize={isMobile ? 'small' : 'medium'} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => togglePasswordVisibility('confirmPassword')}
                      edge="end"
                      sx={{ color: 'var(--text-muted)' }}
                      size={isMobile ? 'small' : 'medium'}
                    >
                      {showPassword.confirmPassword ? <VisibilityOff fontSize={isMobile ? 'small' : 'medium'} /> : <Visibility fontSize={isMobile ? 'small' : 'medium'} />}
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />

            <MuiButton
              type="submit"
              variant="contained"
              fullWidth
              disabled={loading}
              sx={buttonStyles}
              startIcon={<LockIcon />}
              size={isMobile ? 'small' : 'medium'}
            >
              {loading ? 'Updating...' : 'Change Password'}
            </MuiButton>
          </Box>
        </Box>
      </Box>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        sx={{
          bottom: { xs: 70, sm: 24 }
        }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbarSeverity}
          variant="filled"
          sx={{
            width: '100%',
            backgroundColor: snackbarSeverity === 'success' ? 'var(--accent)' : '#DC2626',
            color: 'var(--text)',
            '& .MuiAlert-icon': {
              color: 'var(--text)'
            }
          }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ChangePassword;