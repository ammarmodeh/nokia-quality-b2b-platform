import { useState, useEffect, useRef, useMemo } from "react";
import { IoMdAdd } from "react-icons/io";
import { FaList } from "react-icons/fa";
import { MdClose, MdGridView, MdOutlineSearch, MdFilterList, MdExpandMore, MdExpandLess } from "react-icons/md";
import {
  Tabs, Tab, Stack, Typography, TextField, IconButton, Box, Button, CircularProgress,
  useMediaQuery, MenuItem, FormControl, InputLabel, Select, Grid, Collapse, Paper
} from "@mui/material";
import { HourglassEmpty, PlayCircle, CheckCircle, Warning, Speed, VerifiedUser, Security } from "@mui/icons-material";
import AddTask from "../components/task/AddTask";
import api from "../api/api";
import { PulseLoader } from "react-spinners";
import { useInfiniteQuery } from "@tanstack/react-query";
import { useInView } from "react-intersection-observer";
import TaskCard from "../components/TaskCard";
import { useSelector } from "react-redux";

const TABS = [
  { title: "Board View", icon: <MdGridView /> },
  { title: "List View", icon: <FaList /> },
];

const Tasks = () => {
  const user = useSelector((state) => state?.auth?.user);
  // console.log({ user });
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState(0);
  const [open, setOpen] = useState(false);
  const [updateRefetchTasks, setUpdateRefetchTasks] = useState(false);
  const [updateStateDuringSave, setUpdateStateDuringSave] = useState(false);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [allTasks, setAllTasks] = useState([]);
  const [fieldTeams, setFieldTeams] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const searchInputRef = useRef(null);

  // Advanced Filters State
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [validationFilter, setValidationFilter] = useState("all");
  const [teamFilter, setTeamFilter] = useState("all");

  const { ref, inView } = useInView();
  const [trashActionState, setTrashActionState] = useState({
    loading: false,
    error: null,
    success: false
  });

  // Media queries for responsive design
  const isSmallScreen = useMediaQuery('(max-width:600px)');
  const isMediumScreen = useMediaQuery('(max-width:900px)');

  // Fetch all users and field teams
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [usersRes, teamsRes] = await Promise.all([
          api.get("/users/get-all-users", { headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` } }),
          api.get("/field-teams/get-field-teams", { headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` } })
        ]);
        setUsers(usersRes.data);
        setFieldTeams(teamsRes.data);
      } catch (error) { }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchAllTasks = async () => {
      try {
        const { data } = await api.get("/tasks/get-all-tasks", {
          headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` },
        });
        setAllTasks(data);
      } catch (error) {
        // console.error("Error fetching all tasks:", error);
      }
    };
    fetchAllTasks();
  }, [updateStateDuringSave, updateRefetchTasks]);

  const TASKS_PER_PAGE = 50;

  const fetchTasks = async ({ pageParam = 1 }) => {
    try {
      const params = new URLSearchParams({
        page: pageParam,
        limit: TASKS_PER_PAGE,
        status: statusFilter,
        priority: priorityFilter,
        validationStatus: validationFilter,
        teamId: teamFilter,
        search: searchTerm
      });

      const { data } = await api.get(`/tasks/get-tasks?${params.toString()}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` },
      });
      return data.data || [];
    } catch (error) {
      throw error;
    }
  };

  const { data, status, error, fetchNextPage, isFetchingNextPage, hasNextPage } = useInfiniteQuery({
    queryKey: ['all-tasks', statusFilter, priorityFilter, validationFilter, teamFilter, searchTerm],
    queryFn: fetchTasks,
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage.length === 0 || lastPage.length < TASKS_PER_PAGE) {
        return undefined;
      }
      return allPages.length + 1;
    }
  });

  useEffect(() => {
    if (inView && hasNextPage && !searchTerm) {
      fetchNextPage();
    }
  }, [inView, hasNextPage, fetchNextPage, searchTerm]);

  const tasks = useMemo(() => (data ? data.pages.flat() : []), [data]);

  useEffect(() => {
    if (tasks.length > 0 && !searchTerm) {
      setFilteredTasks(tasks);
    }
  }, [tasks, searchTerm]);

  const calculateStatusStats = () => {
    const totalTasks = allTasks.length;
    let todo = 0, inProgress = 0, closed = 0;
    allTasks.forEach(task => {
      if (task.status === "Todo") todo++;
      else if (task.status === "Closed") closed++;
      else inProgress++;
    });

    return {
      todo: { count: todo, percentage: totalTasks > 0 ? (todo / totalTasks) * 100 : 0 },
      inProgress: { count: inProgress, percentage: totalTasks > 0 ? (inProgress / totalTasks) * 100 : 0 },
      closed: { count: closed, percentage: totalTasks > 0 ? (closed / totalTasks) * 100 : 0 },
    };
  };

  const statusStats = calculateStatusStats();

  const handleSearchClick = () => {
    const term = searchInputRef.current.value.trim().toLowerCase();
    setSearchTerm(term);
    if (term === "") {
      setFilteredTasks(allTasks);
    } else {
      const filtered = allTasks.filter((task) =>
        task.slid.toLowerCase().includes(term)
      );
      setFilteredTasks(filtered);
    }
  };

  const handleClearSearch = () => {
    setSearchTerm("");
    searchInputRef.current.value = "";
    setFilteredTasks(tasks);
  };

  if (status === "pending") {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
      </Box>
    );
  }

  if (status === "error") {
    return (
      <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" height="100vh">
        <Typography variant="h6" color="error" gutterBottom>
          Oops! Something went wrong.
        </Typography>
        <Typography variant="body2" color="textSecondary">
          {error.message}
        </Typography>
        <Button variant="contained" color="primary" onClick={() => fetchNextPage()}>
          Retry
        </Button>
      </Box>
    );
  }

  const handleTaskUpdate = (updatedTask) => {
    setFilteredTasks((prevTasks) =>
      prevTasks.map((task) => (task._id === updatedTask._id ? updatedTask : task))
    );
  };

  const handleTaskDelete = async (taskId) => {
    const confirmDelete = window.confirm("Are you sure you want to move this task to trash?");
    if (!confirmDelete) return;
    setTrashActionState({ loading: true, error: null, success: false });

    try {
      // First get the complete task data
      const { data: taskData } = await api.get(`/tasks/get-task/${taskId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` }
      });

      if (!taskData) {
        throw new Error("Task not found");
      }

      // Move to trash with additional metadata
      const trashResponse = await api.post('/trash/add-trash', {
        ...taskData, // Spread all task fields
        deletedBy: user._id,
        deletionReason: 'Deleted by user',
        deletedAt: new Date()
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` }
      });

      if (trashResponse.status === 201) {
        // Only delete from main collection if trash operation succeeded
        await api.delete(`/tasks/delete-task/${taskId}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` }
        });

        // Update UI state
        setFilteredTasks(prev => prev.filter(task => task._id !== taskId));
        setAllTasks(prev => prev.filter(task => task._id !== taskId));

        alert("Task moved to trash successfully");
      } else {
        throw new Error("Failed to move task to trash");
      }
      setTrashActionState({ loading: false, error: null, success: true });
    } catch (error) {
      // console.error("Error in handleTaskDelete:", error);
      alert(`Error: ${error.message}`);
      setTrashActionState({ loading: false, error: error.message, success: false });
    }
  };


  const handleTaskArchive = async (taskId) => {
    const confirmArchive = window.confirm("Are you sure you want to archive this task?");
    if (!confirmArchive) return;
    setTrashActionState({ loading: true, error: null, success: false });

    try {
      const { data: taskData } = await api.get(`/tasks/get-task/${taskId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` }
      });

      if (!taskData) {
        throw new Error("Task not found");
      }

      // Archive the task
      const archiveResponse = await api.post('/archive/add-archive', {
        taskData,
        archivedBy: user._id,
        archivedAt: new Date(),
        archiveReason: 'Archived by admin'
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` }
      });

      if (archiveResponse.status === 201) {
        // Delete from main collection
        await api.delete(`/tasks/delete-task/${taskId}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` }
        });

        // Update UI state
        setFilteredTasks(prev => prev.filter(task => task._id !== taskId));
        setAllTasks(prev => prev.filter(task => task._id !== taskId));

        alert("Task archived successfully");
      } else {
        throw new Error("Failed to archive task");
      }
      setTrashActionState({ loading: false, error: null, success: true });
    } catch (error) {
      // console.error("Error in handleTaskArchive:", error);
      alert(`Error: ${error.message}`);
      setTrashActionState({ loading: false, error: error.message, success: false });
    }
  };

  const handleFavoriteClick = async (task) => {
    try {
      const response = await api.post("/favourites/add-favourite", {
        task,
        userId: user._id,
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem("accessToken")}` },
      });

      if (response.status === 201) {
        alert("Task added to favorites successfully!");
      } else if (response.data?.isAlreadyFavorited) {
        alert("This task is already in your favorites list!");
      }
    } catch (error) {
      if (error.response && error.response.data && error.response.data.isAlreadyFavorited) {
        alert("This task is already in your favorites list!");
      } else {
        // console.error("Error updating favorite status:", error);
        alert("Failed to add to favorites. Please try again.");
      }
    }
  };

  const handleTabChange = (event, newValue) => {
    setSelected(newValue);
  };

  return (
    <Box sx={{ padding: isSmallScreen ? 1 : 2 }}>
      <Typography variant="h5" sx={{ fontWeight: "bold", color: "#727272", fontSize: isSmallScreen ? '1rem' : '1.5rem', mb: 2 }} gutterBottom>
        All Tasks &gt; All Tasks
      </Typography>
      <Stack
        direction={isSmallScreen ? "column" : "row"}
        justifyContent="space-between"
        alignItems={isSmallScreen ? "flex-start" : "center"}
        spacing={isSmallScreen ? 2 : 0}
        sx={{ mb: 2 }}
      >
        <Tabs
          value={selected}
          onChange={handleTabChange}
          aria-label="task tabs"
          TabIndicatorProps={{
            style: {
              height: "2px",
              backgroundColor: "#2196f3",
            },
          }}
          variant={isSmallScreen ? "scrollable" : "standard"}
          scrollButtons="auto"
          sx={{
            maxWidth: '100%',
            display: 'none' // This will hide the Tabs for all screen sizes
          }}
        >
          {TABS.map((tab, index) => (
            <Tab
              key={index}
              icon={tab.icon}
              disabled={index !== 0}
              label={isSmallScreen ? null : tab.title}
              iconPosition="start"
              sx={{ minWidth: 'unset', px: isSmallScreen ? 1 : 2 }}
            />
          ))}
        </Tabs>
        {user && user.role === "Admin" && (
          <Button
            sx={{
              gap: 1,
              ml: isSmallScreen ? 0 : 2,
              width: isSmallScreen ? '100%' : 'auto'
            }}
            variant="outlined"
            onClick={() => setOpen(true)}
          >
            <IoMdAdd size={20} className="text-lg text-[#1976D2]" />
            <Typography variant="caption" sx={{ fontWeight: "bold", fontSize: "15px" }} className="text-[#1976D2]">
              Create Task
            </Typography>
          </Button>
        )}
      </Stack>

      <Stack
        direction={isSmallScreen ? "column" : "row"}
        alignItems={isSmallScreen ? "flex-start" : "center"}
        justifyContent="space-between"
        spacing={isSmallScreen ? 2 : 0}
        sx={{ mb: 2 }}
      >
        <Box sx={{
          width: '100%',
          overflowX: 'auto',
          whiteSpace: 'nowrap',
          py: 1,
          scrollbarWidth: 'none',
          '&::-webkit-scrollbar': {
            display: 'none'
          }
        }}>
          <Stack direction="row" alignItems="center" spacing={1.5}>
            <Stack
              direction="row"
              alignItems="center"
              spacing={1}
              sx={{
                background: "rgba(234, 179, 8, 0.1)",
                backdropFilter: "blur(10px)",
                px: 2, py: 1, borderRadius: 3,
                color: "#eab308",
                border: "1px solid rgba(234, 179, 8, 0.2)",
                minWidth: 'max-content'
              }}
            >
              <HourglassEmpty sx={{ fontSize: "18px" }} />
              <Typography variant="caption" sx={{ fontWeight: 900, letterSpacing: '0.5px' }}>
                TODO: {statusStats.todo.count} ({statusStats.todo.percentage.toFixed(0)}%)
              </Typography>
            </Stack>

            <Stack
              direction="row"
              alignItems="center"
              spacing={1}
              sx={{
                background: "rgba(59, 130, 246, 0.1)",
                backdropFilter: "blur(10px)",
                px: 2, py: 1, borderRadius: 3,
                color: "#3b82f6",
                border: "1px solid rgba(59, 130, 246, 0.2)",
                minWidth: 'max-content'
              }}
            >
              <PlayCircle sx={{ fontSize: "18px" }} />
              <Typography variant="caption" sx={{ fontWeight: 900, letterSpacing: '0.5px' }}>
                IN PROGRESS: {statusStats.inProgress.count} ({statusStats.inProgress.percentage.toFixed(0)}%)
              </Typography>
            </Stack>

            <Stack
              direction="row"
              alignItems="center"
              spacing={1}
              sx={{
                background: "rgba(34, 197, 94, 0.1)",
                backdropFilter: "blur(10px)",
                px: 2, py: 1, borderRadius: 3,
                color: "#22c55e",
                border: "1px solid rgba(34, 197, 94, 0.2)",
                minWidth: 'max-content'
              }}
            >
              <CheckCircle sx={{ fontSize: "18px" }} />
              <Typography variant="caption" sx={{ fontWeight: 900, letterSpacing: '0.5px' }}>
                CLOSED: {statusStats.closed.count} ({statusStats.closed.percentage.toFixed(0)}%)
              </Typography>
            </Stack>
          </Stack>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            width: "100%",
            maxWidth: "600px",
            py: 1,
            px: 2,
            gap: 1,
            borderRadius: "999px",
            backgroundColor: "var(--surface)",
            border: "1px solid var(--border)",
            "&:focus-within": {
              borderColor: "var(--accent)",
            },
          }}
        >
          <MdOutlineSearch className="text-[var(--text-muted)] text-xl" />
          <TextField
            fullWidth
            variant="standard"
            placeholder="Search tasks by SLID..."
            inputRef={searchInputRef}
            onChange={(e) => !e.target.value && handleClearSearch()}
            onKeyPress={(e) => e.key === 'Enter' && handleSearchClick()}
            sx={{
              "& .MuiInputBase-root": { backgroundColor: "transparent", color: "var(--text)" },
              "& .MuiInputBase-input": { fontSize: "14px", color: "var(--text)", padding: 0 },
              "& .MuiInput-root:before, & .MuiInput-root:after": { borderBottom: "none" },
            }}
            InputProps={{
              disableUnderline: true,
              endAdornment: searchTerm && (
                <IconButton size="small" onClick={handleClearSearch} sx={{ color: "var(--text-secondary)" }}><MdClose /></IconButton>
              ),
            }}
          />
          <IconButton onClick={() => setShowFilters(!showFilters)} size="small" sx={{ color: showFilters ? "#7b68ee" : "#888" }}>
            <MdFilterList />
          </IconButton>
          <Button
            variant="contained"
            onClick={handleSearchClick}
            size="small"
            sx={{
              backgroundColor: "#323232",
              color: "var(--text)",
              borderRadius: "999px",
              "&:hover": { backgroundColor: "#1d4ed8" },
              fontSize: "14px",
              textTransform: "none",
              px: 2,
            }}
          >
            Search
          </Button>
        </Box>
      </Stack>

      {/* Advanced Filter Collapse */}
      <Collapse in={showFilters}>
        <Paper sx={{ p: 3, bgcolor: "var(--surface)", borderRadius: 4, mb: 3, border: "1px solid var(--border)" }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel sx={{ color: "var(--text-muted)" }}>Priority</InputLabel>
                <Select
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value)}
                  label="Priority"
                  sx={{ color: "var(--text)", ".MuiOutlinedInput-notchedOutline": { borderColor: "var(--border)" } }}
                >
                  <MenuItem value="all">All Priorities</MenuItem>
                  <MenuItem value="High">🔴 High</MenuItem>
                  <MenuItem value="Medium">🟠 Medium</MenuItem>
                  <MenuItem value="Low">🔵 Low</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel sx={{ color: "var(--text-muted)" }}>Status</InputLabel>
                <Select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  label="Status"
                  sx={{ color: "var(--text)", ".MuiOutlinedInput-notchedOutline": { borderColor: "var(--border)" } }}
                >
                  <MenuItem value="all">All Statuses</MenuItem>
                  <MenuItem value="Todo">⏳ Todo</MenuItem>
                  <MenuItem value="In Progress">⚡ In Progress</MenuItem>
                  <MenuItem value="Closed">✅ Closed</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel sx={{ color: "var(--text-muted)" }}>Validation</InputLabel>
                <Select
                  value={validationFilter}
                  onChange={(e) => setValidationFilter(e.target.value)}
                  label="Validation"
                  sx={{ color: "var(--text)", ".MuiOutlinedInput-notchedOutline": { borderColor: "var(--border)" } }}
                >
                  <MenuItem value="all">All Validation</MenuItem>
                  <MenuItem value="Pending">🕒 Pending</MenuItem>
                  <MenuItem value="Validated">🛡️ Validated</MenuItem>
                  <MenuItem value="Rejected">❌ Rejected</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel sx={{ color: "var(--text-muted)" }}>Field Team</InputLabel>
                <Select
                  value={teamFilter}
                  onChange={(e) => setTeamFilter(e.target.value)}
                  label="Field Team"
                  sx={{ color: "var(--text)", ".MuiOutlinedInput-notchedOutline": { borderColor: "var(--border)" } }}
                >
                  <MenuItem value="all">All Teams</MenuItem>
                  {fieldTeams.map(team => (
                    <MenuItem key={team._id} value={team._id}>{team.teamName}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
            <Button size="small" onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); setValidationFilter("all"); setTeamFilter("all"); }} sx={{ color: "var(--accent-text)" }}>Reset Filters</Button>
          </Box>
        </Paper>
      </Collapse>

      {selected === 0 ? (
        <Box>
          {filteredTasks.length === 0 ? (
            <Typography align="center" color="textSecondary" sx={{ mt: 3, color: "antiquewhite" }}>
              No tasks found.
            </Typography>
          ) : (
            <>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: isSmallScreen ? '1fr' :
                    isMediumScreen ? 'repeat(2, 1fr)' : 'repeat(auto-fill, minmax(300px, 1fr))',
                  gap: 2,
                  mt: 3
                }}
              >
                {filteredTasks.map((task, index) => (
                  <TaskCard
                    key={`task-${task._id}-${index}`}
                    task={task}
                    users={users}
                    handleTaskUpdate={handleTaskUpdate}
                    handleTaskDelete={handleTaskDelete}
                    handleTaskArchive={handleTaskArchive}
                    handleFavoriteClick={handleFavoriteClick}
                    setUpdateStateDuringSave={setUpdateStateDuringSave}
                    trashActionState={trashActionState}
                  />
                ))}
              </Box>
              <Box sx={{ my: 2, display: 'flex', justifyContent: 'center' }} ref={ref}>
                {isFetchingNextPage ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: "50px" }}>
                    <PulseLoader speedMultiplier={2} size={15} color="#e5e5e5" />
                  </Box>
                ) : (
                  <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: "50px" }}></Box>
                )}
              </Box>
            </>
          )}
        </Box>
      ) : (
        <Box sx={{ width: '100%', textAlign: 'center', mt: 3 }}>
          <Typography variant="body1">
            Currently, the list view is not implemented
          </Typography>
        </Box>
      )}

      <AddTask open={open} setOpen={setOpen} setUpdateRefetchTasks={setUpdateRefetchTasks} />
    </Box>
  );
};

export default Tasks;