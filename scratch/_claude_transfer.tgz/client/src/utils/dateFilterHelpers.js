import { startOfWeek, endOfWeek, format } from 'date-fns';
import { getCustomWeekNumber, generateMonthRanges, getMonthNumber } from './helpers';

/**
 * Filter tasks by a specific week
 * @param {Array} tasks - Array of tasks
 * @param {number} year - The year
 * @param {number} weekNumber - The custom week number
 * @returns {Array} Filtered tasks
 */
export const filterTasksByWeek = (tasks, year, weekNumber, settings = {}) => {
  if (!Array.isArray(tasks)) return [];
  const { weekStartDay = 0 } = settings;
  return tasks.filter(task => {
    if (!task.interviewDate) return false;
    const date = new Date(task.interviewDate);

    // Calculate the start of the week for this task
    const weekStart = startOfWeek(date, { weekStartsOn: weekStartDay });
    const weekYear = weekStart.getFullYear();

    // We filter based on the year of the *week start* to be consistent
    if (weekYear !== year) return false;

    // Calculate week number based on the start of the week
    return getCustomWeekNumber(weekStart, weekYear, settings) === weekNumber;
  });
};

/**
 * Filter tasks by a specific month (Using new configurable logic)
 * @param {Array} tasks - Array of tasks
 * @param {number} year - The year (ignored in favor of settings configuration ranges)
 * @param {number} month - The month number (1-12)
 * @returns {Array} Filtered tasks
 */
export const filterTasksByMonth = (tasks, year, month, settings = {}) => {
  if (!Array.isArray(tasks)) return [];

  return tasks.filter(task => {
    if (!task.interviewDate) return false;
    const d = new Date(task.interviewDate);
    // Ignore invalid dates
    if (isNaN(d.getTime())) return false;
    
    // Check if task matches the requested year and calendar month (1-based index)
    return d.getFullYear() === year && (d.getMonth() + 1) === Number(month);
  });
};

/**
 * Filter tasks by a custom date range
 * @param {Array} tasks - Array of tasks
 * @param {string|Date} startDate - Start date
 * @param {string|Date} endDate - End date
 * @returns {Array} Filtered tasks
 */
export const filterTasksByDateRange = (tasks, startDate, endDate) => {
  if (!Array.isArray(tasks)) return [];
  if (!startDate || !endDate) return tasks;

  const start = new Date(startDate);
  start.setHours(0, 0, 0, 0);

  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999);

  return tasks.filter(task => {
    if (!task.interviewDate) return false;
    const taskDate = new Date(task.interviewDate);
    return taskDate >= start && taskDate <= end;
  });
};

/**
 * Get list of available weeks with data
 * @param {Array} tasks - Array of tasks
 * @returns {Array} Array of {year, week, label, start, end}
 */
export const getAvailableWeeks = (tasks, settings = {}) => {
  if (!Array.isArray(tasks)) return [];
  const safeSettings = settings || {};
  const { weekStartDay = 0, week1StartDate = null, week1EndDate = null, startWeekNumber = 1 } = safeSettings;
  const weeks = new Map();

  // 1. Collect weeks from tasks
  tasks.forEach(task => {
    if (!task.interviewDate) return;
    const date = new Date(task.interviewDate);

    // Always use the start of the week to calculate week number
    const start = startOfWeek(date, { weekStartsOn: weekStartDay });
    const end = endOfWeek(date, { weekStartsOn: weekStartDay });
    const year = start.getFullYear();

    // Use the Sunday to get the custom week number
    const weekNumber = getCustomWeekNumber(start, year, settings);
    const key = `${year}-W${weekNumber}`;

    if (!weeks.has(key)) {
      weeks.set(key, {
        year,
        week: weekNumber,
        key,
        label: `Week ${weekNumber} (${format(start, 'MMM d')} - ${format(end, 'MMM d')})`,
        start,
        end
      });
    }
  });

  // 2. Safely add the CURRENT week if it's not present (even if no tasks)
  const today = new Date();
  const currentYear = today.getFullYear();
  const currentWeekStart = startOfWeek(today, { weekStartsOn: weekStartDay });
  const currentWeekEnd = endOfWeek(today, { weekStartsOn: weekStartDay });
  const currentWeekNumber = getCustomWeekNumber(currentWeekStart, currentYear, settings);
  const currentKey = `${currentYear}-W${currentWeekNumber}`;

  if (!weeks.has(currentKey)) {
    weeks.set(currentKey, {
      year: currentYear,
      week: currentWeekNumber,
      key: currentKey,
      label: `Week ${currentWeekNumber} (${format(currentWeekStart, 'MMM d')} - ${format(currentWeekEnd, 'MMM d')})`,
      start: currentWeekStart,
      end: currentWeekEnd
    });
  }

  // Sort by year desc, then week desc
  return Array.from(weeks.values()).sort((a, b) => {
    if (a.year !== b.year) return b.year - a.year;
    return b.week - a.week;
  });
};

/**
 * Get list of available months (Custom Logic)
 * @param {Array} tasks - Array of tasks
 * @returns {Array} Array of {year, month, label}
 */
export const getAvailableMonths = (tasks, settings = {}) => {
  if (!Array.isArray(tasks)) return [];
  const ranges = generateMonthRanges(tasks, settings);

  // We want to return all generated ranges (or maybe just those that encompass 'tasks' dates?)
  // For 'Available', typically we show what is possible to select.
  // Since ranges are fixed by settings, we display them all.
  // Optionally filter if no data exists, but user might want to see empty month.

  return ranges.map(range => {
    // extract number from key "Month-1"
    const monthNum = parseInt(range.key.split('-')[1]);
    const label = range.label; // range.label already contains the formatted month and date range

    return {
      year: range.start.getFullYear(),
      month: monthNum, // Using number as ID
      key: range.key,
      label: label,
      value: monthNum,
      start: range.start,
      end: range.end
    };
  });
};

/**
 * Calculate trend data for teams or reasons over time periods
 * @param {Array} tasks - Array of tasks
 * @param {string} period - 'week' or 'month'
 * @param {number|string} periodsCount - Number of periods to analyze or 'all'
 * @param {string} groupBy - 'team' or 'reason'
 * @param {Object} dateRange - { start, end } optional custom range
 * @returns {Object} Trend data by group (team name or reason)
 */
export const calculateTrendData = (tasks, period = 'week', periodsCount = 8, groupBy = 'team', dateRange = null, settings = {}) => {
  if (!Array.isArray(tasks)) return {};
  const allPeriods = period === 'week' ? getAvailableWeeks(tasks, settings) : getAvailableMonths(tasks, settings);

  let periodsToAnalyze = [];

  if (dateRange && dateRange.start && dateRange.end) {
    // Filter periods that fall within the custom range
    const start = new Date(dateRange.start);
    start.setHours(0, 0, 0, 0);
    const end = new Date(dateRange.end);
    end.setHours(23, 59, 59, 999);

    periodsToAnalyze = allPeriods.filter(p => {
      let periodDate;
      if (period === 'week') {
        periodDate = p.start; // Week start date
      } else {
        periodDate = new Date(p.year, p.month, 1); // Month start date
      }
      return periodDate >= start && periodDate <= end;
    }).reverse(); // Chronological order
  } else {
    // Standard count-based logic
    periodsToAnalyze = periodsCount === 'all'
      ? [...allPeriods].reverse()
      : allPeriods.slice(0, periodsCount).reverse();
  }

  const trendData = {};

  // 1. First, identify ALL unique keys (teams or reasons) that appear in these periods
  // We need to check all tasks that fall into any of these periods.
  // A simple way is to iterate periods, get tasks, and collect keys.
  const relevantKeys = new Set();

  periodsToAnalyze.forEach(periodInfo => {
    const tasksInPeriod = period === 'week'
      ? filterTasksByWeek(tasks, periodInfo.year, periodInfo.week, settings)
      : filterTasksByMonth(tasks, periodInfo.year, periodInfo.month, settings);

    tasksInPeriod.forEach(task => {
      let key;
      if (groupBy === 'reason') {
        key = task.reason || 'Unspecified';
      } else {
        key = task.teamName;
      }
      if (key) relevantKeys.add(key);
    });
  });

  // 2. Initialize trendData for all keys with ZERO-filled arrays
  const periodLabels = periodsToAnalyze.map(p =>
    period === 'week'
      ? `W${p.week}`
      : p.label.split(' ')[0].substring(0, 3)
  );

  relevantKeys.forEach(key => {
    trendData[key] = {
      periods: periodLabels,
      detractors: new Array(periodsToAnalyze.length).fill(0),
      neutrals: new Array(periodsToAnalyze.length).fill(0),
      totalViolations: new Array(periodsToAnalyze.length).fill(0),
      equivalentDetractors: new Array(periodsToAnalyze.length).fill(0),
      tasks: {}, // Store tasks by period label
      allTasks: [] // Store all tasks across all periods
    };
  });

  // 3. Iterate periods and fill data
  periodsToAnalyze.forEach((periodInfo, index) => {
    const tasksInPeriod = period === 'week'
      ? filterTasksByWeek(tasks, periodInfo.year, periodInfo.week, settings)
      : filterTasksByMonth(tasks, periodInfo.year, periodInfo.month, settings);

    const periodLabel = periodLabels[index];

    tasksInPeriod.forEach(task => {
      let key;
      if (groupBy === 'reason') {
        key = task.reason || 'Unspecified';
      } else {
        key = task.teamName;
      }

      if (!trendData[key]) return; // Should not happen given step 1

      // Initialize tasks array for this period if not exists
      if (!trendData[key].tasks[periodLabel]) {
        trendData[key].tasks[periodLabel] = [];
      }

      // Store the task object
      trendData[key].tasks[periodLabel].push(task);
      trendData[key].allTasks.push(task);

      // Count violations
      if (task.evaluationScore >= 1 && task.evaluationScore <= 6) {
        trendData[key].detractors[index]++;
        trendData[key].totalViolations[index]++;
      } else if (task.evaluationScore >= 7 && task.evaluationScore <= 8) {
        trendData[key].neutrals[index]++;
        trendData[key].totalViolations[index]++;
      }

      // Track reason frequency (only if it's a violation)
      if (task.evaluationScore <= 8) {
        if (!trendData[key].reasonCounts) trendData[key].reasonCounts = {};
        const reason = task.reason || 'Unspecified';
        trendData[key].reasonCounts[reason] = (trendData[key].reasonCounts[reason] || 0) + 1;
      }
    });
  });

  // 4. Calculate equivalent detractors and find top reason
  Object.keys(trendData).forEach(key => {
    // Equivalent Detractors
    trendData[key].equivalentDetractors = trendData[key].detractors.map((det, idx) => {
      const neut = trendData[key].neutrals[idx];
      return det + Math.floor(neut / 3);
    });

    // Top Reason & All Reasons
    let topReason = 'None';
    let topReasonCount = 0;
    let allReasons = [];

    if (trendData[key].reasonCounts) {
      allReasons = Object.entries(trendData[key].reasonCounts)
        .map(([reason, count]) => ({ reason, count }))
        .sort((a, b) => b.count - a.count);

      if (allReasons.length > 0) {
        topReason = allReasons[0].reason;
        topReasonCount = allReasons[0].count;
      }
    }
    trendData[key].allReasons = allReasons;
    trendData[key].topReason = topReason;
    trendData[key].topReasonCount = topReasonCount;
    // Cleanup temporary count map
    delete trendData[key].reasonCounts;
  });

  return trendData;
};

/**
 * Calculate percentage change between two values
 * @param {number} current - Current value
 * @param {number} previous - Previous value
 * @returns {number} Percentage change
 */
export const calculatePercentageChange = (current, previous) => {
  if (previous === 0) return current > 0 ? 100 : 0;
  return Math.round(((current - previous) / previous) * 100);
};
/**
 * Aggregate survey samples based on a specific period
 * @param {Array} samplesData - Array of sample objects {weekNumber, sampleSize, ...}
 * @param {string} type - 'week', 'month', or 'range'
 * @param {any} value - weekNumber, {month}, or {start, end, ...}
 * @param {Object} settings - { weekStartDay, startWeekNumber, month1StartDate, month1EndDate }
 * @returns {number} Sum of sample sizes
 */
export const aggregateSamples = (samplesData, type, value, settings = {}) => {
  if (!samplesData || samplesData.length === 0) return 0;

  if (type === 'week') {
    const weekNum = typeof value === 'object' ? value.weekNumber : value;
    const year = typeof value === 'object' ? value.year : null;
    const startDate = typeof value === 'object' ? value.startDate : null;

    // Try to find exact match by weekNumber and year first
    const matches = samplesData.filter(s => {
      const sWeek = s.weekNumber !== undefined ? s.weekNumber : s.week;
      const sYear = s.year;

      const mWeek = Number(sWeek) === Number(weekNum);
      const mYear = year ? Number(sYear) === Number(year) : true;

      if (mWeek && mYear) return true;

      // Secondary check: Robust Date comparison if weekNum/year didn't match perfectly
      if (startDate && s.startDate) {
        const d1 = new Date(startDate);
        const d2 = new Date(s.startDate);
        return d1.getFullYear() === d2.getFullYear() &&
          d1.getMonth() === d2.getMonth() &&
          d1.getDate() === d2.getDate();
      }

      return false;
    });

    return matches.reduce((sum, s) => sum + (Number(s.sampleSize) || 0), 0);
  }

  if (type === 'month') {
    const { month, year } = value;
    const targetMonth = Number(month);
    const targetYear = year ? Number(year) : null;

    // ── Priority 1: Manually-entered monthly total record ──────────────────
    // These are stored with weekNumber = 100 + month (e.g. Jan=101, Dec=112)
    const MONTH_WEEK_OFFSET = 100;
    const monthlyRecord = samplesData.find(
      s => Number(s.weekNumber) === MONTH_WEEK_OFFSET + targetMonth &&
           (!targetYear || Number(s.year) === targetYear)
    );
    if (monthlyRecord && Number(monthlyRecord.sampleSize) > 0) {
      return Number(monthlyRecord.sampleSize);
    }

    // ── Priority 2: Fall back to summing weekly sample sizes ──────────────
    return samplesData.filter(s => {
      // Skip month-marker records (weekNumber 101–112)
      if (Number(s.weekNumber) > MONTH_WEEK_OFFSET) return false;
      
      // Match year if provided
      if (targetYear && Number(s.year) !== targetYear) return false;

      // 1. Exact match on stored startDate
      if (s.startDate) {
        const sDate = new Date(s.startDate);
        return (sDate.getMonth() + 1) === targetMonth;
      }

      // 2. Estimate from week1StartDate setting
      if (settings.week1StartDate && s.weekNumber) {
        const w1Start = new Date(settings.week1StartDate);
        const estimatedStart = new Date(w1Start);
        estimatedStart.setDate(w1Start.getDate() + (s.weekNumber - 1) * 7);
        return (estimatedStart.getMonth() + 1) === targetMonth;
      }

      // 3. Rough fallback using year + weekNumber
      if (s.year && s.weekNumber) {
        const roughStart = new Date(s.year, 0, 1 + (s.weekNumber - 1) * 7);
        return (roughStart.getMonth() + 1) === targetMonth;
      }

      return false;
    }).reduce((sum, s) => sum + (Number(s.sampleSize) || 0), 0);
  }

  if (type === 'range') {
    const { start, end, weeksInterval } = value;
    if (!start || !end) return 0;

    const startDate = new Date(start);
    const endDate = new Date(end);

    const startMonth = startDate.getMonth() + 1;
    const startYear = startDate.getFullYear();
    const endMonth = endDate.getMonth() + 1;
    const endYear = endDate.getFullYear();

    // If the range falls entirely within a single calendar month, try the monthly token first.
    // This covers both full-month (Sep 1–30) AND partial-month (Sep 1–3) ranges.
    if (startMonth === endMonth && startYear === endYear) {
      const MONTH_WEEK_OFFSET = 100;
      const monthlyRecord = samplesData.find(
        s => Number(s.weekNumber) === MONTH_WEEK_OFFSET + startMonth &&
             Number(s.year) === startYear
      );
      if (monthlyRecord && Number(monthlyRecord.sampleSize) > 0) {
        return Number(monthlyRecord.sampleSize);
      }
    }

    // Fall back to summing weekly sample records that overlap the date range
    return samplesData.filter(s => {
      // Skip monthly-marker records (weekNumber 101–112)
      if (Number(s.weekNumber) > 100) return false;

      // Preferred: use sample startDate
      if (s.startDate) {
        const sDate = new Date(s.startDate);
        return sDate >= startDate && sDate <= endDate;
      }

      // Fallback: use weeksInterval lookup if provided
      if (weeksInterval && s.weekNumber) {
        const weekIdx = s.weekNumber - 1;
        const weekStart = weeksInterval[weekIdx];
        if (weekStart) {
          const weekEnd = new Date(weekStart);
          weekEnd.setDate(weekEnd.getDate() + 6);
          // Checking overlap
          return weekEnd >= startDate && weekStart <= endDate;
        }
      }

      return false;
    }).reduce((sum, s) => sum + (Number(s.sampleSize) || 0), 0);
  }

  // Default 'all' - Sum monthly targets (deduplicated)
  const uniqueTokensMap = new Map();
  samplesData.forEach(s => {
    const key = `${s.year}-${s.weekNumber}`;
    if (!uniqueTokensMap.has(key)) {
      uniqueTokensMap.set(key, s);
    }
  });

  return Array.from(uniqueTokensMap.values())
    .filter(s => s.weekNumber >= 101 && s.weekNumber <= 112)
    .reduce((sum, s) => sum + (Number(s.sampleSize) || 0), 0);
};
