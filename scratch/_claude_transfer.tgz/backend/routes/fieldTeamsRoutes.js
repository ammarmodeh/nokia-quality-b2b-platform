import express from "express";
import { protect, adminOnly } from "../middleware/authMiddleware.js";
import { addFieldTeam, getAllFieldTeams, deleteFieldTeam, updateFieldTeam, updateTeamScore, getFieldTeamByQuizCode, getTeamEvaluationHistory, suspendTeam, terminateTeam, reactivateTeam, onLeaveTeam, resignedTeam, addSession, bulkAddSession, getRecentSessions, updateSessionForTeam, deleteSessionForTeam, reportAbsence, getTeamViolations, toggleQuizPermission, validateTeam, loginFieldTeam } from "../controllers/fieldTeamsControllers.js";

const router = express.Router();

// Get field team by ID and quiz code
router.post('/login', loginFieldTeam);
router.post('/validate-team', validateTeam);

// Get field team by ID
// router.get("/get-field-team/:id", protect, getFieldTeamById);

// Get All Field Teams
router.get("/get-field-teams", protect, getAllFieldTeams);

// GET /field-teams/get-team-by-quiz-code/:quizCode
router.get('/get-team-by-quiz-code/:quizCode', getFieldTeamByQuizCode);

// Add New Field Team
router.post("/add-field-team", protect, addFieldTeam);


// Suspend field team
router.post("/suspend-field-team/:teamId", protect, suspendTeam);

// Terminate field team
router.post("/terminate-field-team/:teamId", protect, terminateTeam);

// reactivate field team
router.post("/reactivate-field-team/:teamId", protect, reactivateTeam);

// On Leave field team
router.post("/on-leave-field-team/:teamId", protect, onLeaveTeam);

// Resigned field team
router.post("/resigned-field-team/:teamId", protect, resignedTeam);


// Delete Field Team
router.delete("/delete-field-team/:id", protect, adminOnly, deleteFieldTeam);

// Update Field Team
router.put("/update-field-team/:id", protect, updateFieldTeam);

// Update team score
router.post('/update-score', updateTeamScore);

// Fetching evaluation history
router.get('/get-evaluation-history/:teamId', protect, getTeamEvaluationHistory);


// Add Session data
router.get("/get-recent-sessions", protect, getRecentSessions);
router.post("/bulk-add-session", protect, bulkAddSession);
router.post("/:teamId/add-session", protect, addSession);

router.put("/:teamId/update-session/:sessionId", protect, updateSessionForTeam);

// Example backend route (Express.js)
router.delete("/:teamId/delete-session/:sessionId", protect, deleteSessionForTeam);

router.post("/:teamId/report-absence", protect, reportAbsence);
router.get("/:teamId/violations", protect, getTeamViolations);

router.put('/toggle-quiz-permission/:id', toggleQuizPermission);

export default router;
