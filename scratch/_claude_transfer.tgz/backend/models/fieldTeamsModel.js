import mongoose from "mongoose";

const fieldTeamsSchema = new mongoose.Schema(
  {
    teamName: {
      type: String,
      required: [true, "Team Name is required"],
      trim: true,
    },
    teamCode: {
      type: String,
      required: [true, "Team Code is required"],
      trim: true,
    },

    firstName: {
      type: String,
      trim: true,
    },
    secondName: {
      type: String,
      trim: true,
    },
    thirdName: {
      type: String,
      trim: true,
    },
    surname: {
      type: String,
      trim: true,
    },
    teamCompany: {
      type: String,
      required: [true, "Team Company is required"],
      trim: true,
    },
    contactNumber: {
      type: String,
      required: [true, "Phone number is required"],
      match: [/^\+?[1-9]\d{1,14}$/, "Please enter a valid phone number"],
    },
    fsmSerialNumber: {
      type: String,
    },
    laptopSerialNumber: {
      type: String,
    },
    evaluationScore: {
      type: String,
      required: [true, "Satisfaction score is required"],
      default: "N/A",
    },
    evaluationHistory: [
      {
        score: String,
        date: { type: Date, default: Date.now },
        quizCode: String,
      },
    ],
    isEvaluated: {
      type: Boolean,
      default: false,
    },
    lastEvaluationDate: {
      type: Date,
      default: null,
    },
    quizCode: {
      type: String,
      required: true,
    },
    isSuspended: {
      type: Boolean,
      default: false,
    },
    suspensionStartDate: {
      type: Date,
      default: null,
    },
    suspensionEndDate: {
      type: Date,
      default: null,
    },
    suspensionReason: {
      type: String,
      default: null,
    },
    isTerminated: {
      type: Boolean,
      default: false,
    },
    terminationReason: {
      type: String,
      default: null,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    isOnLeave: {
      type: Boolean,
      default: false,
    },
    leaveReason: {
      type: String,
      default: null,
    },
    leaveStartDate: {
      type: Date,
      default: null,
    },
    leaveEndDate: {
      type: Date,
      default: null,
    },
    isResigned: {
      type: Boolean,
      default: false,
    },
    resignationReason: {
      type: String,
      default: null,
    },
    stateLogs: [
      {
        state: { type: String, enum: ["Active", "Suspended", "Terminated", "On Leave", "Resigned"], required: true },
        reason: { type: String, default: null },
        startDate: { type: Date, default: null },
        endDate: { type: Date, default: null },
        changedAt: { type: Date, default: Date.now },
      },
    ],
    sessionHistory: [
      {
        _id: { type: mongoose.Schema.Types.ObjectId, auto: true },
        sessionDate: { type: Date, required: true },
        conductedBy: { type: mongoose.Schema.Types.Mixed, required: true },
        location: { type: String },
        sessionType: {
          type: String
        },
        duration: { type: String },
        sessionTitle: { type: String },
        outlines: { type: mongoose.Schema.Types.Mixed },
        notes: { type: String, default: "" },
        status: {
          type: String,
          enum: ["Completed", "Missed", "Cancelled"],
          default: "Completed"
        },
        violationPoints: { type: Number, default: 0 },
        reason: { type: String, default: "" },
        violationType: { type: String }, // Added this field to replace violations.type
      },
    ],

    totalViolationPoints: {
      type: Number,
      default: 0
    },
    experienceYears: {
      type: Number,
      default: 0,
    },
    experienceMonths: {
      type: Number,
      default: 0,
    },
    experienceDays: {
      type: Number,
      default: 0,
    },
    yearsOfExperience: {
      type: Number,
      default: 0,
    },
    employmentType: {
      type: String,
      enum: ["Employee", "Subcontractor"],
      default: "Subcontractor",
    },
    dateOfBirth: {
      type: Date,
      default: null,
    },
    age: {
      type: Number,
      default: null,
    },
    certificates: {
      dd: { type: Boolean, default: false }, // DD: Defensive Driving
      es: { type: Boolean, default: false }, // ES: Electrical Safety
      fa: { type: Boolean, default: false }, // FA: First Aid
      ff: { type: Boolean, default: false }, // FF: Fire Fighting
      ra: { type: Boolean, default: false }, // RA: Risk Assessment
      wah: { type: Boolean, default: false }, // WAH: Work at Height
    },

    canTakeQuiz: {
      type: Boolean,
      default: false, // Default to true so existing teams can take the quiz
    },

    role: {
      type: String,
      default: "fieldTeam",
      enum: ["fieldTeam"], // Add other roles as needed
    },
    isNewToInstallation: {
      type: Boolean,
      default: false
    },
    isNewToActivation: {
      type: Boolean,
      default: false
    },
    installationStartDate: {
      type: Date,
      default: null
    },
    activationStartDate: {
      type: Date,
      default: null
    },
    escalationAction: {
      type: String,
      default: "",
      trim: true,
    },
    escalationStatus: {
      type: String,
      default: "Pending",
      trim: true,
    },
    escalationNotes: {
      type: String,
      default: "",
      trim: true,
    },
    escalationDate: {
      type: Date,
      default: null,
    },
    escalationHistory: [
      {
        offenseScale: {
          type: String,
          default: "",
          trim: true,
        },
        action: {
          type: String,
          default: "",
          trim: true,
        },
        status: {
          type: String,
          default: "Action Taken",
          trim: true,
        },
        actionDate: {
          type: Date,
          default: Date.now,
        },
        period: {
          type: String,
          default: "",
          trim: true,
        },
        notes: {
          type: String,
          default: "",
          trim: true,
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      }
    ],
  },
  { timestamps: true }
);

// Add indexes here, before creating the model
fieldTeamsSchema.index({ quizCode: 1, canTakeQuiz: 1 }); // For quick validation checks
fieldTeamsSchema.index({ isEvaluated: 1, lastEvaluationDate: 1 }); // For reporting

export const FieldTeamsSchema = mongoose.model("FieldTeams", fieldTeamsSchema);