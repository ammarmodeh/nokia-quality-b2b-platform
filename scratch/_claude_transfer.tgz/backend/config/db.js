import mongoose from "mongoose";
import dns from "dns";

/**
 * Connects to MongoDB.
 * Re-added dns.setServers fix because your network/ISP has trouble 
 * resolving MongoDB Atlas SRV records (ECONNREFUSED error).
 */
export const connectDB = async () => {
  try {
    // Force Google DNS to resolve MongoDB SRV records only for local development 
    // if it's needed. On Vercel, this can cause ERR_CONNECTION_RESET.
    if (!process.env.VERCEL && process.env.NODE_ENV !== "production") {
      try {
        dns.setServers(['8.8.8.8', '8.8.4.4']);
      } catch (dnsErr) {
        console.warn("⚠️ Could not set DNS servers:", dnsErr.message);
      }
    }

    const mongoUri = process.env.MONGO_URI;
    if (!mongoUri) {
      throw new Error("MONGO_URI is not defined in environment variables!");
    }

    const conn = await mongoose.connect(mongoUri);
    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);

    mongoose.connection.on('error', (err) => console.error('❌ MongoDB error:', err));
    mongoose.connection.on('disconnected', () => console.warn('⚠️ MongoDB disconnected'));

  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);

    if (error.message.includes("ENOTFOUND")) {
      console.error("💡 TIP: Your ISP/network is blocking the DNS resolution for MongoDB Atlas.");
      console.error("Try using a non-SRV connection string or check your firewall settings.");
    }

    if (error.code === "ETIMEDOUT") {
      console.error("💡 TIP: The connection to MongoDB Atlas timed out.");
      console.error("1. Ensure your IP address is whitelisted in MongoDB Atlas settings.");
      console.error("2. Check if your corporate firewall or local network blocks port 27017.");
    }

    // Removed process.exit(1) to prevent the app from crashing on connection failure.
    // This allows the server to stay up and show diagnostics to the user.
    // Mongoose will automatically try to reconnect if configured.
  }
};
